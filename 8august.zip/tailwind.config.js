/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}', "*.{js,ts,jsx,tsx,mdx}"],
  theme: {
    extend: {
      colors: {
        nature: {
          50: '#f0fdf4',   // lightest green
          100: '#dcfce7',  // very light green
          200: '#bbf7d0',  // light green
          300: '#86efac',  // soft green
          400: '#4ade80',  // medium green
          500: '#22c55e',  // main green
          600: '#16a34a',  // darker green
          700: '#15803d',  // dark green
          800: '#166534',  // very dark green
          900: '#14532d',  // darkest green
        },
        earth: {
          50: '#fefdf8',   // cream white
          100: '#fef7ed',  // warm white
          200: '#fed7aa',  // light sand
          300: '#fdba74',  // sand
          400: '#fb923c',  // warm orange
          500: '#f97316',  // main orange
          600: '#ea580c',  // deeper orange
          700: '#c2410c',  // dark orange
          800: '#9a3412',  // very dark orange
          900: '#7c2d12',  // darkest orange
        },
        sage: {
          50: '#f8fafc',   // very light sage
          100: '#f1f5f9',  // light sage
          200: '#e2e8f0',  // sage gray
          300: '#cbd5e1',  // medium sage
          400: '#94a3b8',  // darker sage
          500: '#64748b',  // main sage
          600: '#475569',  // dark sage
          700: '#334155',  // very dark sage
          800: '#1e293b',  // darkest sage
          900: '#0f172a',  // black sage
        }
      },
      borderRadius: {
        'xl': '1rem',
        '2xl': '1.5rem',
        '3xl': '2rem',
        'organic': '2rem 1rem 2rem 1rem',
        'leaf': '0 2rem 0 2rem',
      },
      fontFamily: {
        'sans': ['Inter', 'system-ui', 'sans-serif'],
        'display': ['Poppins', 'Inter', 'system-ui', 'sans-serif'],
      },
      backgroundImage: {
        'organic-gradient': 'linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%)',
        'earth-gradient': 'linear-gradient(135deg, #fef7ed 0%, #fed7aa 100%)',
        'nature-pattern': "url('data:image/svg+xml,%3Csvg width=\"60\" height=\"60\" viewBox=\"0 0 60 60\" xmlns=\"http://www.w3.org/2000/svg\"%3E%3Cg fill=\"none\" fill-rule=\"evenodd\"%3E%3Cg fill=\"%2322c55e\" fill-opacity=\"0.03\"%3E%3Ccircle cx=\"30\" cy=\"30\" r=\"3\"/%3E%3C/g%3E%3C/g%3E%3C/svg%3E')",
      },
      boxShadow: {
        'organic': '0 8px 32px rgba(34, 197, 94, 0.1)',
        'earth': '0 8px 32px rgba(249, 115, 22, 0.1)',
        'soft': '0 4px 20px rgba(0, 0, 0, 0.05)',
        'nature': '0 10px 40px rgba(34, 197, 94, 0.15)',
      },
      animation: {
        'float': 'float 6s ease-in-out infinite',
        'sway': 'sway 4s ease-in-out infinite',
        'grow': 'grow 0.3s ease-out',
      },
      keyframes: {
        float: {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-10px)' },
        },
        sway: {
          '0%, 100%': { transform: 'rotate(-2deg)' },
          '50%': { transform: 'rotate(2deg)' },
        },
        grow: {
          '0%': { transform: 'scale(1)' },
          '100%': { transform: 'scale(1.05)' },
        },
      },
    },
  },
  plugins: [],
};
