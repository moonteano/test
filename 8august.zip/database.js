import sqlite3 from 'sqlite3';
import bcrypt from 'bcryptjs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Initialize SQLite database
const db = new sqlite3.Database(path.join(__dirname, 'ecommerce.db'));

// Initialize database tables
export const initializeDatabase = () => {
  return new Promise((resolve, reject) => {
    db.serialize(async () => {
      // Users table
      db.run(`
        CREATE TABLE IF NOT EXISTS users (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          email TEXT UNIQUE NOT NULL,
          password TEXT NOT NULL,
          firstName TEXT NOT NULL,
          lastName TEXT NOT NULL,
          phone TEXT,
          address TEXT,
          city TEXT,
          zipCode TEXT,
          role TEXT DEFAULT 'user',
          status TEXT DEFAULT 'active',
          createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
          updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP
        )
      `);

      // Password reset tokens table
      db.run(`
        CREATE TABLE IF NOT EXISTS password_reset_tokens (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          userId INTEGER NOT NULL,
          token TEXT UNIQUE NOT NULL,
          expiresAt DATETIME NOT NULL,
          createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY (userId) REFERENCES users (id) ON DELETE CASCADE
        )
      `);

      // Products table
      db.run(`
        CREATE TABLE IF NOT EXISTS products (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT NOT NULL,
          description TEXT,
          price DECIMAL(10,2) NOT NULL,
          discountPrice DECIMAL(10,2),
          category TEXT NOT NULL,
          brand TEXT,
          inStock BOOLEAN DEFAULT 1,
          imageUrl TEXT,
          tags TEXT,
          featured BOOLEAN DEFAULT 0,
          status TEXT DEFAULT 'active',
          createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
          updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP
        )
      `);
      // Adaugă coloana orderIndex dacă nu există
      db.run(`ALTER TABLE products ADD COLUMN orderIndex INTEGER DEFAULT 0`, () => {});

      // Orders table
      db.run(`
        CREATE TABLE IF NOT EXISTS orders (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          userId INTEGER NOT NULL,
          orderNumber TEXT UNIQUE NOT NULL,
          status TEXT DEFAULT 'pending',
          totalAmount DECIMAL(10,2) NOT NULL,
          shippingAddress TEXT NOT NULL,
          paymentMethod TEXT NOT NULL,
          notes TEXT,
          createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
          updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY (userId) REFERENCES users (id)
        )
      `);

      // Order items table
      db.run(`
        CREATE TABLE IF NOT EXISTS order_items (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          orderId INTEGER NOT NULL,
          productId INTEGER NOT NULL,
          quantity INTEGER NOT NULL,
          price DECIMAL(10,2) NOT NULL,
          FOREIGN KEY (orderId) REFERENCES orders (id),
          FOREIGN KEY (productId) REFERENCES products (id)
        )
      `);

      // Cart items table
      db.run(`
        CREATE TABLE IF NOT EXISTS cart_items (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          userId INTEGER NOT NULL,
          productId INTEGER NOT NULL,
          quantity INTEGER NOT NULL,
          createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY (userId) REFERENCES users (id),
          FOREIGN KEY (productId) REFERENCES products (id)
        )
      `);

      // Contact messages table
      db.run(`
        CREATE TABLE IF NOT EXISTS contact_messages (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT NOT NULL,
          email TEXT NOT NULL,
          subject TEXT NOT NULL,
          message TEXT NOT NULL,
          status TEXT DEFAULT 'unread',
          createdAt DATETIME DEFAULT CURRENT_TIMESTAMP
        )
      `);

      // Notifications table
      db.run(`
        CREATE TABLE IF NOT EXISTS notifications (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          userId INTEGER NOT NULL,
          type TEXT NOT NULL,
          title TEXT NOT NULL,
          message TEXT NOT NULL,
          isRead BOOLEAN DEFAULT 0,
          createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY (userId) REFERENCES users (id)
        )
      `);

      // User profiles table for shipping addresses
      db.run(`
        CREATE TABLE IF NOT EXISTS user_profiles (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          userId INTEGER NOT NULL,
          shippingFirstName TEXT,
          shippingLastName TEXT,
          shippingAddress TEXT,
          shippingCity TEXT,
          shippingZipCode TEXT,
          shippingPhone TEXT,
          billingFirstName TEXT,
          billingLastName TEXT,
          billingAddress TEXT,
          billingCity TEXT,
          billingZipCode TEXT,
          billingPhone TEXT,
          createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
          updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY (userId) REFERENCES users (id)
        )
      `);

      // Chat messages table
      db.run(`
        CREATE TABLE IF NOT EXISTS chat_messages (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          userId INTEGER NOT NULL,
          senderName TEXT NOT NULL,
          senderRole TEXT NOT NULL,
          message TEXT NOT NULL,
          createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY (userId) REFERENCES users (id) ON DELETE CASCADE
        )
      `);

      // Product reviews table
      db.run(`
        CREATE TABLE IF NOT EXISTS product_reviews (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          userId INTEGER NOT NULL,
          productId INTEGER NOT NULL,
          rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
          title TEXT,
          comment TEXT NOT NULL,
          createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY (userId) REFERENCES users (id),
          FOREIGN KEY (productId) REFERENCES products (id)
        )
      `);

      // Favorites table
      db.run(`
        CREATE TABLE IF NOT EXISTS favorites (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          userId INTEGER NOT NULL,
          productId INTEGER NOT NULL,
          createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY (userId) REFERENCES users (id),
          FOREIGN KEY (productId) REFERENCES products (id),
          UNIQUE(userId, productId)
        )
      `);

      // Coupons table
      db.run(`
        CREATE TABLE IF NOT EXISTS coupons (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          code TEXT UNIQUE NOT NULL,
          name TEXT NOT NULL,
          description TEXT,
          discountType TEXT NOT NULL CHECK (discountType IN ('percentage', 'fixed')),
          discountValue DECIMAL(10,2) NOT NULL,
          minimumAmount DECIMAL(10,2) DEFAULT 0,
          maxUses INTEGER DEFAULT NULL,
          usedCount INTEGER DEFAULT 0,
          isActive BOOLEAN DEFAULT 1,
          validFrom DATETIME NOT NULL,
          validTo DATETIME NOT NULL,
          createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
          updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP
        )
      `);

      // Coupon usage tracking table
      db.run(`
        CREATE TABLE IF NOT EXISTS coupon_usage (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          couponId INTEGER NOT NULL,
          userId INTEGER NOT NULL,
          orderId INTEGER,
          discountAmount DECIMAL(10,2) NOT NULL,
          createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY (couponId) REFERENCES coupons (id),
          FOREIGN KEY (userId) REFERENCES users (id)
        )
      `);

      // Stories table for homepage story cards
      db.run(`
        CREATE TABLE IF NOT EXISTS stories (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT NOT NULL,
          image TEXT NOT NULL,
          link TEXT NOT NULL,
          bgGradient TEXT NOT NULL,
          title TEXT NOT NULL,
          subtitle TEXT NOT NULL,
          description TEXT NOT NULL,
          personImage TEXT,
          isActive BOOLEAN DEFAULT 1,
          orderIndex INTEGER NOT NULL,
          createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
          updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP
        )
      `);
      // Update contact_messages table to include userId for replies
      db.run(`
        ALTER TABLE contact_messages ADD COLUMN userId INTEGER
      `, () => {
        // Ignore error if column already exists
      });

      db.run(`
        ALTER TABLE contact_messages ADD COLUMN conversationId TEXT
      `, () => {
        // Ignore error if column already exists
      });

      // Create default admin user
      const adminEmail = 'admin@apachecom.ro';
      const adminPassword = await bcrypt.hash('Philadelfia1@', 10);
      
      db.run(`
        INSERT OR IGNORE INTO users (email, password, firstName, lastName, role)
        VALUES (?, ?, 'Admin', 'User', 'admin')
      `, [adminEmail, adminPassword]);

      // Sample products insertion removed to prevent auto-adding on restart

      resolve();
    });
  });
};

export default db;
