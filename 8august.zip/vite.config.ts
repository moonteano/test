import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    host: true,
    allowedHosts: [
      'localhost',
      '127.0.0.1',
      '5.249.161.92',
      'apachecom.ro',
      'www.apachecom.ro'
    ],
    proxy: {
      '/api': {
        target: 'http://5.249.161.92:3001',
        changeOrigin: true,
        secure: false,
      },
    },
  },
  optimizeDeps: {
    exclude: ['lucide-react'],
  },
  build: {
    // Heavy obfuscation and minification for production
    minify: 'terser',
    // Ensure UTF-8 encoding
    charset: 'utf8',
    terserOptions: {
      compress: {
        drop_console: true, // Remove console.logs
        drop_debugger: true, // Remove debugger statements
        pure_funcs: ['console.log', 'console.info', 'console.debug', 'console.warn'],
      },
      mangle: {
        toplevel: true, // Mangle top-level variable names
        eval: true,
        keep_fnames: false, // Don't keep function names
        properties: {
          regex: /^_/, // Mangle properties starting with _
        },
      },
      format: {
        comments: false, // Remove all comments
      },
    },
    rollupOptions: {
      output: {
        // Obfuscate chunk names
        chunkFileNames: 'assets/[hash].js',
        entryFileNames: 'assets/[hash].js',
        assetFileNames: 'assets/[hash].[ext]',
        manualChunks: {
          // Split vendor code to make reverse engineering harder
          vendor: ['react', 'react-dom'],
          router: ['react-router-dom'],
          ui: ['lucide-react'],
        },
      },
    },
    sourcemap: false, // Never generate source maps for production
    cssCodeSplit: true, // Split CSS to make analysis harder
  },
});
