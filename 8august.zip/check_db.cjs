const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./api/ecommerce.db');

console.log('Checking notifications table structure...');

db.serialize(() => {
  // Get table schema
  db.all("PRAGMA table_info(notifications)", (err, rows) => {
    if (err) {
      console.error('Error getting table info:', err);
    } else {
      console.log('Notifications table columns:');
      rows.forEach(row => {
        console.log(`- ${row.name}: ${row.type} (nullable: ${row.notnull === 0})`);
      });
    }
  });

  // Check current notifications
  db.all("SELECT id, userId, message, isRead, createdAt FROM notifications LIMIT 5", (err, rows) => {
    if (err) {
      console.error('Error fetching notifications:', err);
    } else {
      console.log('\nSample notifications:');
      rows.forEach(row => {
        console.log(`ID: ${row.id}, User: ${row.userId}, Read: ${row.isRead}, Message: ${row.message?.substring(0, 50)}...`);
      });
    }
    
    db.close();
  });
});
