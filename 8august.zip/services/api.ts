import axios from 'axios';
import { Product, CartItem, Order, DashboardStats, User } from '../types';

export const API_BASE_URL = 'https://apachecom.ro/api';
export const API_ORIGIN = new URL(API_BASE_URL).origin;
export const toAssetUrl = (p: string = '') => {
  if (!p) return '' as any;
  return p.startsWith('http') ? p : `${API_ORIGIN}${p.startsWith('/') ? '' : '/'}${p}`;
};

const api = axios.create({
  baseURL: API_BASE_URL,
});

// Add token to requests
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Products API
export const productsAPI = {
  getAll: (params?: any) => api.get<Product[]>('/products', { params }).then(res => res.data),
  getById: (id: number) => api.get<Product>(`/products/${id}`).then(res => res.data),
  getCategories: () => api.get<string[]>('/categories').then(res => res.data),
  getReviews: (productId: number) => api.get(`/products/${productId}/reviews`).then(res => res.data),
  addReview: (productId: number, reviewData: any) => 
    api.post(`/products/${productId}/reviews`, reviewData).then(res => res.data),
  deleteReview: (productId: number, reviewId: number) =>
    api.delete(`/products/${productId}/reviews/${reviewId}`).then(res => res.data),
  getFavorites: () => api.get('/favorites').then(res => res.data),
  addToFavorites: (productId: number) => 
    api.post('/favorites', { productId }).then(res => res.data),
  removeFromFavorites: (productId: number) => 
    api.delete(`/favorites/${productId}`).then(res => res.data),
};

// Cart API
export const cartAPI = {
  getItems: () => api.get<CartItem[]>('/cart').then(res => res.data),
  addItem: (productId: number, quantity: number) => 
    api.post('/cart', { productId, quantity }).then(res => res.data),
  removeItem: (productId: number) => 
    api.delete(`/cart/${productId}`).then(res => res.data),
};

// Orders API
export const ordersAPI = {
  create: (orderData: any) => api.post('/orders', orderData).then(res => res.data),
  getMyOrders: () => api.get<Order[]>('/orders').then(res => res.data),
};

// Admin API
export const adminAPI = {
  getDashboard: (range?: string) => api.get<DashboardStats>('/admin/dashboard', { params: range ? { range } : {} }).then(res => res.data),
  getUsers: () => api.get<User[]>('/admin/users').then(res => res.data),
  updateUserStatus: (id: number, status: string) => 
    api.put(`/admin/users/${id}/status`, { status }).then(res => res.data),
  getOrders: () => api.get<Order[]>('/admin/orders').then(res => res.data),
  updateOrderStatus: (id: number, status: string) => 
    api.put(`/admin/orders/${id}/status`, { status }).then(res => res.data),
  createProduct: (productData: any) => 
    api.post('/admin/products', productData).then(res => res.data),
  updateProduct: (id: number, productData: any) => 
    api.put(`/admin/products/${id}`, productData).then(res => res.data),
  deleteProduct: (id: number) => 
    api.delete(`/admin/products/${id}`).then(res => res.data),
  getMessages: () => api.get('/admin/messages').then(res => res.data),
  markMessageAsRead: (id: number) => 
    api.put(`/admin/messages/${id}/read`).then(res => res.data),
  deleteMessage: (id: number) => 
    api.delete(`/admin/messages/${id}`).then(res => res.data),
  replyToMessage: (id: number, reply: string) => 
    api.post(`/admin/messages/${id}/reply`, { reply }).then(res => res.data),
  // Notifications
  getAllNotifications: () => api.get('/admin/notifications').then(res => res.data),
  sendNotification: (notificationData: any) => 
    api.post('/admin/notifications', notificationData).then(res => res.data),
  sendNotificationToAll: (notificationData: any) => 
    api.post('/admin/notifications/broadcast', notificationData).then(res => res.data),
  deleteNotification: (id: number) => 
    api.delete(`/admin/notifications/${id}`).then(res => res.data),
  // SQL
  runSQL: (query: string) => api.post('/admin/sql', { query }).then(res => res.data),
  getSQLTables: () => api.get('/admin/sql/tables').then(res => res.data),
  getSQLTable: (table: string) => api.get(`/admin/sql/table/${table}`).then(res => res.data),
  updateSQLRow: (table: string, id: number, data: any) => api.put(`/admin/sql/table/${table}/${id}`, data).then(res => res.data),
  addSQLRow: (table: string, data: any) => api.post(`/admin/sql/table/${table}`, data).then(res => res.data),
  deleteSQLRow: (table: string, id: number) => api.delete(`/admin/sql/table/${table}/${id}`).then(res => res.data),
  // Sales by Category and Recent Orders
  getSalesByCategory: () => api.get('/admin/sales-by-category').then(res => res.data),
  getRecentOrders: () => api.get('/admin/recent-orders').then(res => res.data),
  // Salveaza ordinea categoriilor
  setCategoryOrder: (order: string[]) => api.post('/admin/categories/order', { order }).then(res => res.data),
  // Salveaza ordinea produselor
  setProductOrder: (order: number[]) => api.post('/admin/products/order', { order }).then(res => res.data),
};

// Contact API
export const contactAPI = {
  sendMessage: (messageData: any) => api.post('/contact', messageData).then(res => res.data),
};

// Notifications API
export const notificationsAPI = {
  getAll: () => api.get('/notifications').then(res => res.data),
  markAsRead: (id: number) => api.put(`/notifications/${id}/read`).then(res => res.data),
  markAllAsRead: () => api.put('/notifications/mark-all-read').then(res => res.data),
  delete: (id: number) => api.delete(`/notifications/${id}`).then(res => res.data),
  clearRead: () => api.delete('/notifications/clear-read').then(res => res.data),
  clearAll: () => api.delete('/notifications/clear-all').then(res => res.data),
};

// User API
export const userAPI = {
  forgotPassword: (email: string) => api.post('/auth/forgot-password', { email }).then(res => res.data),
  resetPassword: (token: string, password: string) => api.post('/auth/reset-password', { token, password }).then(res => res.data),
};

// File Manager API
export const fileAPI = {
  list: (folder = '') => 
    api.get('/admin/files', { params: { folder } }).then(res => res.data),
  
  upload: (files: FileList, folder = '') => {
    const formData = new FormData();
    Array.from(files).forEach(file => {
      formData.append('files', file);
    });
    if (folder) formData.append('folder', folder);
    
    return api.post('/admin/files/upload', formData, {
      headers: { 'Content-Type': 'multipart/form-data' }
    }).then(res => res.data);
  },
  
  createFolder: (folder: string, name: string) => 
    api.post('/admin/files/folder', { folder, name }).then(res => res.data),
  
  deleteFile: (folder: string, name: string) => 
    api.delete('/admin/files', { data: { folder, name } }).then(res => res.data),
  
  rename: (folder: string, oldName: string, newName: string) => 
    api.put('/admin/files/rename', { folder, oldName, newName }).then(res => res.data),
  
  move: (srcFolder: string, name: string, destFolder: string) => 
    api.post('/admin/files/move', { srcFolder, name, destFolder }).then(res => res.data),
};

// Stories API
export const storiesAPI = {
  getAll: () => api.get('/stories').then(res => res.data),
  getAllAdmin: () => api.get('/admin/stories').then(res => res.data),
  create: (storyData: any) => api.post('/admin/stories', storyData).then(res => res.data),
  update: (id: number, storyData: any) => api.put(`/admin/stories/${id}`, storyData).then(res => res.data),
  delete: (id: number) => api.delete(`/admin/stories/${id}`).then(res => res.data),
};

// Coupons API
export const couponsAPI = {
  // Admin operations
  getAll: () => api.get('/admin/coupons').then(res => res.data),
  create: (couponData: any) => api.post('/admin/coupons', couponData).then(res => res.data),
  update: (id: number, couponData: any) => api.put(`/admin/coupons/${id}`, couponData).then(res => res.data),
  delete: (id: number) => api.delete(`/admin/coupons/${id}`).then(res => res.data),
  getStats: () => api.get('/admin/coupons/stats').then(res => res.data),
  
  // User operations
  validate: (code: string, totalAmount: number) => 
    api.post('/coupons/validate', { code, totalAmount }).then(res => res.data),
  apply: (code: string, orderTotal: number) => 
    api.post('/coupons/apply', { code, orderTotal }).then(res => res.data),
};

export default api;
