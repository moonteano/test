import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { cartAPI } from '../services/api';

interface CartContextType {
  cartItemsCount: number;
  updateCartCount: () => void;
  incrementCartCount: (quantity?: number) => void;
  decrementCartCount: (quantity?: number) => void;
  setCartCount: (count: number) => void;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export const useCart = () => {
  const context = useContext(CartContext);
  if (context === undefined) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
};

interface CartProviderProps {
  children: ReactNode;
}

export const CartProvider: React.FC<CartProviderProps> = ({ children }) => {
  const [cartItemsCount, setCartItemsCount] = useState(0);

  const fetchCartCount = async () => {
    try {
      // Check if user is authenticated before making the request
      const token = localStorage.getItem('token');
      if (!token) {
        setCartItemsCount(0);
        return;
      }

      const items = await cartAPI.getItems();
      const totalCount = items.reduce((sum, item) => sum + item.quantity, 0);
      setCartItemsCount(totalCount);
    } catch (error) {
      console.error('Error fetching cart count:', error);
      setCartItemsCount(0);
    }
  };

  const updateCartCount = () => {
    fetchCartCount();
  };

  const incrementCartCount = (quantity: number = 1) => {
    setCartItemsCount(prev => prev + quantity);
  };

  const decrementCartCount = (quantity: number = 1) => {
    setCartItemsCount(prev => Math.max(0, prev - quantity));
  };

  const setCartCount = (count: number) => {
    setCartItemsCount(Math.max(0, count));
  };

  useEffect(() => {
    updateCartCount();
    
    // Listen for auth state changes
    const handleStorageChange = () => {
      updateCartCount();
    };
    
    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, []);

  const value = {
    cartItemsCount,
    updateCartCount,
    incrementCartCount,
    decrementCartCount,
    setCartCount
  };

  return (
    <CartContext.Provider value={value}>
      {children}
    </CartContext.Provider>
  );
};
