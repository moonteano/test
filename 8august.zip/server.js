import express from 'express';
import cors from 'cors';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import path from 'path';
import { fileURLToPath } from 'url';
import db, { initializeDatabase } from './database.js';
import Stripe from 'stripe';
import { OAuth2Client } from 'google-auth-library';
import sqlite3 from 'sqlite3';
import multer from 'multer';
import fs from 'fs';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import { randomBytes } from 'crypto';
import dotenv from 'dotenv';

// Load environment variables
dotenv.config({ path: path.join(path.dirname(fileURLToPath(import.meta.url)), '../.env') });

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3001;
// Use environment variable or generate random JWT secret
const JWT_SECRET = process.env.JWT_SECRET || randomBytes(64).toString('hex');
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || 'STRIPE_SECRET_KEY', { apiVersion: '2022-11-15' });
const GOOGLE_CLIENT_ID = process.env.GOOGLE_CLIENT_ID || '942886322491-m04lmosrd12skv7q1q9l90lv7crcg286.apps.googleusercontent.com';
const googleClient = new OAuth2Client(GOOGLE_CLIENT_ID);

// Security middleware
app.use(helmet({
  contentSecurityPolicy: false,
  crossOriginEmbedderPolicy: false,
}));

// Rate limiting (more permissive for development)
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 1000, // increased for development - limit each IP to 1000 requests per windowMs
  message: 'Too many requests from this IP, please try again later.',
  standardHeaders: true,
  legacyHeaders: false,
  skip: (req) => {
    // Skip rate limiting for local development
    return req.ip === '::1' || req.ip === '127.0.0.1' || req.ip?.includes('192.168.');
  }
});

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 50, // increased for development - limit each IP to 50 auth requests per windowMs
  message: 'Too many authentication attempts, please try again later.',
  skipSuccessfulRequests: true,
  skip: (req) => {
    // Skip rate limiting for local development
    return req.ip === '::1' || req.ip === '127.0.0.1' || req.ip?.includes('192.168.');
  }
});

app.use(limiter);
app.use('/api/auth', authLimiter);

// Basic middleware
app.use(cors({
  origin: true, // Allow all origins for development
  credentials: true,
}));

// Set UTF-8 encoding for all responses
app.use((req, res, next) => {
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  next();
});

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// Serve static files from the uploads directory (for product images, etc.)
app.use('/uploads', express.static(path.join(__dirname, '../uploads'), {
  setHeaders: (res) => {
    res.set('Access-Control-Allow-Origin', '*');
    res.set('Cross-Origin-Resource-Policy', 'cross-origin');
    res.set('Cross-Origin-Opener-Policy', 'same-origin-allow-popups');
    res.set('Access-Control-Allow-Headers', '*');
  }
}));

// Serve static files from the dist directory
app.use(express.static(path.join(__dirname, '../dist')));

// File upload config
const uploadDir = path.join(__dirname, '../uploads');
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir);
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    // Use root upload directory for all files initially
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + '-' + file.originalname);
  }
});
const upload = multer({ 
  storage,
  limits: {
    fileSize: 10 * 1024 * 1024 // 10MB limit
  }
});

// Auth middleware
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Access token required' });
  }

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ error: 'Invalid token' });
    }
    req.user = user;
    next();
  });
};

// Admin middleware
const requireAdmin = (req, res, next) => {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Admin access required' });
  }
  next();
};

// Initialize database
await initializeDatabase();

// --- AUTO-MIGRATION: Recreate chat_messages table if missing or broken ---
await new Promise((resolve) => {
  db.get("PRAGMA table_info(chat_messages);", (err, columns) => {
    if (err || !Array.isArray(columns) || columns.length === 0) {
      console.warn('Tabela chat_messages nu exista sau este corupta. Se va recrea automat...');
      db.serialize(() => {
        db.run("DROP TABLE IF EXISTS chat_messages;");
        db.run(`CREATE TABLE chat_messages (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          userId INTEGER,
          senderName TEXT,
          senderRole TEXT,
          message TEXT NOT NULL,
          createdAt DATETIME DEFAULT CURRENT_TIMESTAMP
        );`, (err) => {
          if (err) {
            console.error('FATAL: Nu s-a putut crea tabela chat_messages:', err.message);
            process.exit(1);
          } else {
            console.log('Tabela chat_messages a fost recreata cu succes!');
            resolve();
          }
        });
      });
    } else {
      resolve();
    }
  });
});

// --- CLEANUP CHAT MESSAGES ORFANE ---
db.run(`DELETE FROM chat_messages WHERE userId NOT IN (SELECT id FROM users) OR senderName IS NULL OR senderName = ''`);

// DEBUG: Print users table structure at startup
const debugDb = new sqlite3.Database(path.join(__dirname, 'ecommerce.db'));
debugDb.all('PRAGMA table_info(users);', (err, rows) => {
  if (err) {
    console.error('Error reading users table structure:', err.message);
  } else {
    console.log('USERS TABLE STRUCTURE:');
    rows.forEach(row => console.log(row));
  }
});

// DEBUG: Print admin JWT token for admin@ecommerce.com at startup
db.get('SELECT * FROM users WHERE email = ?', ['admin@ecommerce.com'], (err, user) => {
  if (!err && user) {
    const token = jwt.sign({ userId: user.id, email: user.email, role: user.role }, JWT_SECRET);
    console.log('ADMIN JWT TOKEN:', token);
  }
});

// Authentication routes
app.post('/api/auth/register', async (req, res) => {
  try {
    const { email, password, firstName, lastName, phone, address, city, zipCode } = req.body;
    
    const hashedPassword = await bcrypt.hash(password, 10);
    
    db.run(`
      INSERT INTO users (email, password, firstName, lastName, phone, address, city, zipCode)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `, [email, hashedPassword, firstName, lastName, phone, address, city, zipCode], function(err) {
      if (err) {
        if (err.message.includes('UNIQUE constraint failed')) {
          return res.status(400).json({ error: 'Email already exists' });
        }
        return res.status(500).json({ error: err.message });
      }
      
      const token = jwt.sign({ userId: this.lastID, email, role: 'user' }, JWT_SECRET);
      res.json({ 
        token, 
        user: { 
          id: this.lastID, 
          email, 
          firstName, 
          lastName, 
          role: 'user' 
        } 
      });
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    
    db.get('SELECT * FROM users WHERE email = ?', [email], async (err, user) => {
      if (err) {
        return res.status(500).json({ error: err.message });
      }
      
      if (!user || !(await bcrypt.compare(password, user.password))) {
        return res.status(401).json({ error: 'Invalid credentials' });
      }
      
      if (user.status !== 'active') {
        return res.status(401).json({ error: 'Account is disabled' });
      }
      
      const token = jwt.sign({ 
        userId: user.id, 
        email: user.email, 
        role: user.role 
      }, JWT_SECRET);
      
      res.json({ 
        token, 
        user: { 
          id: user.id, 
          email: user.email, 
          firstName: user.firstName, 
          lastName: user.lastName, 
          role: user.role 
        } 
      });
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Google OAuth login/register endpoint
app.post('/api/auth/google', async (req, res) => {
  const { credential } = req.body;
  if (!credential) return res.status(400).json({ error: 'Missing Google credential' });
  try {
    const ticket = await googleClient.verifyIdToken({
      idToken: credential,
      audience: GOOGLE_CLIENT_ID,
    });
    const payload = ticket.getPayload();
    if (!payload?.email) return res.status(400).json({ error: 'Invalid Google token' });
    // Check if user exists
    db.get('SELECT * FROM users WHERE email = ?', [payload.email], async (err, user) => {
      if (err) return res.status(500).json({ error: err.message });
      if (!user) {
        // Register new user (set password to 'google-oauth' and fill all required NOT NULL fields)
        db.run(`INSERT INTO users (email, password, firstName, lastName) VALUES (?, ?, ?, ?)`,
          [payload.email, 'google-oauth', payload.given_name || '', payload.family_name || ''],
          function(err) {
            if (err) return res.status(500).json({ error: err.message });
            const token = jwt.sign({ userId: this.lastID, email: payload.email, role: 'user' }, JWT_SECRET);
            return res.json({ token, user: { id: this.lastID, email: payload.email, firstName: payload.given_name, lastName: payload.family_name, role: 'user' } });
          }
        );
      } else {
        // Login existing user
        const token = jwt.sign({ userId: user.id, email: user.email, role: user.role }, JWT_SECRET);
        return res.json({ token, user });
      }
    });
  } catch (e) {
    return res.status(401).json({ error: 'Invalid Google token' });
  }
});

// Password reset endpoints
app.post('/api/auth/forgot-password', async (req, res) => {
  const { email } = req.body;
  
  if (!email) {
    return res.status(400).json({ error: 'Email is required' });
  }

  // Check if user exists
  db.get('SELECT id, email, firstName FROM users WHERE email = ?', [email], async (err, user) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }

    if (!user) {
      // Don't reveal if email exists or not for security
      return res.json({ message: 'Daca email-ul exista, vei primi instruc?iuni de resetare.' });
    }

    // Generate reset token
    const resetToken = randomBytes(32).toString('hex');
    const resetTokenExpiry = new Date(Date.now() + 3600000); // 1 hour from now

    // Store reset token in database (add this table if needed)
    db.run(`
      INSERT OR REPLACE INTO password_reset_tokens (userId, token, expiresAt, createdAt)
      VALUES (?, ?, ?, CURRENT_TIMESTAMP)
    `, [user.id, resetToken, resetTokenExpiry.toISOString()], (err) => {
      if (err) {
        console.error('Error storing reset token:', err);
        return res.status(500).json({ error: 'Failed to generate reset token' });
      }

      // In a real app, you would send an email here
      // For demo purposes, we'll return the token (REMOVE IN PRODUCTION!)
      console.log(`Reset token for ${email}: ${resetToken}`);
      
      res.json({ 
        message: 'Daca email-ul exista, vei primi instruc?iuni de resetare.',
        // REMOVE THIS IN PRODUCTION - only for demo
        resetToken: resetToken 
      });
    });
  });
});

app.post('/api/auth/reset-password', async (req, res) => {
  const { token, newPassword } = req.body;
  
  if (!token || !newPassword) {
    return res.status(400).json({ error: 'Token ?i parola noua sunt necesare' });
  }

  if (newPassword.length < 6) {
    return res.status(400).json({ error: 'Parola trebuie sa aiba cel pu?in 6 caractere' });
  }

  // Check if token is valid and not expired
  db.get(`
    SELECT userId FROM password_reset_tokens 
    WHERE token = ? AND expiresAt > CURRENT_TIMESTAMP
  `, [token], async (err, resetRecord) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }

    if (!resetRecord) {
      return res.status(400).json({ error: 'Token invalid sau expirat' });
    }

    try {
      // Hash new password
      const hashedPassword = await bcrypt.hash(newPassword, 10);

      // Update user password
      db.run(`
        UPDATE users SET password = ?, updatedAt = CURRENT_TIMESTAMP WHERE id = ?
      `, [hashedPassword, resetRecord.userId], function(err) {
        if (err) {
          return res.status(500).json({ error: err.message });
        }

        // Delete used reset token
        db.run('DELETE FROM password_reset_tokens WHERE token = ?', [token]);

        res.json({ message: 'Parola a fost resetata cu succes' });
      });
    } catch (error) {
      res.status(500).json({ error: 'Failed to hash password' });
    }
  });
});

// Verify reset token endpoint
app.post('/api/auth/verify-reset-token', (req, res) => {
  const { token } = req.body;
  
  if (!token) {
    return res.status(400).json({ error: 'Token is required' });
  }

  db.get(`
    SELECT u.email FROM password_reset_tokens prt
    JOIN users u ON prt.userId = u.id
    WHERE prt.token = ? AND prt.expiresAt > CURRENT_TIMESTAMP
  `, [token], (err, result) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }

    if (!result) {
      return res.status(400).json({ error: 'Token invalid sau expirat' });
    }

    res.json({ valid: true, email: result.email });
  });
});

// Products routes
app.get('/api/products', (req, res) => {
  const { category, search, minPrice, maxPrice } = req.query;
  let query = 'SELECT * FROM products WHERE status = "active"';
  const params = [];

  if (category) {
    query += ' AND category = ?';
    params.push(category);
  }
  if (search) {
    query += ' AND name LIKE ?';
    params.push(`%${search}%`);
  }
  if (minPrice) {
    query += ' AND (discountPrice IS NOT NULL AND discountPrice >= ? OR (discountPrice IS NULL AND price >= ?))';
    params.push(minPrice, minPrice);
  }
  if (maxPrice) {
    query += ' AND (discountPrice IS NOT NULL AND discountPrice <= ? OR (discountPrice IS NULL AND price <= ?))';
    params.push(maxPrice, maxPrice);
  }

  // ORDINE PERSONALIZATA
  query += ' ORDER BY orderIndex ASC, createdAt DESC';

  db.all(query, params, (err, products) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    res.json(products);
  });
});

// Product reviews routes
app.get('/api/products/:id/reviews', (req, res) => {
  const { id } = req.params;
  db.all(`
    SELECT r.*, u.firstName || ' ' || u.lastName as userName
    FROM product_reviews r
    JOIN users u ON r.userId = u.id
    WHERE r.productId = ?
    ORDER BY r.createdAt DESC
  `, [id], (err, reviews) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    res.json(reviews);
  });
});

// Add review
app.post('/api/products/:id/reviews', authenticateToken, (req, res) => {
  const { id } = req.params;
  const { rating, comment } = req.body;
  const userId = req.user.userId;

  console.log('POST /api/products/:id/reviews', { id, rating, comment, userId });

  if (!rating || !comment) {
    console.log('Missing rating or comment');
    return res.status(400).json({ error: 'Rating and comment are required' });
  }

  // Check if user already has reviews for this product
  db.all('SELECT * FROM product_reviews WHERE userId = ? AND productId = ?', [userId, id], (err, existingReviews) => {
    if (err) {
      console.error('Error checking existing reviews:', err);
      return res.status(500).json({ error: err.message });
    }

    console.log('Existing reviews:', existingReviews);

    if (existingReviews.length >= 2) {
      console.log('User already has 2 reviews for this product');
      return res.status(400).json({ error: 'You have already reviewed this product twice' });
    }

    // Add the review
    console.log('Adding review to database...');
    db.run(`
      INSERT INTO product_reviews (userId, productId, rating, comment, createdAt)
      VALUES (?, ?, ?, ?, datetime('now'))
    `, [userId, id, rating, comment], function(err) {
      if (err) {
        console.error('Error inserting review:', err);
        return res.status(500).json({ error: err.message });
      }
      console.log('Review added successfully, ID:', this.lastID);
      res.status(201).json({ 
        id: this.lastID, 
        message: 'Review added successfully' 
      });
    });
  });
});

// Endpoint pentru ?tergere review
app.delete('/api/products/:productId/reviews/:reviewId', authenticateToken, (req, res) => {
  const { productId, reviewId } = req.params;
  const userId = req.user.userId;
  console.log('DELETE review', { productId, reviewId, userId });
  db.get('SELECT * FROM product_reviews WHERE id = ? AND productId = ? AND userId = ?', [reviewId, productId, userId], (err, review) => {
    console.log('Found review:', review);
    if (err) return res.status(500).json({ error: err.message });
    if (!review) return res.status(404).json({ error: 'Review not found' });
    db.run('DELETE FROM product_reviews WHERE id = ?', [reviewId], function(err) {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ message: 'Review deleted successfully' });
    });
  });
});

// Favorites routes
app.get('/api/favorites', authenticateToken, (req, res) => {
  const userId = req.user.userId;
  
  db.all(`
    SELECT f.*, p.name, p.price, p.discountPrice, p.imageUrl, p.inStock,
      (
        SELECT AVG(rating) FROM product_reviews WHERE productId = p.id
      ) as ratingAvg,
      (
        SELECT COUNT(*) FROM product_reviews WHERE productId = p.id
      ) as reviewsCount
    FROM favorites f
    JOIN products p ON f.productId = p.id
    WHERE f.userId = ? AND p.status = "active"
  `, [userId], (err, favorites) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    res.json(favorites);
  });
});

app.post('/api/favorites', authenticateToken, (req, res) => {
  const { productId } = req.body;
  const userId = req.user.userId;
  
  db.run('INSERT OR IGNORE INTO favorites (userId, productId) VALUES (?, ?)', [userId, productId], (err) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    res.json({ message: 'Added to favorites' });
  });
});

app.delete('/api/favorites/:productId', authenticateToken, (req, res) => {
  const { productId } = req.params;
  const userId = req.user.userId;
  
  db.run('DELETE FROM favorites WHERE userId = ? AND productId = ?', [userId, productId], (err) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    res.json({ message: 'Removed from favorites' });
  });
});
app.get('/api/products/:id', (req, res) => {
  const { id } = req.params;
  
  db.get('SELECT * FROM products WHERE id = ? AND status = "active"', [id], (err, product) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    
    if (!product) {
      return res.status(404).json({ error: 'Product not found' });
    }
    
    res.json(product);
  });
});

// --- CATEGORY ORDER TABLE ---
db.run(`CREATE TABLE IF NOT EXISTS category_order (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  category TEXT UNIQUE NOT NULL,
  orderIndex INTEGER NOT NULL
)`);

// --- SET CATEGORY ORDER ENDPOINT ---
app.post('/api/admin/categories/order', authenticateToken, requireAdmin, (req, res) => {
  const { order } = req.body; // order: ["Soia", "Sare", ...]
  if (!Array.isArray(order)) return res.status(400).json({ error: 'Order must be an array' });
  // Remove all and re-insert
  db.run('DELETE FROM category_order', [], (err) => {
    if (err) return res.status(500).json({ error: err.message });
    const stmt = db.prepare('INSERT INTO category_order (category, orderIndex) VALUES (?, ?)');
    order.forEach((cat, idx) => stmt.run(cat, idx));
    stmt.finalize();
    res.json({ message: 'Category order saved' });
  });
});

// --- GET CATEGORIES IN ORDER ---
app.get('/api/categories', (req, res) => {
  db.all('SELECT category FROM category_order ORDER BY orderIndex ASC', [], (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    if (rows.length > 0) {
      res.json(rows.map(r => r.category));
    } else {
      // fallback: get distinct categories from products
      db.all('SELECT DISTINCT category FROM products', [], (err2, rows2) => {
        if (err2) return res.status(500).json({ error: err2.message });
        res.json(rows2.map(r => r.category));
      });
    }
  });
});

// --- SET PRODUCT ORDER ENDPOINT ---
app.post('/api/admin/products/order', authenticateToken, requireAdmin, (req, res) => {
  const { order } = req.body; // order: [id1, id2, ...]
  if (!Array.isArray(order)) return res.status(400).json({ error: 'Order must be an array' });
  // Update orderIndex for each product
  const stmt = db.prepare('UPDATE products SET orderIndex = ? WHERE id = ?');
  order.forEach((id, idx) => stmt.run(idx, id));
  stmt.finalize();
  res.json({ message: 'Product order saved' });
});

// --- GET PRODUCTS IN ORDER ---
app.get('/api/products', (req, res) => {
  db.all('SELECT * FROM products ORDER BY orderIndex ASC, createdAt DESC', [], (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

// Categories routes
app.get('/api/categories', (req, res) => {
  db.all('SELECT DISTINCT category FROM products WHERE status = "active"', (err, categories) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    res.json(categories.map(c => c.category));
  });
});

// Cart routes
app.get('/api/cart', authenticateToken, (req, res) => {
  const userId = req.user.userId;
  
  db.all(`
    SELECT ci.*, p.name, p.price, p.discountPrice, p.imageUrl, p.inStock
    FROM cart_items ci
    JOIN products p ON ci.productId = p.id
    WHERE ci.userId = ?
  `, [userId], (err, items) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    res.json(items);
  });
});

app.post('/api/cart', authenticateToken, (req, res) => {
  const { productId, quantity } = req.body;
  const userId = req.user.userId;
  
  // Check if item already exists in cart
  db.get('SELECT * FROM cart_items WHERE userId = ? AND productId = ?', [userId, productId], (err, existingItem) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    
    if (existingItem) {
      // Update quantity
      db.run('UPDATE cart_items SET quantity = ? WHERE userId = ? AND productId = ?', 
        [quantity, userId, productId], (err) => {
          if (err) {
            return res.status(500).json({ error: err.message });
          }
          res.json({ message: 'Cart updated successfully' });
        });
    } else {
      // Add new item
      db.run('INSERT INTO cart_items (userId, productId, quantity) VALUES (?, ?, ?)', 
        [userId, productId, quantity], (err) => {
          if (err) {
            return res.status(500).json({ error: err.message });
          }
          res.json({ message: 'Item added to cart' });
        });
    }
  });
});

app.delete('/api/cart/:productId', authenticateToken, (req, res) => {
  const { productId } = req.params;
  const userId = req.user.userId;
  
  db.run('DELETE FROM cart_items WHERE userId = ? AND productId = ?', [userId, productId], (err) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    res.json({ message: 'Item removed from cart' });
  });
});

// Stories routes
app.get('/api/stories', (req, res) => {
  db.all('SELECT * FROM stories WHERE isActive = 1 ORDER BY orderIndex ASC', (err, stories) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    res.json(stories);
  });
});

app.get('/api/admin/stories', authenticateToken, requireAdmin, (req, res) => {
  db.all('SELECT * FROM stories ORDER BY orderIndex ASC', (err, stories) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    res.json(stories);
  });
});

app.post('/api/admin/stories', authenticateToken, requireAdmin, (req, res) => {
  const { name, image, link, bgGradient, title, subtitle, description, personImage, isActive, orderIndex } = req.body;
  
  db.run(`
    INSERT INTO stories (name, image, link, bgGradient, title, subtitle, description, personImage, isActive, orderIndex)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `, [name, image, link, bgGradient, title, subtitle, description, personImage, isActive ? 1 : 0, orderIndex], function(err) {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    
    // Return the created story
    db.get('SELECT * FROM stories WHERE id = ?', [this.lastID], (err, story) => {
      if (err) {
        return res.status(500).json({ error: err.message });
      }
      res.json(story);
    });
  });
});

app.put('/api/admin/stories/:id', authenticateToken, requireAdmin, (req, res) => {
  const { id } = req.params;
  const { name, image, link, bgGradient, title, subtitle, description, personImage, isActive, orderIndex } = req.body;
  
  db.run(`
    UPDATE stories SET 
      name = ?, image = ?, link = ?, bgGradient = ?, title = ?, subtitle = ?, 
      description = ?, personImage = ?, isActive = ?, orderIndex = ?, 
      updatedAt = CURRENT_TIMESTAMP
    WHERE id = ?
  `, [name, image, link, bgGradient, title, subtitle, description, personImage, isActive ? 1 : 0, orderIndex, id], function(err) {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    
    if (this.changes === 0) {
      return res.status(404).json({ error: 'Story not found' });
    }
    
    // Return the updated story
    db.get('SELECT * FROM stories WHERE id = ?', [id], (err, story) => {
      if (err) {
        return res.status(500).json({ error: err.message });
      }
      res.json(story);
    });
  });
});

app.delete('/api/admin/stories/:id', authenticateToken, requireAdmin, (req, res) => {
  const { id } = req.params;
  
  db.run('DELETE FROM stories WHERE id = ?', [id], function(err) {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    
    if (this.changes === 0) {
      return res.status(404).json({ error: 'Story not found' });
    }
    
    res.json({ message: 'Story deleted successfully' });
  });
});

// Orders routes
app.post('/api/orders', authenticateToken, (req, res) => {
  const { items, shippingAddress, paymentMethod, notes } = req.body;
  const userId = req.user.userId;
  const orderNumber = 'ORD-' + Date.now();
  
  // Calculate total amount
  const totalAmount = items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  
  db.run(`
    INSERT INTO orders (userId, orderNumber, totalAmount, shippingAddress, paymentMethod, notes)
    VALUES (?, ?, ?, ?, ?, ?)
  `, [userId, orderNumber, totalAmount, JSON.stringify(shippingAddress), paymentMethod, notes], function(err) {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    
    const orderId = this.lastID;
    
    // Add order items
    const insertItems = items.map(item => {
      return new Promise((resolve, reject) => {
        if (typeof item.price !== 'number' || isNaN(item.price)) {
          console.error('Order item price invalid:', item);
        }
        db.run('INSERT INTO order_items (orderId, productId, quantity, price) VALUES (?, ?, ?, ?)',
          [orderId, item.productId, item.quantity, item.price], (err) => {
            if (err) reject(err);
            else resolve();
          });
      });
    });
    
    Promise.all(insertItems).then(() => {
      // Clear cart
      db.run('DELETE FROM cart_items WHERE userId = ?', [userId], (err) => {
        if (err) {
          console.error('Error clearing cart:', err);
        }
      });
      
      // Create notification for user
      db.run(`
        INSERT INTO notifications (userId, type, title, message)
        VALUES (?, 'success', 'Comanda plasata!', 'Comanda #${orderNumber} a fost plasata cu succes.')
      `, [userId]);
      
      res.json({ 
        orderId, 
        orderNumber, 
        message: 'Comanda plasata cu succes!' 
      });
    }).catch(err => {
      res.status(500).json({ error: err.message });
    });
  });
});

app.get('/api/orders', authenticateToken, (req, res) => {
  const userId = req.user.userId;
  db.all(`
    SELECT o.*, 
           json_group_array(json_object(
             'productId', p.id,
             'name', p.name,
             'quantity', oi.quantity,
             'price', oi.price
           )) as items
    FROM orders o
    JOIN users u ON o.userId = u.id
    LEFT JOIN order_items oi ON o.id = oi.orderId
    LEFT JOIN products p ON oi.productId = p.id
    WHERE o.userId = ?
    GROUP BY o.id
    ORDER BY o.createdAt DESC
  `, [userId], (err, orders) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    // Parse items JSON for fiecare order
    const parsed = orders.map(order => ({
      ...order,
      items: order.items ? JSON.parse(order.items) : []
    }));
    res.json(parsed);
  });
});

// --- ADMIN: List all orders ---
app.get('/api/admin/orders', authenticateToken, requireAdmin, (req, res) => {
  db.all(`
    SELECT o.*, u.email, u.firstName, u.lastName,
           json_group_array(json_object(
             'productId', p.id,
             'name', p.name,
             'quantity', oi.quantity,
             'price', oi.price
           )) as items
    FROM orders o
    JOIN users u ON o.userId = u.id
    LEFT JOIN order_items oi ON o.id = oi.orderId
    LEFT JOIN products p ON oi.productId = p.id
    GROUP BY o.id
    ORDER BY o.createdAt DESC
  `, (err, orders) => {
    if (err) return res.status(500).json({ error: err.message });
    const parsed = orders.map(order => ({
      ...order,
      items: order.items ? JSON.parse(order.items) : []
    }));
    res.json(parsed);
  });
});

// --- ADMIN: List all notifications ---
app.get('/api/admin/notifications', authenticateToken, requireAdmin, (req, res) => {
  db.all('SELECT * FROM notifications ORDER BY createdAt DESC', (err, notifications) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(notifications);
  });
});

// --- ADMIN: Send notification to specific user ---
app.post('/api/admin/notifications', authenticateToken, requireAdmin, (req, res) => {
  const { userId, type, title, message } = req.body;
  
  if (!userId || !title || !message) {
    return res.status(400).json({ error: 'userId, title and message are required' });
  }
  
  db.run(`
    INSERT INTO notifications (userId, type, title, message)
    VALUES (?, ?, ?, ?)
  `, [userId, type || 'info', title, message], function(err) {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    
    res.json({ 
      id: this.lastID,
      message: 'Notification sent successfully' 
    });
  });
});

// --- ADMIN: List all contact messages ---
app.get('/api/admin/messages', authenticateToken, requireAdmin, (req, res) => {
  db.all('SELECT * FROM contact_messages ORDER BY createdAt DESC', (err, messages) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(messages);
  });
});

// Contact form endpoint
app.post('/api/contact', (req, res) => {
  const { name, email, subject, message } = req.body;
  if (!name || !email || !subject || !message) {
    return res.status(400).json({ error: 'All fields are required.' });
  }

  db.run(
    `INSERT INTO contact_messages (name, email, subject, message, status, createdAt) VALUES (?, ?, ?, ?, 'unread', CURRENT_TIMESTAMP)`,
    [name, email, subject, message],
    function (err) {
      if (err) {
        return res.status(500).json({ error: err.message });
      }
      res.json({ message: 'Mesajul a fost trimis cu succes!' });
    }
  );
});

// Admin routes
app.get('/api/admin/dashboard', authenticateToken, requireAdmin, (req, res) => {
  const stats = {};
  db.get('SELECT COUNT(*) as count FROM users WHERE role = "user"', (err, result) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    stats.totalUsers = result.count;
    db.get('SELECT COUNT(*) as count FROM products WHERE status = "active"', (err, result) => {
      if (err) {
        return res.status(500).json({ error: err.message });
      }
      stats.totalProducts = result.count;
      db.get('SELECT COUNT(*) as count, SUM(totalAmount) as revenue FROM orders', (err, result) => {
        if (err) {
          return res.status(500).json({ error: err.message });
        }
        stats.totalOrders = result.count;
        stats.totalRevenue = result.revenue || 0;
        res.json(stats);
      });
    });
  });
});

app.get('/api/admin/users', authenticateToken, requireAdmin, (req, res) => {
  db.all('SELECT id, email, firstName, lastName, role, status, createdAt FROM users ORDER BY createdAt DESC', (err, users) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    res.json(users);
  });
});

app.put('/api/admin/users/:id/status', authenticateToken, requireAdmin, (req, res) => {
  const { id } = req.params;
  const { status } = req.body;
  
  db.run('UPDATE users SET status = ? WHERE id = ?', [status, id], (err) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    res.json({ message: 'User status updated successfully' });
  });
});

// Coupons endpoints
app.get('/api/admin/coupons', authenticateToken, requireAdmin, (req, res) => {
  db.all(`
    SELECT c.*, 
           COALESCE(SUM(cu.discountAmount), 0) as totalDiscountGiven,
           COUNT(cu.id) as actualUsageCount
    FROM coupons c
    LEFT JOIN coupon_usage cu ON c.id = cu.couponId
    GROUP BY c.id
    ORDER BY c.createdAt DESC
  `, (err, coupons) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    res.json(coupons);
  });
});

app.post('/api/admin/coupons', authenticateToken, requireAdmin, (req, res) => {
  const { code, name, description, discountType, discountValue, minimumAmount, maxUses, validFrom, validTo, isActive } = req.body;
  
  if (!code || !name || !discountType || !discountValue || !validFrom || !validTo) {
    return res.status(400).json({ error: 'All required fields must be provided' });
  }

  // Validate discount type
  if (!['percentage', 'fixed'].includes(discountType)) {
    return res.status(400).json({ error: 'Discount type must be percentage or fixed' });
  }

  // Validate percentage value
  if (discountType === 'percentage' && (discountValue < 0 || discountValue > 100)) {
    return res.status(400).json({ error: 'Percentage discount must be between 0 and 100' });
  }

  // Set isActive=1 by default, usedCount=0 by default
  const isActiveValue = typeof isActive === 'undefined' ? 1 : isActive ? 1 : 0;

  db.run(`
    INSERT INTO coupons (code, name, description, discountType, discountValue, minimumAmount, maxUses, validFrom, validTo, isActive, usedCount)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0)
  `, [code.toUpperCase(), name, description, discountType, discountValue, minimumAmount || 0, maxUses, validFrom, validTo, isActiveValue], function(err) {
    if (err) {
      if (err.message.includes('UNIQUE constraint failed')) {
        return res.status(400).json({ error: 'Coupon code already exists' });
      }
      return res.status(500).json({ error: err.message });
    }
    res.json({ id: this.lastID, message: 'Coupon created successfully' });
  });
});

app.put('/api/admin/coupons/:id', authenticateToken, requireAdmin, (req, res) => {
  const { id } = req.params;
  const { name, description, discountType, discountValue, minimumAmount, maxUses, validFrom, validTo, isActive } = req.body;

  db.run(`
    UPDATE coupons 
    SET name = ?, description = ?, discountType = ?, discountValue = ?, 
        minimumAmount = ?, maxUses = ?, validFrom = ?, validTo = ?, 
        isActive = ?, updatedAt = CURRENT_TIMESTAMP
    WHERE id = ?
  `, [name, description, discountType, discountValue, minimumAmount || 0, maxUses, validFrom, validTo, isActive, id], function(err) {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    if (this.changes === 0) {
      return res.status(404).json({ error: 'Coupon not found' });
    }
    res.json({ message: 'Coupon updated successfully' });
  });
});

app.delete('/api/admin/coupons/:id', authenticateToken, requireAdmin, (req, res) => {
  const { id } = req.params;
  
  db.run('DELETE FROM coupons WHERE id = ?', [id], function(err) {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    if (this.changes === 0) {
      return res.status(404).json({ error: 'Coupon not found' });
    }
    res.json({ message: 'Coupon deleted successfully' });
  });
});

// Validate coupon endpoint for checkout
app.post('/api/coupons/validate', authenticateToken, (req, res) => {
  const { code, totalAmount } = req.body;
  const userId = req.user.userId;

  if (!code || totalAmount === undefined) {
    return res.status(400).json({ error: 'Code and total amount are required' });
  }

  db.get(`
    SELECT * FROM coupons 
    WHERE code = ? AND isActive = 1 
    AND validFrom <= CURRENT_TIMESTAMP 
    AND validTo >= CURRENT_TIMESTAMP
  `, [code.toUpperCase()], (err, coupon) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }

    if (!coupon) {
      return res.status(404).json({ error: 'Cupon invalid sau expirat' });
    }

    // Check minimum amount
    if (totalAmount < coupon.minimumAmount) {
      return res.status(400).json({ 
        error: `Suma minima pentru acest cupon este ${coupon.minimumAmount} Lei` 
      });
    }

    // Check usage limit
    if (coupon.maxUses && coupon.usedCount >= coupon.maxUses) {
      return res.status(400).json({ error: 'Cuponul a fost utilizat maximum de ori' });
    }

    // Check if user already used this coupon
    db.get(`
      SELECT id FROM coupon_usage WHERE couponId = ? AND userId = ?
    `, [coupon.id, userId], (err, usage) => {
      if (err) {
        return res.status(500).json({ error: err.message });
      }

      if (usage) {
        return res.status(400).json({ error: 'Ai utilizat deja acest cupon' });
      }

      // Calculate discount
      let discountAmount = 0;
      if (coupon.discountType === 'percentage') {
        discountAmount = (totalAmount * coupon.discountValue) / 100;
      } else {
        discountAmount = Math.min(coupon.discountValue, totalAmount);
      }

      res.json({
        valid: true,
        coupon: {
          id: coupon.id,
          code: coupon.code,
          name: coupon.name,
          discountType: coupon.discountType,
          discountValue: coupon.discountValue
        },
        discountAmount: Math.round(discountAmount * 100) / 100,
        newTotal: Math.max(0, totalAmount - discountAmount)
      });
    });
  });
});

// Apply coupon endpoint (called when order is placed)
app.post('/api/coupons/apply', authenticateToken, (req, res) => {
  const { couponId, orderId, discountAmount } = req.body;
  const userId = req.user.userId;

  db.run(`
    INSERT INTO coupon_usage (couponId, userId, orderId, discountAmount)
    VALUES (?, ?, ?, ?)
  `, [couponId, userId, orderId, discountAmount], function(err) {
    if (err) {
      return res.status(500).json({ error: err.message });
    }

    // Update coupon usage count
    db.run(`
      UPDATE coupons SET usedCount = usedCount + 1 WHERE id = ?
    `, [couponId], (err) => {
      if (err) {
        console.error('Error updating coupon usage count:', err);
      }
    });

    res.json({ message: 'Coupon applied successfully' });
  });
});

// Stripe Checkout endpoint
app.post('/api/create-checkout-session', async (req, res) => {
  const { amount, success_url, cancel_url } = req.body;
  if (!amount || isNaN(amount)) {
    return res.status(400).json({ error: 'Amount is required and must be a number.' });
  }
  try {
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      line_items: [{
        price_data: {
          currency: 'ron',
          product_data: { name: 'Comanda' },
          unit_amount: Math.round(amount * 100),
        },
        quantity: 1,
      }],
      mode: 'payment',
      success_url: success_url || (process.env.FRONTEND_URL || 'http://localhost:5173') + '/success',
      cancel_url: cancel_url || (process.env.FRONTEND_URL || 'http://localhost:5173') + '/cancel',
    });
    res.json({ url: session.url });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Serve uploads statically
app.use('/uploads', express.static(uploadDir));

// Admin file manager routes
app.get('/api/admin/files', authenticateToken, requireAdmin, (req, res) => {
  const folder = req.query.folder || '';
  const dir = path.join(uploadDir, folder);
  
  try {
    if (!fs.existsSync(dir)) {
      return res.json({ folders: [], files: [] });
    }
    
    const items = fs.readdirSync(dir, { withFileTypes: true });
    
    const folders = items
      .filter(i => i.isDirectory())
      .map(i => ({
        name: i.name,
        type: 'folder',
        size: 0,
        createdAt: fs.statSync(path.join(dir, i.name)).birthtime
      }));
    
    const files = items
      .filter(i => i.isFile())
      .map(i => {
        const filePath = path.join(dir, i.name);
        const stats = fs.statSync(filePath);
        const ext = path.extname(i.name).toLowerCase();
        const isImage = ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.svg'].includes(ext);
        
        return {
          name: i.name,
          type: isImage ? 'image' : 'file',
          size: stats.size,
          createdAt: stats.birthtime,
          url: `/uploads/${folder ? folder + '/' : ''}${i.name}`,
          extension: ext
        };
      });
    
    res.json({ folders, files });
  } catch (err) {
    console.error('Error reading directory:', err);
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/admin/files/upload', authenticateToken, requireAdmin, upload.array('files', 10), (req, res) => {
  try {
    console.log('Upload request received');
    console.log('req.body:', req.body);
    console.log('req.files:', req.files);
    
    const folder = req.body.folder || '';
    
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({ error: 'No files uploaded' });
    }
    
    const uploadedFiles = [];
    
    // Move files to the correct folder if specified
    for (const file of req.files) {
      let finalPath = file.path;
      let finalUrl = `/uploads/${file.filename}`;
      
      if (folder) {
        const targetDir = path.join(uploadDir, folder);
        if (!fs.existsSync(targetDir)) {
          fs.mkdirSync(targetDir, { recursive: true });
        }
        
        const newPath = path.join(targetDir, file.filename);
        fs.renameSync(file.path, newPath);
        finalPath = newPath;
        finalUrl = `/uploads/${folder}/${file.filename}`;
      }
      
      uploadedFiles.push({
        name: file.filename,
        originalName: file.originalname,
        url: finalUrl,
        size: file.size
      });
    }
    
    console.log('Upload successful, returning:', uploadedFiles);
    res.json({ files: uploadedFiles });
  } catch (error) {
    console.error('Upload error:', error);
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/admin/files/folder', authenticateToken, requireAdmin, (req, res) => {
  const { folder, name } = req.body;
  const targetDir = path.join(uploadDir, folder || '', name);
  
  try {
    if (fs.existsSync(targetDir)) {
      return res.status(400).json({ error: 'Folder already exists' });
    }
    
    fs.mkdirSync(targetDir, { recursive: true });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/admin/files', authenticateToken, requireAdmin, (req, res) => {
  const { folder, name } = req.body;
  const filePath = path.join(uploadDir, folder || '', name);
  
  try {
    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ error: 'File or folder not found' });
    }
    
    const stats = fs.statSync(filePath);
    if (stats.isDirectory()) {
      fs.rmSync(filePath, { recursive: true, force: true });
    } else {
      fs.unlinkSync(filePath);
    }
    
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/admin/files/rename', authenticateToken, requireAdmin, (req, res) => {
  const { folder, oldName, newName } = req.body;
  const oldPath = path.join(uploadDir, folder || '', oldName);
  const newPath = path.join(uploadDir, folder || '', newName);
  
  try {
    if (!fs.existsSync(oldPath)) {
      return res.status(404).json({ error: 'File or folder not found' });
    }
    
    if (fs.existsSync(newPath)) {
      return res.status(400).json({ error: 'A file or folder with this name already exists' });
    }
    
    fs.renameSync(oldPath, newPath);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/admin/files/move', authenticateToken, requireAdmin, (req, res) => {
  const { srcFolder, name, destFolder } = req.body;
  const srcPath = path.join(uploadDir, srcFolder || '', name);
  const destPath = path.join(uploadDir, destFolder || '', name);
  
  try {
    if (!fs.existsSync(srcPath)) {
      return res.status(404).json({ error: 'File or folder not found' });
    }
    
    if (fs.existsSync(destPath)) {
      return res.status(400).json({ error: 'A file or folder with this name already exists in destination' });
    }
    
    // Ensure destination directory exists
    const destDir = path.dirname(destPath);
    if (!fs.existsSync(destDir)) {
      fs.mkdirSync(destDir, { recursive: true });
    }
    
    fs.renameSync(srcPath, destPath);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// --- REMOVE CHAT LIVE ENDPOINTS ---
// (Au fost eliminate complet endpoint-urile /api/chat/messages ?i orice logica asociata chat-ului live)

// --- ADMIN: Update order status ---
app.put('/api/admin/orders/:id/status', authenticateToken, requireAdmin, (req, res) => {
  const { id } = req.params;
  const { status } = req.body;
  db.run('UPDATE orders SET status = ? WHERE id = ?', [status, id], function(err) {
    if (err) return res.status(500).json({ error: err.message });
    if (this.changes === 0) return res.status(404).json({ error: 'Order not found' });
    res.json({ message: 'Order status updated successfully' });
  });
});

// --- ADMIN: Broadcast notification ---
app.post('/api/admin/notifications/broadcast', authenticateToken, requireAdmin, (req, res) => {
  const { title, message, type } = req.body;
  if (!title || !message) return res.status(400).json({ error: 'Title and message required' });
  db.all('SELECT id FROM users WHERE status = "active"', (err, users) => {
    if (err) return res.status(500).json({ error: err.message });
    const insertMany = users.map(u => new Promise((resolve, reject) => {
      db.run('INSERT INTO notifications (userId, type, title, message) VALUES (?, ?, ?, ?)',
        [u.id, type || 'info', title, message], err => err ? reject(err) : resolve());
    }));
    Promise.all(insertMany)
      .then(() => res.json({ message: 'Broadcast sent' }))
      .catch(e => res.status(500).json({ error: e.message }));
  });
});

// Notifications routes
app.get('/api/notifications', authenticateToken, (req, res) => {
  const userId = req.user.userId;
  
  db.all(`
    SELECT * FROM notifications 
    WHERE userId = ? 
    ORDER BY createdAt DESC 
    LIMIT 50
  `, [userId], (err, notifications) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    res.json(notifications);
  });
});

// Update single notification as read
app.put('/api/notifications/:id/read', authenticateToken, (req, res) => {
  const { id } = req.params;
  const userId = req.user.userId;
  db.run(`
    UPDATE notifications 
    SET isRead = 1
    WHERE id = ? AND userId = ?
  `, [id, userId], function(err) {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    if (this.changes === 0) {
      return res.status(404).json({ error: 'Notification not found' });
    }
    res.json({ message: 'Notification marked as read' });
  });
});

// Mark all notifications as read for a user
app.put('/api/notifications/mark-all-read', authenticateToken, (req, res) => {
  const userId = req.user.userId;
  console.log('DEBUG mark-all-read for userId:', userId);
  db.run(`
    UPDATE notifications 
    SET isRead = 1
    WHERE userId = ? AND isRead = 0
  `, [userId], function(err) {
    if (err) {
      console.error('ERROR mark-all-read:', err);
      return res.status(500).json({ error: err.message });
    }
    res.json({ 
      message: 'All notifications marked as read',
      updatedCount: this.changes 
    });
  });
});

// Delete a specific notification
app.delete('/api/notifications/:id', authenticateToken, (req, res) => {
  const { id } = req.params;
  const userId = req.user.userId;
  
  db.run('DELETE FROM notifications WHERE id = ? AND userId = ?', [id, userId], function(err) {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    
    if (this.changes === 0) {
      return res.status(404).json({ error: 'Notification not found' });
    }
    
    res.json({ message: 'Notification deleted successfully' });
  });
});

// Delete all read notifications for a user
app.delete('/api/notifications/clear-read', authenticateToken, (req, res) => {
  const userId = req.user.userId;
  
  db.run('DELETE FROM notifications WHERE userId = ? AND isRead = 1', [userId], function(err) {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    
    res.json({ 
      message: 'All read notifications cleared',
      deletedCount: this.changes 
    });
  });
});

// Delete all notifications for a user
app.delete('/api/notifications/clear-all', authenticateToken, (req, res) => {
  const userId = req.user.userId;
  
  db.run('DELETE FROM notifications WHERE userId = ?', [userId], function(err) {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    
    res.json({ 
      message: 'All notifications cleared',
      deletedCount: this.changes 
    });
  });
});

// Admin Product Management Endpoints
app.post('/api/admin/products', authenticateToken, requireAdmin, (req, res) => {
  const { name, description, price, discountPrice, category, brand, inStock, imageUrl, tags, featured } = req.body;
  
  if (!name || !description || !price || !category) {
    return res.status(400).json({ error: 'Name, description, price, and category are required' });
  }

  db.run(`
    INSERT INTO products (name, description, price, discountPrice, category, brand, inStock, imageUrl, tags, featured)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `, [name, description, price, discountPrice, category, brand || '', inStock !== false, imageUrl || '', tags || '', featured === true], function(err) {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    res.json({ id: this.lastID, message: 'Product created successfully' });
  });
});

app.put('/api/admin/products/:id', authenticateToken, requireAdmin, (req, res) => {
  const { id } = req.params;
  const { name, description, price, discountPrice, category, brand, inStock, imageUrl, tags, featured } = req.body;

  db.run(`
    UPDATE products 
    SET name = ?, description = ?, price = ?, discountPrice = ?, category = ?, 
        brand = ?, inStock = ?, imageUrl = ?, tags = ?, featured = ?, 
        updatedAt = CURRENT_TIMESTAMP
    WHERE id = ?
  `, [name, description, price, discountPrice, category, brand || '', inStock !== false, imageUrl || '', tags || '', featured === true, id], function(err) {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    if (this.changes === 0) {
      return res.status(404).json({ error: 'Product not found' });
    }
    res.json({ message: 'Product updated successfully' });
  });
});

app.delete('/api/admin/products/:id', authenticateToken, requireAdmin, (req, res) => {
  const { id } = req.params;
  
  db.run('DELETE FROM products WHERE id = ?', [id], function(err) {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    if (this.changes === 0) {
      return res.status(404).json({ error: 'Product not found' });
    }
    res.json({ message: 'Product deleted successfully' });
  });
});

// Start the server
app.listen(PORT, '0.0.0.0', () => {
  console.log(`Server running on http://0.0.0.0:${PORT}`);
  console.log('?? Database initialized and ready');
  console.log('?? Admin login: admin@ecommerce.com / admin123');
});
