"use client"

import type React from "react"
import { Link, useLocation } from "react-router-dom"
import { Package, Heart, ShoppingCart, User, Home } from "lucide-react"
import { useAuth } from "../context/AuthContext"
import { useCart } from "../context/CartContext"

const MobileBottomNavigation: React.FC = () => {
  const location = useLocation()
  const { user } = useAuth()
  const { cartItemsCount } = useCart()

  const navItems = [
    {
      name: "Acasă",
      icon: Home,
      path: "/",
      shortName: "Acasă",
    },
    {
      name: "Toate produsele",
      icon: Package,
      path: "/products",
      shortName: "Produse",
    },
    {
      name: "Favorite",
      icon: Heart,
      path: "/favorites",
      shortName: "Favorite",
    },
    {
      name: "Coș cumpărături",
      icon: ShoppingCart,
      path: "/cart",
      shortName: "Coș",
      showBadge: true,
    },
    {
      name: "Contul meu",
      icon: User,
      path: user ? "/account" : "/login",
      shortName: "Cont",
    },
  ]

  const isActive = (path: string) => {
    if (path === "/") {
      return location.pathname === "/"
    }
    if (path === "/products") {
      return location.pathname === "/products" || location.pathname.startsWith("/products")
    }
    if (path === "/account" || path === "/login") {
      return location.pathname === "/account" || location.pathname === "/login"
    }
    return location.pathname === path
  }

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-md border-t border-sage-200 shadow-2xl z-50 lg:hidden">
      <div className="grid grid-cols-5 h-20">
        {navItems.map((item) => {
          const Icon = item.icon
          const active = isActive(item.path)

          return (
            <Link
              key={item.path}
              to={item.path}
              className={`flex flex-col items-center justify-center px-2 py-2 transition-all duration-200 relative ${
                active ? "text-nature-600 bg-nature-50" : "text-sage-600 hover:text-nature-600 hover:bg-sage-50"
              }`}
            >
              <div className="relative">
                <Icon className={`w-6 h-6 mb-1 transition-colors ${active ? "text-nature-600" : "text-sage-600"}`} />
                {item.showBadge && cartItemsCount > 0 && (
                  <div className="absolute -top-2 -right-2 w-5 h-5 bg-earth-500 text-white text-xs rounded-full flex items-center justify-center animate-pulse font-medium shadow-lg">
                    {cartItemsCount > 99 ? "99+" : cartItemsCount}
                  </div>
                )}
              </div>
              <span
                className={`text-xs font-medium leading-tight text-center transition-colors ${
                  active ? "text-nature-600" : "text-sage-600"
                }`}
              >
                {item.shortName}
              </span>

              {/* Active indicator */}
              {active && (
                <div className="absolute top-0 left-1/2 transform -translate-x-1/2 w-8 h-1 bg-nature-600 rounded-b-full"></div>
              )}
            </Link>
          )
        })}
      </div>
    </div>
  )
}

export default MobileBottomNavigation
