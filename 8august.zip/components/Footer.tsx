import type React from "react"
import { Link } from "react-router-dom"
import { MapPin, Phone, Mail, Facebook, Instagram, Twitter, Youtube, ArrowRight, Heart } from "lucide-react"
import { toAssetUrl } from "../services/api"

const Footer: React.FC = () => {
  return (
    <footer className="bg-gradient-to-br from-sage-900 via-sage-800 to-nature-900 text-white relative overflow-hidden">
      {/* Decorative background elements */}
      <div className="absolute top-0 left-0 w-96 h-96 bg-nature-600/5 rounded-full -translate-x-48 -translate-y-48"></div>
      <div className="absolute bottom-0 right-0 w-80 h-80 bg-earth-600/5 rounded-full translate-x-40 translate-y-40"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 relative z-10">
        {/* Main Footer Content */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          {/* Company Info */}
          <div className="lg:col-span-2">
            <div className="flex items-center space-x-3 mb-6">
              <img
                src={toAssetUrl("uploads/logo.png") || "/placeholder.svg"}
                alt="Magazin Eco"
                className="h-16 w-auto object-contain filter brightness-0 invert"
              />
            </div>
            <p className="text-sage-200 mb-6 leading-relaxed text-lg">
              Sursa ta de încredere pentru produse organice premium: soia, sare și condimente naturale. Dedicați
              calității și sustenabilității pentru o viață mai sănătoasă.
            </p>

            {/* Contact Info */}
            <div className="space-y-4">
              <div className="flex items-start space-x-3">
                <MapPin className="w-5 h-5 text-nature-400 mt-1 flex-shrink-0" />
                <div>
                  <p className="text-sage-200 font-medium">Adresa noastră</p>
                  <p className="text-sage-300 text-sm">DJ248 31, Lunca Cetățuii 707085, Iași, România</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <Phone className="w-5 h-5 text-nature-400 flex-shrink-0" />
                <div>
                  <p className="text-sage-200 font-medium">Telefon</p>
                  <div className="text-sage-300 text-sm">
                    <p>+40 743 159 223</p>
                    <p>+40 744 137 032</p>
                  </div>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <Mail className="w-5 h-5 text-nature-400 flex-shrink-0" />
                <div>
                  <p className="text-sage-200 font-medium">Email</p>
                  <p className="text-sage-300 text-sm">apache_com@yahoo.com</p>
                </div>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-xl font-bold mb-6 text-white">Legături Rapide</h3>
            <ul className="space-y-3">
              {[
                { name: "Toate Produsele", path: "/products" },
                { name: "Contact", path: "/contact" },
                { name: "Contul Meu", path: "/account" },
                { name: "Despre Noi", path: "/about" },
                { name: "Favorite", path: "/favorites" },
                { name: "Coș Cumpărături", path: "/cart" },
              ].map((link) => (
                <li key={link.path}>
                  <Link
                    to={link.path}
                    className="group flex items-center text-sage-300 hover:text-nature-400 transition-colors duration-200"
                  >
                    <ArrowRight className="w-4 h-4 mr-2 opacity-0 group-hover:opacity-100 transform -translate-x-2 group-hover:translate-x-0 transition-all duration-200" />
                    <span className="group-hover:translate-x-1 transition-transform duration-200">{link.name}</span>
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Product Categories */}
          <div>
            <h3 className="text-xl font-bold mb-6 text-white">Categorii Produse</h3>
            <ul className="space-y-3">
              {[
                { name: "Produse din Soia", category: "Soia" },
                { name: "Sare Naturală", category: "Sare" },
                { name: "Condimente Bio", category: "Condimente" },
                { name: "Stafide Premium", category: "Stafide" },
                { name: "Semințe Organice", category: "Seminte" },
              ].map((item) => (
                <li key={item.category}>
                  <Link
                    to={`/products?category=${item.category}`}
                    className="group flex items-center text-sage-300 hover:text-earth-400 transition-colors duration-200"
                  >
                    <ArrowRight className="w-4 h-4 mr-2 opacity-0 group-hover:opacity-100 transform -translate-x-2 group-hover:translate-x-0 transition-all duration-200" />
                    <span className="group-hover:translate-x-1 transition-transform duration-200">{item.name}</span>
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Social Media & Newsletter */}
        <div className="border-t border-sage-700/50 pt-12 mb-12">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Social Media */}
            <div>
              <h3 className="text-xl font-bold mb-6 text-white">Conectează-te cu Noi</h3>
              <div className="flex space-x-4 mb-6">
                {[
                  { icon: Facebook, href: "#", color: "hover:bg-blue-600" },
                  { icon: Instagram, href: "#", color: "hover:bg-pink-600" },
                  { icon: Twitter, href: "#", color: "hover:bg-blue-400" },
                  { icon: Youtube, href: "#", color: "hover:bg-red-600" },
                ].map(({ icon: Icon, href, color }, index) => (
                  <a
                    key={index}
                    href={href}
                    className={`bg-sage-700/50 hover:bg-opacity-80 p-3 rounded-2xl transition-all duration-300 hover:scale-110 group ${color}`}
                  >
                    <Icon className="w-6 h-6 text-sage-300 group-hover:text-white transition-colors" />
                  </a>
                ))}
              </div>

              {/* Sustainability Badge */}
              <div className="bg-nature-600/20 rounded-2xl p-6 border border-nature-600/30">
                <div className="flex items-center mb-3">
                  <Heart className="w-5 h-5 text-nature-400 mr-2" />
                  <h4 className="font-semibold text-nature-300">Angajament pentru Sustenabilitate</h4>
                </div>
                <p className="text-sage-300 text-sm leading-relaxed">
                  Pentru fiecare comandă, plantăm un copac și folosim ambalaje 100% biodegradabile pentru a proteja
                  planeta pentru generațiile viitoare.
                </p>
              </div>
            </div>

            {/* Newsletter */}
            <div>
              <h3 className="text-xl font-bold mb-6 text-white">Newsletter</h3>
              <p className="text-sage-300 mb-6">
                Abonează-te pentru a primi cele mai noi oferte, rețete sănătoase și sfaturi pentru un stil de viață
                natural.
              </p>
              <form className="space-y-4">
                <div className="flex flex-col sm:flex-row gap-3">
                  <input
                    type="email"
                    placeholder="Adresa ta de email"
                    className="flex-1 px-4 py-3 rounded-xl bg-sage-800/50 border border-sage-600 text-white placeholder-sage-400 focus:border-nature-500 focus:ring-2 focus:ring-nature-500/20 transition-all outline-none"
                  />
                  <button
                    type="submit"
                    className="bg-gradient-to-r from-nature-500 to-nature-600 hover:from-nature-600 hover:to-nature-700 text-white font-semibold px-6 py-3 rounded-xl transition-all duration-300 transform hover:scale-105 shadow-lg"
                  >
                    Abonează-te
                  </button>
                </div>
                <p className="text-sage-400 text-xs">Nu spam, doar conținut valoros. Poți să te dezabonezi oricând.</p>
              </form>
            </div>
          </div>
        </div>

        {/* Company Details & Quality Assurance */}
        <div className="border-t border-sage-700/50 pt-12 mb-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Company Details */}
            <div>
              <h4 className="font-bold text-lg mb-4 text-white">Detalii Companie</h4>
              <div className="text-sm text-sage-300 space-y-2">
                <p>
                  <span className="font-medium text-sage-200">Denumire:</span> APACHE COM SRL
                </p>
                <p>
                  <span className="font-medium text-sage-200">CUI:</span> 16431883
                </p>
                <p>
                  <span className="font-medium text-sage-200">Nr. Înregistrare:</span> J22/989/2004
                </p>
                <p>
                  <span className="font-medium text-sage-200">EUID:</span> ROONRC.J22/989/2004
                </p>
              </div>
            </div>

            {/* Quality Assurance */}
            <div>
              <h4 className="font-bold text-lg mb-4 text-white">Garanția Calității</h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm text-sage-300">
                {[
                  "✓ 100% Produse Certificate Organice",
                  "✓ Aprovizionare Echitabilă",
                  "✓ Verificat Non-GMO",
                  "✓ Recoltat Sustenabil",
                  "✓ Testat pentru Calitate",
                  "✓ Garanție de Satisfacție",
                ].map((item, index) => (
                  <div key={index} className="flex items-center">
                    <span className="text-nature-400 mr-2">✓</span>
                    <span>{item.substring(2)}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="border-t border-sage-700/50 pt-8">
          <div className="flex flex-col lg:flex-row justify-between items-center gap-6">
            <p className="text-sage-400 text-sm">&copy; 2025 APACHE COM SRL. Toate drepturile rezervate.</p>
            <div className="flex flex-wrap justify-center gap-6 text-xs text-sage-400">
              <Link to="/privacypolicy" className="hover:text-nature-400 transition-colors duration-200">
                Politica de Confidențialitate
              </Link>
              <Link to="/terms" className="hover:text-nature-400 transition-colors duration-200">
                Termeni și Condiții
              </Link>
              <Link to="/delivery" className="hover:text-nature-400 transition-colors duration-200">
                Politica de Livrare
              </Link>
            </div>
          </div>

          {/* ANPC Logos */}
          <div className="flex flex-col sm:flex-row justify-center items-center gap-8 mt-8 pt-8 border-t border-sage-700/30">
            <a
              href="https://anpc.ro/ce-este-sal/"
              target="_blank"
              rel="noopener noreferrer"
              className="transition-transform hover:scale-105"
            >
              <img
                src={toAssetUrl("uploads/anpc1.png") || "/placeholder.svg"}
                alt="ANPC Banner 1"
                className="h-16 md:h-20 object-contain opacity-80 hover:opacity-100 transition-opacity"
              />
            </a>
            <a href="#" className="transition-transform hover:scale-105">
              <img
                src={toAssetUrl("uploads/anpc2.png") || "/placeholder.svg"}
                alt="ANPC Banner 2"
                className="h-16 md:h-20 object-contain opacity-80 hover:opacity-100 transition-opacity"
              />
            </a>
          </div>
        </div>
      </div>
    </footer>
  )
}

export default Footer
