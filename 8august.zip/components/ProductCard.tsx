"use client"

import type React from "react"
import { useState } from "react"
import { Link } from "react-router-dom"
import { ShoppingCart, Heart, Star, Eye, Zap } from "lucide-react"
import type { Product } from "../types"
import { useAuth } from "../context/AuthContext"
import { cartAPI, productsAPI, toAssetUrl } from "../services/api"
import { useNotifications } from "../hooks/useNotifications"

interface ProductCardProps {
  product: Product
  favoriteIds?: number[]
  viewMode?: "grid" | "grid-mobile" | "list" | "favorites"
}

const ProductCard: React.FC<ProductCardProps> = ({ product, favoriteIds = [], viewMode = "grid" }) => {
  const { isAuthenticated, user } = useAuth()
  const { showSuccess, showError } = useNotifications()
  const [isAddingToCart, setIsAddingToCart] = useState(false)
  const [isFavorite, setIsFavorite] = useState(favoriteIds.includes(product.id))
  const [imageLoaded, setImageLoaded] = useState(false)

  const discountPercentage = product.discountPrice
    ? Math.round(((product.price - product.discountPrice) / product.price) * 100)
    : 0

  const finalPrice = product.discountPrice || product.price

  const handleAddToCart = async (e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()

    if (!isAuthenticated || user?.role !== "user") {
      showError("Autentificare necesară", "Te rugăm să te autentifici ca și client pentru a adăuga produse în coș")
      return
    }

    setIsAddingToCart(true)
    try {
      await cartAPI.addItem(product.id, 1)
      showSuccess("Produs adăugat!", `${product.name} a fost adăugat în coș`)
    } catch (error) {
      console.error("Error adding to cart:", error)
      showError("Eroare", "Nu s-a putut adăuga produsul în coș")
    } finally {
      setIsAddingToCart(false)
    }
  }

  const handleToggleFavorite = async (e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()

    if (!isAuthenticated || user?.role !== "user") {
      showError("Autentificare necesară", "Te rugăm să te autentifici pentru a adăuga la favorite")
      return
    }

    try {
      if (isFavorite) {
        await productsAPI.removeFromFavorites(product.id)
        showSuccess("Eliminat din favorite", "Produsul a fost eliminat din favorite")
      } else {
        await productsAPI.addToFavorites(product.id)
        showSuccess("Adăugat la favorite", "Produsul a fost adăugat la favorite")
      }
      setIsFavorite(!isFavorite)
    } catch (error) {
      console.error("Error toggling favorite:", error)
      showError("Eroare", "Nu s-a putut actualiza lista de favorite")
    }
  }

  const renderRating = () => {
    const rating = product.ratingAvg || 0
    const reviewsCount = product.reviewsCount || 0

    return (
      <div className="flex items-center space-x-1 mb-2">
        <div className="flex items-center">
          {[...Array(5)].map((_, i) => (
            <Star key={i} className={`w-3 h-3 ${i < rating ? "text-yellow-400 fill-current" : "text-gray-300"}`} />
          ))}
        </div>
        {reviewsCount > 0 && <span className="text-xs text-sage-500">({reviewsCount})</span>}
      </div>
    )
  }

  if (viewMode === "list") {
    return (
      <Link to={`/products/${product.id}`} className="group">
        <div className="bg-white rounded-2xl shadow-sm hover:shadow-lg border border-sage-100 overflow-hidden transition-all duration-300 hover:-translate-y-1">
          <div className="flex p-6">
            <div className="relative w-32 h-32 flex-shrink-0 mr-6">
              {!imageLoaded && <div className="absolute inset-0 bg-sage-100 rounded-xl animate-pulse"></div>}
              <img
                src={toAssetUrl(product.imageUrl) || "/placeholder.svg"}
                alt={product.name}
                className={`w-full h-full object-cover rounded-xl transition-opacity duration-300 ${
                  imageLoaded ? "opacity-100" : "opacity-0"
                }`}
                onLoad={() => setImageLoaded(true)}
                loading="lazy"
              />
              {product.featured && (
                <span className="absolute top-2 left-2 bg-nature-500 text-white text-xs px-2 py-1 rounded-full font-medium">
                  Recomandat
                </span>
              )}
              {discountPercentage > 0 && (
                <span className="absolute top-2 right-2 bg-earth-500 text-white text-xs px-2 py-1 rounded-full font-medium">
                  -{discountPercentage}%
                </span>
              )}
            </div>

            <div className="flex-1 flex flex-col justify-between">
              <div>
                <h3 className="font-semibold text-lg text-sage-900 mb-2 group-hover:text-nature-600 transition-colors line-clamp-2">
                  {product.name}
                </h3>
                <p className="text-sm text-sage-600 mb-3 line-clamp-2">{product.description}</p>
                {renderRating()}
                <div className="flex items-center space-x-2 mb-4">
                  <span className="text-2xl font-bold text-sage-900">{finalPrice.toFixed(2)} Lei</span>
                  {product.discountPrice && (
                    <span className="text-lg text-sage-400 line-through">{product.price.toFixed(2)} Lei</span>
                  )}
                </div>
              </div>

              <div className="flex items-center justify-between">
                <span className={`text-sm font-medium ${product.inStock ? "text-green-600" : "text-red-600"}`}>
                  {product.inStock ? "În stoc" : "Indisponibil"}
                </span>

                <div className="flex items-center space-x-2">
                  <button
                    onClick={handleToggleFavorite}
                    className={`p-2 rounded-full transition-colors ${
                      isFavorite ? "text-earth-500 bg-earth-50" : "text-sage-400 hover:text-earth-500 hover:bg-earth-50"
                    }`}
                  >
                    <Heart className={`w-5 h-5 ${isFavorite ? "fill-current" : ""}`} />
                  </button>

                  {product.inStock && (
                    <button
                      onClick={handleAddToCart}
                      disabled={isAddingToCart}
                      className="bg-nature-500 hover:bg-nature-600 text-white p-2 rounded-full transition-colors disabled:opacity-50"
                    >
                      <ShoppingCart className="w-5 h-5" />
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </Link>
    )
  }

  // Grid view (default)
  return (
    <Link to={`/products/${product.id}`} className="group block">
      <div className="bg-white rounded-2xl shadow-sm hover:shadow-xl border border-sage-100 overflow-hidden transition-all duration-300 hover:-translate-y-2 relative">
        {/* Image Container */}
        <div className="relative aspect-square overflow-hidden bg-sage-50">
          {!imageLoaded && <div className="absolute inset-0 bg-sage-100 animate-pulse"></div>}
          <img
            src={toAssetUrl(product.imageUrl) || "/placeholder.svg"}
            alt={product.name}
            className={`w-full h-full object-cover transition-all duration-500 group-hover:scale-110 ${
              imageLoaded ? "opacity-100" : "opacity-0"
            }`}
            onLoad={() => setImageLoaded(true)}
            loading="lazy"
          />

          {/* Badges */}
          <div className="absolute top-3 left-3 flex flex-col gap-2">
            {product.featured && (
              <span className="bg-nature-500 text-white text-xs px-2 py-1 rounded-full font-medium shadow-lg">
                <Zap className="w-3 h-3 inline mr-1" />
                Recomandat
              </span>
            )}
            {discountPercentage > 0 && (
              <span className="bg-earth-500 text-white text-xs px-2 py-1 rounded-full font-medium shadow-lg animate-pulse">
                -{discountPercentage}% OFF
              </span>
            )}
          </div>

          {/* Action Buttons */}
          <div className="absolute top-3 right-3 flex flex-col gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
            <button
              onClick={handleToggleFavorite}
              className={`p-2 rounded-full backdrop-blur-sm transition-all duration-200 ${
                isFavorite
                  ? "bg-earth-500 text-white shadow-lg"
                  : "bg-white/90 text-sage-600 hover:bg-earth-500 hover:text-white shadow-md"
              }`}
            >
              <Heart className={`w-4 h-4 ${isFavorite ? "fill-current" : ""}`} />
            </button>

            <Link
              to={`/products/${product.id}`}
              className="p-2 rounded-full bg-white/90 text-sage-600 hover:bg-nature-500 hover:text-white transition-all duration-200 shadow-md"
              onClick={(e) => e.stopPropagation()}
            >
              <Eye className="w-4 h-4" />
            </Link>
          </div>

          {/* Stock Status */}
          {!product.inStock && (
            <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
              <span className="bg-red-500 text-white px-3 py-1 rounded-full text-sm font-medium">Indisponibil</span>
            </div>
          )}
        </div>

        {/* Content */}
        <div className="p-4">
          <div className="mb-2">
            <span className="text-xs text-nature-600 font-medium bg-nature-50 px-2 py-1 rounded-full">
              {product.category}
            </span>
          </div>

          <h3 className="font-semibold text-sage-900 mb-2 line-clamp-2 group-hover:text-nature-600 transition-colors">
            {product.name}
          </h3>

          <p className="text-sm text-sage-600 mb-3 line-clamp-2">{product.brand}</p>

          {renderRating()}

          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-2">
              <span className="text-xl font-bold text-sage-900">{finalPrice.toFixed(2)} Lei</span>
              {product.discountPrice && (
                <span className="text-sm text-sage-400 line-through">{product.price.toFixed(2)} Lei</span>
              )}
            </div>
          </div>

          {/* Add to Cart Button */}
          {product.inStock && (
            <button
              onClick={handleAddToCart}
              disabled={isAddingToCart}
              className="w-full bg-gradient-to-r from-nature-500 to-nature-600 hover:from-nature-600 hover:to-nature-700 text-white font-medium py-3 rounded-xl transition-all duration-300 transform hover:scale-105 disabled:opacity-50 disabled:transform-none shadow-lg hover:shadow-xl flex items-center justify-center space-x-2"
            >
              <ShoppingCart className="w-4 h-4" />
              <span>{isAddingToCart ? "Se adaugă..." : "Adaugă în coș"}</span>
            </button>
          )}
        </div>
      </div>
    </Link>
  )
}

export default ProductCard
