"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { Link, useLocation } from "react-router-dom"
import { ShoppingCart, User, Menu, X, Bell, Search, Heart } from "lucide-react"
import { useAuth } from "../context/AuthContext"
import { cartAPI, notificationsAPI, productsAPI, toAssetUrl } from "../services/api"
import { useNotifications } from "../hooks/useNotifications"
import type { Product } from "../types"

const Header: React.FC = () => {
  const { user, isAuthenticated, logout } = useAuth()
  const { showSuccess, showInfo, showWarning, showError } = useNotifications()
  const location = useLocation()
  const [cartItemsCount, setCartItemsCount] = useState(0)
  const [unreadNotifications, setUnreadNotifications] = useState(0)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const [showNotifications, setShowNotifications] = useState(false)
  const [notifications, setNotifications] = useState<any[]>([])
  const [searchResults, setSearchResults] = useState<Product[]>([])
  const [showSearchPreview, setShowSearchPreview] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const [isScrolled, setIsScrolled] = useState(false)
  let searchTimeout: NodeJS.Timeout

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20)
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  useEffect(() => {
    if (isAuthenticated && user?.role === "user") {
      fetchCartItems()
      fetchNotifications()
      const interval = setInterval(fetchNotifications, 30000)
      return () => clearInterval(interval)
    }
  }, [isAuthenticated, user])

  useEffect(() => {
    return () => {
      if (searchTimeout) clearTimeout(searchTimeout)
    }
  }, [])

  const fetchCartItems = async () => {
    try {
      const items = await cartAPI.getItems()
      setCartItemsCount(items.reduce((sum, item) => sum + item.quantity, 0))
    } catch (error) {
      console.error("Error fetching cart items:", error)
    }
  }

  const fetchNotifications = async () => {
    try {
      const notificationsData = await notificationsAPI.getAll()
      setNotifications(notificationsData)
      setUnreadNotifications(notificationsData.filter((n: any) => !n.isRead).length)

      const newNotifications = notificationsData.filter(
        (n: any) => !n.isRead && new Date(n.createdAt).getTime() > Date.now() - 60000,
      )

      newNotifications.forEach((notification: any) => {
        switch (notification.type) {
          case "success":
            showSuccess(notification.title, notification.message)
            break
          case "warning":
            showWarning(notification.title, notification.message)
            break
          case "error":
            showError(notification.title, notification.message)
            break
          default:
            showInfo(notification.title, notification.message)
        }
      })
    } catch (error) {
      console.error("Error fetching notifications:", error)
    }
  }

  const markNotificationAsRead = async (notificationId: number) => {
    try {
      await notificationsAPI.markAsRead(notificationId)
      await fetchNotifications()
    } catch (error) {
      console.error("Error marking notification as read:", error)
    }
  }

  const markAllNotificationsAsRead = async () => {
    try {
      await notificationsAPI.markAllAsRead()
      await fetchNotifications()
    } catch (error) {
      console.error("Error marking all notifications as read:", error)
    }
  }

  const handleLogout = () => {
    logout()
    setIsMobileMenuOpen(false)
  }

  const handleSearchInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value)
    setShowSearchPreview(true)
    if (searchTimeout) clearTimeout(searchTimeout)
    const value = e.target.value
    searchTimeout = setTimeout(async () => {
      if (value.trim().length < 2) {
        setSearchResults([])
        return
      }
      try {
        const products = await productsAPI.getAll({ search: value })
        setSearchResults(products.filter((p: Product) => p.name.toLowerCase().includes(value.toLowerCase())))
      } catch {
        setSearchResults([])
      }
    }, 300)
  }

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (searchQuery.trim().length > 0) {
      console.log("Search:", searchQuery)
    }
  }

  const handleSearchBlur = () => {
    setTimeout(() => setShowSearchPreview(false), 200)
  }

  return (
    <header
      className={`sticky top-0 z-50 transition-all duration-300 ${
        isScrolled
          ? "bg-white/95 backdrop-blur-md shadow-lg border-b border-sage-100"
          : "bg-white/90 backdrop-blur-sm shadow-sm border-b border-sage-50"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 lg:h-20">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-3 group">
            <div className="relative">
              <img
                src={toAssetUrl("uploads/logo.png") || "/placeholder.svg"}
                alt="Logo"
                className="h-10 lg:h-12 w-auto object-contain transition-transform group-hover:scale-105"
                style={{ maxWidth: 140 }}
              />
            </div>
          </Link>

          {/* Desktop Search Bar */}
          <form onSubmit={handleSearch} className="hidden lg:flex flex-1 max-w-2xl mx-8">
            <div className="relative w-full">
              <input
                type="text"
                value={searchQuery}
                onChange={handleSearchInput}
                onBlur={handleSearchBlur}
                onFocus={() => setShowSearchPreview(true)}
                placeholder="Caută produse naturale..."
                className="w-full pl-12 pr-4 py-3 text-sage-700 placeholder-sage-400 bg-sage-50 border-2 border-sage-100 rounded-2xl focus:border-nature-500 focus:ring-4 focus:ring-nature-100 focus:bg-white transition-all outline-none"
                autoComplete="off"
              />
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-sage-400 w-5 h-5" />

              {showSearchPreview && searchQuery.trim().length > 0 && (
                <div className="absolute left-0 right-0 mt-2 bg-white border-2 border-sage-100 rounded-2xl shadow-xl z-[100] max-h-96 overflow-y-auto">
                  {searchResults.length === 0 ? (
                    <div className="p-6 text-sage-500 text-center">Niciun produs găsit</div>
                  ) : (
                    searchResults.slice(0, 6).map((product) => (
                      <Link
                        key={product.id}
                        to={`/products/${product.id}`}
                        className="flex items-center gap-4 px-6 py-4 hover:bg-sage-50 transition-colors border-b border-sage-50 last:border-b-0"
                        onClick={() => setShowSearchPreview(false)}
                      >
                        <img
                          src={toAssetUrl(product.imageUrl) || "/placeholder.svg"}
                          alt={product.name}
                          className="w-12 h-12 object-cover rounded-xl border border-sage-200"
                        />
                        <div className="flex-1">
                          <div className="font-medium text-sage-900 text-sm">{product.name}</div>
                          <div className="text-xs text-sage-500">
                            {product.brand} • {product.price} RON
                          </div>
                        </div>
                      </Link>
                    ))
                  )}
                </div>
              )}
            </div>
          </form>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center space-x-8">
            <Link
              to="/products"
              className={`text-sage-600 hover:text-nature-600 font-medium transition-colors duration-200 relative group ${
                location.pathname === "/products" ? "text-nature-600" : ""
              }`}
            >
              Produse
              <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-nature-600 transition-all group-hover:w-full"></span>
            </Link>

            <Link
              to="/contact"
              className={`text-sage-600 hover:text-nature-600 font-medium transition-colors duration-200 relative group ${
                location.pathname === "/contact" ? "text-nature-600" : ""
              }`}
            >
              Contact
              <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-nature-600 transition-all group-hover:w-full"></span>
            </Link>

            {isAuthenticated ? (
              <>
                {user?.role === "admin" ? (
                  <Link
                    to="/admin"
                    className="text-sage-600 hover:text-nature-600 font-medium transition-colors duration-200"
                  >
                    Panou Admin
                  </Link>
                ) : (
                  <>
                    {/* Favorites */}
                    <Link
                      to="/favorites"
                      className="relative text-sage-600 hover:text-earth-500 transition-colors duration-200 group"
                    >
                      <div className="p-2 rounded-xl hover:bg-sage-50 transition-colors duration-200">
                        <Heart className="w-6 h-6" />
                      </div>
                    </Link>

                    {/* Cart */}
                    <Link
                      to="/cart"
                      className="relative text-sage-600 hover:text-nature-600 transition-colors duration-200 group"
                    >
                      <div className="p-2 rounded-xl hover:bg-sage-50 transition-colors duration-200">
                        <ShoppingCart className="w-6 h-6" />
                        {cartItemsCount > 0 && (
                          <span className="absolute -top-1 -right-1 bg-earth-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center animate-pulse font-medium">
                            {cartItemsCount > 99 ? "99+" : cartItemsCount}
                          </span>
                        )}
                      </div>
                    </Link>

                    {/* Notifications */}
                    <div className="relative">
                      <button
                        onClick={() => setShowNotifications(!showNotifications)}
                        className="relative text-sage-600 hover:text-nature-600 transition-colors duration-200"
                      >
                        <div className="p-2 rounded-xl hover:bg-sage-50 transition-colors duration-200">
                          <Bell className="w-6 h-6" />
                          {unreadNotifications > 0 && (
                            <span className="absolute -top-1 -right-1 bg-earth-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center animate-pulse font-medium">
                              {unreadNotifications > 99 ? "99+" : unreadNotifications}
                            </span>
                          )}
                        </div>
                      </button>

                      {showNotifications && (
                        <div className="absolute right-0 mt-2 w-80 bg-white rounded-2xl shadow-xl border-2 border-sage-100 z-50">
                          <div className="p-4 border-b border-sage-100">
                            <div className="flex items-center justify-between">
                              <h3 className="font-semibold text-sage-900">Notificări</h3>
                              {notifications.length > 0 && (
                                <button
                                  onClick={markAllNotificationsAsRead}
                                  className="text-sm text-nature-600 hover:text-nature-700 font-medium"
                                >
                                  Marchează toate
                                </button>
                              )}
                            </div>
                          </div>
                          <div className="max-h-96 overflow-y-auto">
                            {notifications.length === 0 ? (
                              <div className="p-6 text-center text-sage-500">Nicio notificare</div>
                            ) : (
                              notifications.slice(0, 5).map((notification) => (
                                <div
                                  key={notification.id}
                                  className={`p-4 border-b border-sage-50 hover:bg-sage-25 cursor-pointer transition-colors ${
                                    !notification.isRead ? "bg-nature-25" : ""
                                  }`}
                                  onClick={() => markNotificationAsRead(notification.id)}
                                >
                                  <div className="flex items-start space-x-3">
                                    <div
                                      className={`w-2 h-2 rounded-full mt-2 ${
                                        !notification.isRead ? "bg-nature-600" : "bg-sage-300"
                                      }`}
                                    ></div>
                                    <div className="flex-1">
                                      <h4 className="font-medium text-sage-900 text-sm">{notification.title}</h4>
                                      <p className="text-sage-600 text-sm mt-1">{notification.message}</p>
                                      <p className="text-sage-400 text-xs mt-2">
                                        {new Date(notification.createdAt).toLocaleString("ro-RO")}
                                      </p>
                                    </div>
                                  </div>
                                </div>
                              ))
                            )}
                          </div>
                          {notifications.length > 5 && (
                            <div className="p-4 border-t border-sage-100">
                              <Link
                                to="/account"
                                className="text-nature-600 hover:text-nature-700 text-sm font-medium"
                                onClick={() => setShowNotifications(false)}
                              >
                                Vezi toate notificările
                              </Link>
                            </div>
                          )}
                        </div>
                      )}
                    </div>

                    {/* User Account */}
                    <Link to="/account" className="text-sage-600 hover:text-nature-600 transition-colors duration-200">
                      <div className="p-2 rounded-xl hover:bg-sage-50 transition-colors duration-200">
                        <User className="w-6 h-6" />
                      </div>
                    </Link>
                  </>
                )}

                <button
                  onClick={handleLogout}
                  className="text-sage-600 hover:text-earth-600 font-medium transition-colors duration-200 px-4 py-2 rounded-xl hover:bg-earth-50"
                >
                  Deconectare
                </button>
              </>
            ) : (
              <>
                <Link
                  to="/login"
                  className="text-sage-600 hover:text-nature-600 font-medium transition-colors duration-200 px-4 py-2 rounded-xl hover:bg-nature-50"
                >
                  Conectare
                </Link>
                <Link
                  to="/register"
                  className="bg-gradient-to-r from-nature-500 to-nature-600 hover:from-nature-600 hover:to-nature-700 text-white font-medium px-6 py-2 rounded-xl transition-all duration-300 transform hover:scale-105 shadow-lg"
                >
                  Înregistrare
                </Link>
              </>
            )}
          </div>

          {/* Mobile menu button */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="lg:hidden text-sage-600 p-2 rounded-xl hover:bg-sage-50 transition-colors duration-200"
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile menu */}
        {isMobileMenuOpen && (
          <div className="lg:hidden absolute top-full left-0 right-0 bg-white shadow-xl border-t border-sage-100 z-40">
            <div className="px-4 py-6 space-y-4">
              {/* Mobile Search Bar */}
              <form onSubmit={handleSearch} className="mb-6">
                <div className="relative">
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={handleSearchInput}
                    placeholder="Caută produse naturale..."
                    className="w-full pl-10 pr-4 py-3 border-2 border-sage-200 rounded-2xl focus:ring-2 focus:ring-nature-500 focus:border-nature-500 text-sage-700 placeholder-sage-400 transition-all outline-none"
                    autoComplete="off"
                  />
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-sage-400 w-5 h-5" />
                </div>
              </form>

              {/* Mobile Navigation Links */}
              <div className="space-y-2">
                <Link
                  to="/products"
                  className="flex items-center py-3 px-4 text-sage-700 hover:text-nature-600 hover:bg-nature-50 font-medium rounded-xl transition-colors duration-200"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  Produse
                </Link>

                <Link
                  to="/contact"
                  className="flex items-center py-3 px-4 text-sage-700 hover:text-nature-600 hover:bg-nature-50 font-medium rounded-xl transition-colors duration-200"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  Contact
                </Link>

                {isAuthenticated ? (
                  <>
                    {user?.role === "admin" ? (
                      <Link
                        to="/admin"
                        className="flex items-center py-3 px-4 text-sage-700 hover:text-nature-600 hover:bg-nature-50 font-medium rounded-xl transition-colors duration-200"
                        onClick={() => setIsMobileMenuOpen(false)}
                      >
                        Panou Admin
                      </Link>
                    ) : (
                      <>
                        <Link
                          to="/cart"
                          className="flex items-center py-3 px-4 text-sage-700 hover:text-nature-600 hover:bg-nature-50 font-medium rounded-xl transition-colors duration-200"
                          onClick={() => setIsMobileMenuOpen(false)}
                        >
                          <ShoppingCart className="w-5 h-5 mr-3" />
                          Coș ({cartItemsCount})
                        </Link>
                        <Link
                          to="/account"
                          className="flex items-center py-3 px-4 text-sage-700 hover:text-nature-600 hover:bg-nature-50 font-medium rounded-xl transition-colors duration-200"
                          onClick={() => setIsMobileMenuOpen(false)}
                        >
                          <User className="w-5 h-5 mr-3" />
                          Contul Meu
                        </Link>
                        <Link
                          to="/favorites"
                          className="flex items-center py-3 px-4 text-sage-700 hover:text-nature-600 hover:bg-nature-50 font-medium rounded-xl transition-colors duration-200"
                          onClick={() => setIsMobileMenuOpen(false)}
                        >
                          <Heart className="w-5 h-5 mr-3" />
                          Preferate
                        </Link>
                        <button
                          onClick={() => setShowNotifications(!showNotifications)}
                          className="flex items-center py-3 px-4 text-sage-700 hover:text-nature-600 hover:bg-nature-50 font-medium rounded-xl transition-colors duration-200 w-full text-left"
                        >
                          <Bell className="w-5 h-5 mr-3" />
                          Notificări ({unreadNotifications})
                        </button>
                      </>
                    )}
                    <button
                      onClick={handleLogout}
                      className="flex items-center py-3 px-4 text-earth-600 hover:text-earth-700 hover:bg-earth-50 font-medium rounded-xl transition-colors duration-200 w-full text-left"
                    >
                      Deconectare
                    </button>
                  </>
                ) : (
                  <>
                    <Link
                      to="/login"
                      className="flex items-center py-3 px-4 text-sage-700 hover:text-nature-600 hover:bg-nature-50 font-medium rounded-xl transition-colors duration-200"
                      onClick={() => setIsMobileMenuOpen(false)}
                    >
                      Conectare
                    </Link>
                    <Link
                      to="/register"
                      className="flex items-center py-3 px-4 bg-gradient-to-r from-nature-500 to-nature-600 text-white hover:from-nature-600 hover:to-nature-700 font-medium rounded-xl transition-all duration-300 justify-center shadow-lg"
                      onClick={() => setIsMobileMenuOpen(false)}
                    >
                      Înregistrare
                    </Link>
                  </>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </header>
  )
}

export default Header
