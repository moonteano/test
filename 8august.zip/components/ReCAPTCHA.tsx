import React from 'react';

declare global {
  interface Window {
    grecaptcha?: any;
  }
}

const SITE_KEY = 'YOUR_RECAPTCHA_SITE_KEY'; // Replace with your actual site key

const ReCAPTCHA: React.FC<{ onChange: (token: string) => void }> = ({ onChange }) => {
  React.useEffect(() => {
    if (!window.grecaptcha) {
      const script = document.createElement('script');
      script.src = 'https://www.google.com/recaptcha/api.js?render=explicit';
      script.async = true;
      document.body.appendChild(script);
    }
  }, []);

  React.useEffect(() => {
    if (window.grecaptcha) {
      window.grecaptcha.ready(() => {
        window.grecaptcha.render('recaptcha-container', {
          sitekey: SITE_KEY,
          callback: onChange,
        });
      });
    }
  }, [onChange]);

  return <div id="recaptcha-container" className="my-4" />;
};

export default ReCAPTCHA;
