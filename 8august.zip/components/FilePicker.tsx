import React, { useState, useEffect } from 'react';
import { X, Folder, FileImage, Upload, Search } from 'lucide-react';
import { fileAPI, toAssetUrl } from '../services/api';

interface FileItem {
  name: string;
  type: 'file' | 'image' | 'folder';
  size?: number;
  createdAt?: string;
  url?: string;
  extension?: string;
}

interface FilePickerProps {
  isOpen: boolean;
  onClose: () => void;
  onSelect: (file: FileItem) => void;
  title?: string;
  allowedTypes?: string[];
}

const FilePicker: React.FC<FilePickerProps> = ({ 
  isOpen, 
  onClose, 
  onSelect, 
  title = "Select Image" 
}) => {
  const [files, setFiles] = useState<FileItem[]>([]);
  const [folders, setFolders] = useState<FileItem[]>([]);
  const [currentFolder, setCurrentFolder] = useState('');
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  const pathSegments = currentFolder ? currentFolder.split('/').filter(Boolean) : [];

  useEffect(() => {
    if (isOpen) {
      fetchFiles();
    }
  }, [isOpen, currentFolder]);

  const fetchFiles = async () => {
    setLoading(true);
    try {
      const response = await fileAPI.list(currentFolder);
      
      // Filter only image files
      const imageFiles = (response.files || []).filter((file: FileItem) => 
        file.type === 'image' || /\.(jpg|jpeg|png|gif|webp|svg)$/i.test(file.name)
      );
      
      setFiles(imageFiles);
      setFolders(response.folders || []);
    } catch (error) {
      console.error('Error fetching files:', error);
      setFiles([]);
      setFolders([]);
    } finally {
      setLoading(false);
    }
  };

  const navigateToFolder = (folderName: string) => {
    const newPath = currentFolder ? `${currentFolder}/${folderName}` : folderName;
    setCurrentFolder(newPath);
  };

  const navigateToPath = (index: number) => {
    const newPath = pathSegments.slice(0, index + 1).join('/');
    setCurrentFolder(newPath);
  };

  const goBack = () => {
    const parentPath = pathSegments.slice(0, -1).join('/');
    setCurrentFolder(parentPath);
  };

  const handleFileSelect = (file: FileItem) => {
    if (file.url) {
      onSelect({
        ...file,
        url: file.url // Use relative URL, toAssetUrl will be applied when displaying
      });
      onClose();
    }
  };

  const filteredFiles = files.filter(file =>
    file.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg w-full max-w-4xl max-h-[80vh] m-4 flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b">
          <h2 className="text-xl font-semibold text-gray-900">{title}</h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Breadcrumbs */}
        <div className="px-6 py-4 border-b bg-gray-50">
          <div className="flex items-center space-x-2 text-sm">
            <button
              onClick={() => setCurrentFolder('')}
              className="text-blue-600 hover:text-blue-800 font-medium"
            >
              Home
            </button>
            {pathSegments.map((segment, index) => (
              <React.Fragment key={index}>
                <span className="text-gray-400">/</span>
                <button
                  onClick={() => navigateToPath(index)}
                  className="text-blue-600 hover:text-blue-800 font-medium"
                >
                  {segment}
                </button>
              </React.Fragment>
            ))}
          </div>
          
          {currentFolder && (
            <button
              onClick={goBack}
              className="mt-2 text-gray-600 hover:text-gray-800 text-sm"
            >
              ← Back
            </button>
          )}
        </div>

        {/* Search */}
        <div className="px-6 py-4 border-b">
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Search images..."
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-auto p-6">
          {loading ? (
            <div className="flex items-center justify-center h-32">
              <div className="animate-spin w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full"></div>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {/* Folders */}
              {folders.map((folder) => (
                <div
                  key={folder.name}
                  className="group relative bg-gray-50 rounded-lg p-3 hover:bg-gray-100 cursor-pointer border-2 border-transparent hover:border-gray-200 transition-all"
                  onClick={() => navigateToFolder(folder.name)}
                >
                  <div className="aspect-square mb-2 bg-gray-100 rounded-lg flex items-center justify-center">
                    <Folder className="w-12 h-12 text-blue-500" />
                  </div>
                  <div className="text-xs font-medium text-gray-900 truncate text-center" title={folder.name}>
                    {folder.name}
                  </div>
                </div>
              ))}

              {/* Image Files */}
              {filteredFiles.map((file) => (
                <div
                  key={file.name}
                  className="group relative bg-gray-50 rounded-lg p-3 hover:bg-gray-100 cursor-pointer border-2 border-transparent hover:border-blue-300 transition-all"
                  onClick={() => handleFileSelect(file)}
                >
                  <div className="aspect-square mb-2 bg-gray-100 rounded-lg flex items-center justify-center overflow-hidden">
                    {file.url ? (
                      <img
                        src={toAssetUrl(file.url)}
                        alt={file.name}
                        className="w-full h-full object-cover rounded"
                        onError={(e) => {
                          const target = e.target as HTMLImageElement;
                          target.style.display = 'none';
                          const parent = target.parentElement;
                          if (parent) {
                            parent.innerHTML = '<div class="flex items-center justify-center w-full h-full"><svg class="w-6 h-6 text-gray-400" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2H4zm12 12H4l4-8 3 6 2-4 3 6z" clip-rule="evenodd" /></svg></div>';
                          }
                        }}
                      />
                    ) : (
                      <FileImage className="w-12 h-12 text-gray-400" />
                    )}
                  </div>
                  
                  <div className="text-xs font-medium text-gray-900 truncate text-center" title={file.name}>
                    {file.name}
                  </div>
                  
                  {/* Select overlay */}
                  <div className="absolute inset-0 bg-blue-500 bg-opacity-0 hover:bg-opacity-10 rounded-lg transition-all group-hover:bg-opacity-20 flex items-center justify-center">
                    <div className="opacity-0 group-hover:opacity-100 bg-blue-600 text-white px-2 py-1 rounded text-xs font-medium">
                      Select
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Empty state */}
          {!loading && folders.length === 0 && filteredFiles.length === 0 && (
            <div className="text-center py-12">
              <Upload className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500 mb-2">No images found in this folder</p>
              <p className="text-sm text-gray-400">
                {searchTerm ? 'Try adjusting your search terms' : 'Upload some images to get started'}
              </p>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t bg-gray-50 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 text-gray-600 hover:text-gray-800"
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
};

export default FilePicker;
