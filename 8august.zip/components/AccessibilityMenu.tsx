"use client"

import type React from "react"
import { useState, useEffect } from "react"

const AccessibilityMenu: React.FC = () => {
  const [open, setOpen] = useState(false)
  const [fontSize, setFontSize] = useState(1)
  const [underlineLinks, setUnderlineLinks] = useState(false)
  const [underlineTitles, setUnderlineTitles] = useState(false)
  const [disableAnimations, setDisableAnimations] = useState(false)
  const [colorMode, setColorMode] = useState<"normal" | "bw" | "contrast" | "invert">("normal")
  const [cursor, setCursor] = useState<"default" | "big-light" | "big-dark">("default")

  // Apply accessibility settings
  useEffect(() => {
    document.body.style.fontSize = `${fontSize * 100}%`
  }, [fontSize])

  useEffect(() => {
    document.body.classList.toggle("underline-links", underlineLinks)
    document.body.classList.toggle("underline-titles", underlineTitles)
    document.body.classList.toggle("disable-animations", disableAnimations)
    document.body.classList.remove("bw", "contrast", "invert")
    if (colorMode !== "normal") document.body.classList.add(colorMode)
    document.body.classList.remove("cursor-big-light", "cursor-big-dark")
    if (cursor === "big-light") document.body.classList.add("cursor-big-light")
    if (cursor === "big-dark") document.body.classList.add("cursor-big-dark")
  }, [underlineLinks, underlineTitles, disableAnimations, colorMode, cursor])

  const reset = () => {
    setFontSize(1)
    setUnderlineLinks(false)
    setUnderlineTitles(false)
    setDisableAnimations(false)
    setColorMode("normal")
    setCursor("default")
  }

  // Keyboard shortcuts
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.altKey && e.key.toLowerCase() === "l") setUnderlineLinks((v) => !v)
      if (e.altKey && e.key.toLowerCase() === "t") setUnderlineTitles((v) => !v)
      if (e.altKey && e.key.toLowerCase() === "a") setDisableAnimations((v) => !v)
      if (e.ctrlKey && e.key.toLowerCase() === "b") setColorMode((m) => (m === "bw" ? "normal" : "bw"))
      if (e.ctrlKey && e.key === "+") setColorMode((m) => (m === "contrast" ? "normal" : "contrast"))
      if (e.ctrlKey && e.key === "/") setColorMode((m) => (m === "invert" ? "normal" : "invert"))
      if (e.ctrlKey && e.key === "[") setCursor((c) => (c === "big-light" ? "default" : "big-light"))
      if (e.ctrlKey && e.key === "]") setCursor((c) => (c === "big-dark" ? "default" : "big-dark"))
    }
    window.addEventListener("keydown", handler)
    return () => window.removeEventListener("keydown", handler)
  }, [])

  return (
    <>
      <button
        className="fixed bottom-6 right-6 z-50 bg-sage-800 hover:bg-sage-900 text-white rounded-full w-14 h-14 flex items-center justify-center shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:scale-110 focus:outline-none focus:ring-4 focus:ring-sage-300"
        aria-label="Meniu de accesibilitate"
        onClick={() => setOpen(!open)}
      >
        <span role="img" aria-label="accesibilitate" className="text-2xl">
          ♿
        </span>
      </button>

      {open && (
        <div className="fixed inset-0 z-40 flex items-center justify-center bg-black/50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 bg-white rounded-t-2xl border-b border-sage-200 p-6">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-bold text-sage-900">Meniu Accesibilitate</h2>
                <button
                  className="text-sage-400 hover:text-sage-600 p-2 rounded-full hover:bg-sage-100 transition-colors"
                  onClick={() => setOpen(false)}
                >
                  <span className="text-2xl">&times;</span>
                </button>
              </div>
            </div>

            <div className="p-6 space-y-6">
              {/* Quick Actions */}
              <div className="flex gap-3">
                <button
                  className="flex-1 bg-sage-100 hover:bg-sage-200 text-sage-800 font-medium py-3 px-4 rounded-xl transition-colors text-sm"
                  onClick={reset}
                >
                  Resetează
                </button>
                <button
                  className="flex-1 bg-sage-800 hover:bg-sage-900 text-white font-medium py-3 px-4 rounded-xl transition-colors text-sm"
                  onClick={() => setOpen(false)}
                >
                  Închide
                </button>
              </div>

              {/* Font Size */}
              <div className="space-y-3">
                <h3 className="font-semibold text-sage-900">Dimensiune Font</h3>
                <div className="flex items-center justify-between bg-sage-50 rounded-xl p-4">
                  <span className="text-sm text-sage-700">Ajustează mărimea textului</span>
                  <div className="flex items-center gap-3">
                    <button
                      className="w-8 h-8 bg-white border border-sage-300 rounded-lg flex items-center justify-center hover:bg-sage-100 transition-colors"
                      onClick={() => setFontSize((f) => Math.max(0.7, f - 0.1))}
                    >
                      -
                    </button>
                    <span className="text-sm font-medium w-12 text-center">{Math.round(fontSize * 100)}%</span>
                    <button
                      className="w-8 h-8 bg-white border border-sage-300 rounded-lg flex items-center justify-center hover:bg-sage-100 transition-colors"
                      onClick={() => setFontSize((f) => Math.min(2, f + 0.1))}
                    >
                      +
                    </button>
                  </div>
                </div>
              </div>

              {/* Content Adjustments */}
              <div className="space-y-3">
                <h3 className="font-semibold text-sage-900">Ajustări Conținut</h3>
                <div className="space-y-3">
                  {[
                    {
                      label: "Subliniază linkurile",
                      state: underlineLinks,
                      setState: setUnderlineLinks,
                      shortcut: "Alt + L",
                    },
                    {
                      label: "Subliniază titlurile",
                      state: underlineTitles,
                      setState: setUnderlineTitles,
                      shortcut: "Alt + T",
                    },
                    {
                      label: "Dezactivează animațiile",
                      state: disableAnimations,
                      setState: setDisableAnimations,
                      shortcut: "Alt + A",
                    },
                  ].map(({ label, state, setState, shortcut }) => (
                    <div key={label} className="flex items-center justify-between bg-sage-50 rounded-xl p-4">
                      <div>
                        <span className="text-sm text-sage-700">{label}</span>
                        <div className="text-xs text-sage-500 mt-1">{shortcut}</div>
                      </div>
                      <button
                        className={`w-12 h-6 rounded-full transition-colors ${state ? "bg-nature-500" : "bg-sage-300"}`}
                        onClick={() => setState(!state)}
                      >
                        <div
                          className={`w-5 h-5 bg-white rounded-full shadow-sm transition-transform ${
                            state ? "translate-x-6" : "translate-x-0.5"
                          }`}
                        ></div>
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Color Adjustments */}
              <div className="space-y-3">
                <h3 className="font-semibold text-sage-900">Ajustări Culori</h3>
                <div className="space-y-3">
                  {[
                    { label: "Alb-negru", mode: "bw", shortcut: "Ctrl + B" },
                    { label: "Contrast crescut", mode: "contrast", shortcut: "Ctrl + +" },
                    { label: "Inversează culorile", mode: "invert", shortcut: "Ctrl + /" },
                  ].map(({ label, mode, shortcut }) => (
                    <div key={mode} className="flex items-center justify-between bg-sage-50 rounded-xl p-4">
                      <div>
                        <span className="text-sm text-sage-700">{label}</span>
                        <div className="text-xs text-sage-500 mt-1">{shortcut}</div>
                      </div>
                      <button
                        className={`w-12 h-6 rounded-full transition-colors ${
                          colorMode === mode ? "bg-nature-500" : "bg-sage-300"
                        }`}
                        onClick={() => setColorMode(colorMode === mode ? "normal" : (mode as any))}
                      >
                        <div
                          className={`w-5 h-5 bg-white rounded-full shadow-sm transition-transform ${
                            colorMode === mode ? "translate-x-6" : "translate-x-0.5"
                          }`}
                        ></div>
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Cursor Adjustments */}
              <div className="space-y-3">
                <h3 className="font-semibold text-sage-900">Ajustări Cursor</h3>
                <div className="space-y-3">
                  {[
                    { label: "Cursor mare deschis", mode: "big-light", shortcut: "Ctrl + [" },
                    { label: "Cursor mare închis", mode: "big-dark", shortcut: "Ctrl + ]" },
                  ].map(({ label, mode, shortcut }) => (
                    <div key={mode} className="flex items-center justify-between bg-sage-50 rounded-xl p-4">
                      <div>
                        <span className="text-sm text-sage-700">{label}</span>
                        <div className="text-xs text-sage-500 mt-1">{shortcut}</div>
                      </div>
                      <button
                        className={`w-12 h-6 rounded-full transition-colors ${
                          cursor === mode ? "bg-nature-500" : "bg-sage-300"
                        }`}
                        onClick={() => setCursor(cursor === mode ? "default" : (mode as any))}
                      >
                        <div
                          className={`w-5 h-5 bg-white rounded-full shadow-sm transition-transform ${
                            cursor === mode ? "translate-x-6" : "translate-x-0.5"
                          }`}
                        ></div>
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  )
}

export default AccessibilityMenu
