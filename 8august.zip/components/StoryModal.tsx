"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { Link } from "react-router-dom"
import { ChevronLeft, ChevronRight, X } from "lucide-react"
import { toAssetUrl } from "../services/api"

interface StoryModalProps {
  selectedStory: number
  storyCategories: any[]
  onClose: () => void
}

const StoryModal: React.FC<StoryModalProps> = ({ selectedStory, storyCategories, onClose }) => {
  const [storyProgress, setStoryProgress] = useState(0)

  const currentIndex = storyCategories.findIndex((cat) => cat.id === selectedStory)
  const story = storyCategories[currentIndex]

  useEffect(() => {
    setStoryProgress(0)
    const duration = 4000
    const interval = 50
    const increment = (interval / duration) * 100

    const timer = setInterval(() => {
      setStoryProgress((prev) => {
        if (prev >= 100) {
          const nextIndex = (currentIndex + 1) % storyCategories.length
          if (nextIndex === 0) {
            onClose()
            return 0
          }
          return 0
        }
        return prev + increment
      })
    }, interval)

    return () => clearInterval(timer)
  }, [selectedStory, currentIndex, storyCategories.length, onClose])

  const goToNextStory = () => {
    const nextIndex = (currentIndex + 1) % storyCategories.length
    if (nextIndex === 0) {
      onClose()
    }
  }

  const goToPrevStory = () => {
    const prevIndex = (currentIndex - 1 + storyCategories.length) % storyCategories.length
    // Handle previous story logic
  }

  if (!story) return null

  return (
    <div className="fixed inset-0 bg-black bg-opacity-90 flex items-center justify-center z-50 p-4">
      <div className="relative w-full max-w-sm h-full max-h-[90vh]">
        <div className={`${story.bgGradient} rounded-3xl overflow-hidden h-full relative shadow-2xl`}>
          {/* Progress bars */}
          <div className="absolute top-4 left-4 right-4 z-20 flex gap-1">
            {storyCategories.map((_, index) => (
              <div key={index} className="flex-1 h-1 bg-white bg-opacity-30 rounded-full overflow-hidden">
                <div
                  className="h-full bg-white transition-all duration-100"
                  style={{ width: index === currentIndex ? `${storyProgress}%` : index < currentIndex ? "100%" : "0%" }}
                />
              </div>
            ))}
          </div>

          {/* Navigation buttons */}
          <button
            onClick={goToPrevStory}
            className="absolute left-4 top-1/2 transform -translate-y-1/2 z-20 w-10 h-10 bg-black bg-opacity-50 rounded-full hidden sm:flex items-center justify-center text-white hover:bg-opacity-70"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>

          <button
            onClick={goToNextStory}
            className="absolute right-4 top-1/2 transform -translate-y-1/2 z-20 w-10 h-10 bg-black bg-opacity-50 rounded-full hidden sm:flex items-center justify-center text-white hover:bg-opacity-70"
          >
            <ChevronRight className="w-6 h-6" />
          </button>

          {/* Close button */}
          <button
            onClick={onClose}
            className="absolute top-16 right-4 z-20 w-8 h-8 bg-black bg-opacity-50 rounded-full flex items-center justify-center text-white hover:bg-opacity-70"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Story title */}
          <div className="absolute top-4 left-4 z-20">
            <span className="text-white text-sm font-medium bg-black bg-opacity-30 px-3 py-1 rounded-full">
              {story.subtitle}
            </span>
          </div>

          {/* Content */}
          <div className="relative h-full flex flex-col justify-between text-white p-8">
            {/* Background image */}
            {story.image && (
              <div
                className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-20"
                style={{ backgroundImage: `url(${toAssetUrl(story.image)})` }}
              />
            )}

            <div className="relative z-10 text-center mb-8">
              <h2 className="text-2xl font-light mb-2">{story.title}</h2>
              <div className="text-4xl font-bold mb-6 border-2 border-white inline-block px-4 py-2">
                {story.subtitle}
              </div>
              <p className="text-lg opacity-90">{story.description}</p>
            </div>

            {/* Person image */}
            {story.personImage && (
              <div className="relative z-10 flex justify-center mb-4">
                <img
                  src={toAssetUrl(story.personImage) || "/placeholder.svg"}
                  alt="Person"
                  className="w-20 h-20 rounded-full border-2 border-white object-cover"
                />
              </div>
            )}

            {/* Bottom discover button */}
            <div className="relative z-10 absolute bottom-8 left-1/2 transform -translate-x-1/2">
              <Link
                to={story.link}
                onClick={onClose}
                className="bg-black text-white px-6 py-3 rounded-full font-medium flex items-center gap-2 hover:bg-gray-800 transition-colors"
              >
                <span>Descoperă acum!</span>
                <div className="w-6 h-6 bg-white rounded-full flex items-center justify-center">
                  <ChevronRight className="w-4 h-4 text-black" />
                </div>
              </Link>
            </div>

            {/* Mobile navigation areas */}
            <div className="absolute inset-0 flex sm:hidden">
              <div className="w-1/2 h-full" onClick={goToPrevStory}></div>
              <div className="w-1/2 h-full" onClick={goToNextStory}></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default StoryModal
