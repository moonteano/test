import React, { useRef, useState, useEffect } from 'react';

function randomCode(length = 5) {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = '';
  for (let i = 0; i < length; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return code;
}

const drawCaptcha = (canvas: HTMLCanvasElement, code: string) => {
  const ctx = canvas.getContext('2d');
  if (!ctx) return;
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.fillStyle = '#f3f4f6';
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.font = 'bold 32px monospace';
  ctx.fillStyle = '#222';
  ctx.setTransform(1, 0.1 * (Math.random() - 0.5), 0, 1, 0, 0);
  ctx.fillText(code, 20, 40);
  // Add noise
  for (let i = 0; i < 10; i++) {
    ctx.strokeStyle = `rgba(0,0,0,${Math.random()})`;
    ctx.beginPath();
    ctx.moveTo(Math.random() * 120, Math.random() * 60);
    ctx.lineTo(Math.random() * 120, Math.random() * 60);
    ctx.stroke();
  }
};

const SimpleCaptcha: React.FC<{ onValidate: (valid: boolean) => void }> = ({ onValidate }) => {
  const [code, setCode] = useState(randomCode());
  const [input, setInput] = useState('');
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (canvasRef.current) drawCaptcha(canvasRef.current, code);
  }, [code]);

  useEffect(() => {
    onValidate(input.trim().toUpperCase() === code);
  }, [input, code, onValidate]);

  return (
    <div className="my-4">
      <label className="block text-sm font-medium text-gray-700 mb-2">Cod de verificare</label>
      <div className="flex items-center gap-3">
        <canvas ref={canvasRef} width={120} height={60} className="rounded border bg-gray-100" />
        <button type="button" className="text-xs px-2 py-1 bg-sage-100 rounded hover:bg-sage-200" onClick={() => { setCode(randomCode()); setInput(''); }}>
          Generează alt cod
        </button>
      </div>
      <input
        type="text"
        value={input}
        onChange={e => setInput(e.target.value)}
        maxLength={5}
        className="mt-2 w-full px-4 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-nature-500 focus:border-transparent"
        placeholder="Introdu codul din imagine"
        autoComplete="off"
      />
    </div>
  );
};

export default SimpleCaptcha;
