export interface User {
  id: number;
  email: string;
  firstName: string;
  lastName: string;
  phone?: string;
  address?: string;
  city?: string;
  zipCode?: string;
  role: 'user' | 'admin';
  status: 'active' | 'disabled';
  createdAt: string;
  updatedAt: string;
}

export interface Product {
  id: number;
  name: string;
  description: string;
  price: number;
  discountPrice?: number;
  category: string;
  brand: string;
  inStock: boolean;
  imageUrl: string;
  tags: string;
  featured: boolean;
  status: 'active' | 'disabled' | 'deleted';
  createdAt: string;
  updatedAt: string;
  ratingAvg?: number; // media ratingurilor
  reviewsCount?: number; // număr review-uri
}

export interface CartItem {
  id: number;
  userId: number;
  productId: number;
  quantity: number;
  name: string;
  price: number;
  discountPrice?: number;
  imageUrl: string;
  inStock: boolean;
  createdAt: string;
}

export interface Order {
  id: number;
  userId: number;
  orderNumber: string;
  status: 'pending' | 'processing' | 'shipped' | 'delivered' | 'cancelled';
  totalAmount: number;
  shippingAddress: string;
  paymentMethod: string;
  notes?: string;
  items?: any[]; // schimbat din string în any[] pentru detalii iteme
  email?: string;
  firstName?: string;
  lastName?: string;
  createdAt: string;
  updatedAt: string;
  estimatedDelivery?: string; // adăugat pentru estimare livrare
}

export interface ShippingAddress {
  firstName: string;
  lastName: string;
  address: string;
  city: string;
  zipCode: string;
  phone: string;
}

export interface AuthState {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
}

export interface DashboardStats {
  totalUsers: number;
  totalProducts: number;
  totalOrders: number;
  totalRevenue: number;
}

export interface Coupon {
  id: number;
  code: string;
  name?: string;
  description: string;
  discountType: 'percentage' | 'fixed';
  discountValue: number;
  minimumOrderValue?: number;
  minimumAmount?: number;
  maxUses?: number;
  currentUses: number;
  usedCount?: number;
  actualUsageCount?: number;
  totalDiscountGiven?: number;
  validFrom: string;
  validUntil: string;
  validTo?: string;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface CouponValidation {
  valid: boolean;
  message: string;
  discountAmount?: number;
  finalTotal?: number;
}

export interface CouponStats {
  totalCoupons: number;
  activeCoupons: number;
  totalUsage: number;
  totalDiscount: number;
}
