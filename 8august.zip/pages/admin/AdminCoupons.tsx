import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useNotifications } from '../../hooks/useNotifications';
import { Trash2, Edit, Plus, Tag, DollarSign, Users, TrendingUp } from 'lucide-react';
import { couponsAPI } from '../../services/api';
import { Coupon } from '../../types';

interface NewCoupon {
  code: string;
  name: string;
  description: string;
  discountType: 'percentage' | 'fixed';
  discountValue: number;
  minimumAmount: number;
  maxUses: number;
  validFrom: string;
  validTo: string;
}

const AdminCoupons: React.FC = () => {
  const { user } = useAuth();
  const { showSuccess, showError } = useNotifications();
  const [coupons, setCoupons] = useState<Coupon[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingCoupon, setEditingCoupon] = useState<Coupon | null>(null);
  const [newCoupon, setNewCoupon] = useState<NewCoupon>({
    code: '',
    name: '',
    description: '',
    discountType: 'percentage',
    discountValue: 0,
    minimumAmount: 0,
    maxUses: 0,
    validFrom: '',
    validTo: ''
  });

  useEffect(() => {
    fetchCoupons();
  }, []);

  const fetchCoupons = async () => {
    try {
      const data = await couponsAPI.getAll();
      setCoupons(data);
    } catch (error) {
      console.error('Error fetching coupons:', error);
      showError('Eroare', 'Nu s-au putut încărca cupoanele');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!newCoupon.code || !newCoupon.name || !newCoupon.validFrom || !newCoupon.validTo) {
      showError('Eroare', 'Toate câmpurile obligatorii trebuie completate');
      return;
    }

    try {
      if (editingCoupon) {
        await couponsAPI.update(editingCoupon.id, { ...newCoupon, isActive: editingCoupon.isActive });
        showSuccess('Succes', 'Cuponul a fost actualizat');
      } else {
        await couponsAPI.create(newCoupon);
        showSuccess('Succes', 'Cuponul a fost creat');
      }
      
      setShowForm(false);
      setEditingCoupon(null);
      setNewCoupon({
        code: '',
        name: '',
        description: '',
        discountType: 'percentage',
        discountValue: 0,
        minimumAmount: 0,
        maxUses: 0,
        validFrom: '',
        validTo: ''
      });
      fetchCoupons();
    } catch (error) {
      console.error('Error saving coupon:', error);
      showError('Eroare', 'Nu s-a putut salva cuponul');
    }
  };

  const handleEdit = (coupon: Coupon) => {
    setEditingCoupon(coupon);
    setNewCoupon({
      code: coupon.code,
      name: coupon.name || '',
      description: coupon.description || '',
      discountType: coupon.discountType,
      discountValue: coupon.discountValue,
      minimumAmount: coupon.minimumAmount || 0,
      maxUses: coupon.maxUses || 0,
      validFrom: coupon.validFrom.split('T')[0],
      validTo: (coupon.validTo || coupon.validUntil).split('T')[0]
    });
    setShowForm(true);
  };

  const handleDelete = async (id: number) => {
    if (!confirm('Ești sigur că vrei să ștergi acest cupon?')) return;

    try {
      await couponsAPI.delete(id);
      showSuccess('Succes', 'Cuponul a fost șters');
      fetchCoupons();
    } catch (error) {
      console.error('Error deleting coupon:', error);
      showError('Eroare', 'Nu s-a putut șterge cuponul');
    }
  };

  const toggleActive = async (coupon: Coupon) => {
    try {
      await couponsAPI.update(coupon.id, {
        ...coupon,
        isActive: !coupon.isActive
      });
      showSuccess('Succes', coupon.isActive ? 'Cupon dezactivat' : 'Cupon activat');
      fetchCoupons();
    } catch (error) {
      console.error('Error toggling coupon:', error);
      showError('Eroare', 'Nu s-a putut actualiza statusul cuponului');
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('ro-RO');
  };

  const isExpired = (validTo: string) => {
    return new Date(validTo) < new Date();
  };

  if (user?.role !== 'admin') {
    return <div>Access denied</div>;
  }

  if (loading) {
    return <div className="flex justify-center items-center h-64">
      <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
    </div>;
  }

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold text-gray-900">Administrare Cupoane</h1>
        <button
          onClick={() => setShowForm(true)}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 flex items-center space-x-2"
        >
          <Plus className="w-5 h-5" />
          <span>Cupon Nou</span>
        </button>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="flex items-center">
            <Tag className="w-8 h-8 text-blue-600" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Total Cupoane</p>
              <p className="text-2xl font-bold text-gray-900">{coupons.length}</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="flex items-center">
            <Users className="w-8 h-8 text-green-600" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Cupoane Active</p>
              <p className="text-2xl font-bold text-gray-900">
                {coupons.filter(c => c.isActive && !isExpired(c.validTo || c.validUntil)).length}
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="flex items-center">
            <TrendingUp className="w-8 h-8 text-purple-600" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Utilizări Total</p>
              <p className="text-2xl font-bold text-gray-900">
                {coupons.reduce((sum, c) => sum + (c.actualUsageCount || 0), 0)}
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="flex items-center">
            <DollarSign className="w-8 h-8 text-red-600" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Reduceri Totale</p>
              <p className="text-2xl font-bold text-gray-900">
                {coupons.reduce((sum, c) => sum + (c.totalDiscountGiven || 0), 0).toFixed(2)} Lei
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Form Modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg w-full max-w-md max-h-screen overflow-y-auto">
            <h2 className="text-xl font-bold mb-4">
              {editingCoupon ? 'Editează Cupon' : 'Cupon Nou'}
            </h2>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">Cod Cupon</label>
                <input
                  type="text"
                  value={newCoupon.code}
                  onChange={(e) => setNewCoupon({...newCoupon, code: e.target.value.toUpperCase()})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="ex: SAVE20"
                  disabled={!!editingCoupon}
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Nume Cupon</label>
                <input
                  type="text"
                  value={newCoupon.name}
                  onChange={(e) => setNewCoupon({...newCoupon, name: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="ex: Reducere 20%"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Descriere</label>
                <textarea
                  value={newCoupon.description}
                  onChange={(e) => setNewCoupon({...newCoupon, description: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Descriere opțională..."
                  rows={3}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Tip Reducere</label>
                <select
                  value={newCoupon.discountType}
                  onChange={(e) => setNewCoupon({...newCoupon, discountType: e.target.value as 'percentage' | 'fixed'})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="percentage">Procentaj (%)</option>
                  <option value="fixed">Suma fixă (Lei)</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Valoare Reducere {newCoupon.discountType === 'percentage' ? '(%)' : '(Lei)'}
                </label>
                <input
                  type="number"
                  value={newCoupon.discountValue}
                  onChange={(e) => setNewCoupon({...newCoupon, discountValue: Number(e.target.value)})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  min="0"
                  max={newCoupon.discountType === 'percentage' ? "100" : undefined}
                  step={newCoupon.discountType === 'percentage' ? "1" : "0.01"}
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Suma Minimă (Lei)</label>
                <input
                  type="number"
                  value={newCoupon.minimumAmount}
                  onChange={(e) => setNewCoupon({...newCoupon, minimumAmount: Number(e.target.value)})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  min="0"
                  step="0.01"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Utilizări Maxime (0 = nelimitat)</label>
                <input
                  type="number"
                  value={newCoupon.maxUses}
                  onChange={(e) => setNewCoupon({...newCoupon, maxUses: Number(e.target.value)})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  min="0"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Valid De La</label>
                  <input
                    type="date"
                    value={newCoupon.validFrom}
                    onChange={(e) => setNewCoupon({...newCoupon, validFrom: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Valid Până La</label>
                  <input
                    type="date"
                    value={newCoupon.validTo}
                    onChange={(e) => setNewCoupon({...newCoupon, validTo: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required
                  />
                </div>
              </div>

              <div className="flex space-x-4 pt-4">
                <button
                  type="submit"
                  className="flex-1 bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  {editingCoupon ? 'Actualizează' : 'Creează Cupon'}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setShowForm(false);
                    setEditingCoupon(null);
                    setNewCoupon({
                      code: '',
                      name: '',
                      description: '',
                      discountType: 'percentage',
                      discountValue: 0,
                      minimumAmount: 0,
                      maxUses: 0,
                      validFrom: '',
                      validTo: ''
                    });
                  }}
                  className="flex-1 bg-gray-300 text-gray-700 py-2 px-4 rounded-md hover:bg-gray-400"
                >
                  Anulează
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Coupons List */}
      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Cupon</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Reducere</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Utilizări</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Perioada</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Acțiuni</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {coupons.map((coupon) => (
              <tr key={coupon.id}>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div>
                    <div className="text-sm font-medium text-gray-900">{coupon.code}</div>
                    <div className="text-sm text-gray-500">{coupon.name}</div>
                    {coupon.description && (
                      <div className="text-xs text-gray-400">{coupon.description}</div>
                    )}
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-900">
                    {coupon.discountType === 'percentage' 
                      ? `${coupon.discountValue}%` 
                      : `${coupon.discountValue} Lei`
                    }
                  </div>
                  {(coupon.minimumAmount || 0) > 0 && (
                    <div className="text-xs text-gray-500">Min: {coupon.minimumAmount || 0} Lei</div>
                  )}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-900">
                    {coupon.actualUsageCount || 0}{coupon.maxUses ? `/${coupon.maxUses}` : ''}
                  </div>
                  <div className="text-xs text-gray-500">
                    Total economisit: {(coupon.totalDiscountGiven || 0).toFixed(2)} Lei
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-900">
                    {formatDate(coupon.validFrom)} - {formatDate(coupon.validTo || coupon.validUntil)}
                  </div>
                  {isExpired(coupon.validTo || coupon.validUntil) && (
                    <div className="text-xs text-red-500">Expirat</div>
                  )}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                    coupon.isActive && !isExpired(coupon.validTo || coupon.validUntil)
                      ? 'bg-green-100 text-green-800'
                      : 'bg-red-100 text-red-800'
                  }`}>
                    {coupon.isActive 
                      ? (isExpired(coupon.validTo || coupon.validUntil) ? 'Expirat' : 'Activ')
                      : 'Inactiv'
                    }
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                  <div className="flex space-x-2">
                    <button
                      onClick={() => handleEdit(coupon)}
                      className="text-blue-600 hover:text-blue-900"
                    >
                      <Edit className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => toggleActive(coupon)}
                      className={`${coupon.isActive ? 'text-red-600 hover:text-red-900' : 'text-green-600 hover:text-green-900'}`}
                    >
                      {coupon.isActive ? '⏸️' : '▶️'}
                    </button>
                    <button
                      onClick={() => handleDelete(coupon.id)}
                      className="text-red-600 hover:text-red-900"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        
        {coupons.length === 0 && (
          <div className="text-center py-8">
            <Tag className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-500">Nu există cupoane create încă.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminCoupons;
