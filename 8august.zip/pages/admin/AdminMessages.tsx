import React, { useState, useEffect } from 'react';
import { Mail, Search, Trash2, Reply, Clock, User } from 'lucide-react';
import { adminAPI } from '../../services/api';

interface ContactMessage {
  id: number;
  name: string;
  email: string;
  subject: string;
  message: string;
  status: 'unread' | 'read' | 'replied';
  createdAt: string;
}

const AdminMessages: React.FC = () => {
  const [messages, setMessages] = useState<ContactMessage[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedMessage, setSelectedMessage] = useState<ContactMessage | null>(null);
  const [replyText, setReplyText] = useState('');
  const [sendingReply, setSendingReply] = useState(false);

  useEffect(() => {
    fetchMessages();
  }, []);

  const fetchMessages = async () => {
    try {
      const messagesData = await adminAPI.getMessages();
      setMessages(messagesData);
    } catch (error) {
      console.error('Eroare la încărcarea mesajelor:', error);
    } finally {
      setLoading(false);
    }
  };

  const markAsRead = async (messageId: number) => {
    try {
      await adminAPI.markMessageAsRead(messageId);
      await fetchMessages();
    } catch (error) {
      console.error('Eroare la marcarea mesajului:', error);
    }
  };

  const deleteMessage = async (messageId: number) => {
    if (confirm('Sigur doriți să ștergeți acest mesaj?')) {
      try {
        await adminAPI.deleteMessage(messageId);
        await fetchMessages();
        if (selectedMessage?.id === messageId) {
          setSelectedMessage(null);
        }
      } catch (error) {
        console.error('Eroare la ștergerea mesajului:', error);
      }
    }
  };

  const sendReply = async () => {
    if (!selectedMessage || !replyText.trim()) return;

    setSendingReply(true);
    try {
      await adminAPI.replyToMessage(selectedMessage.id, replyText);
      
      // Create notification for user about the reply
      await adminAPI.sendNotification({
        email: selectedMessage.email, // Use email instead of userId
        type: 'info',
        title: 'Răspuns la mesajul tău',
        message: `Am răspuns la mesajul tău cu subiectul "${selectedMessage.subject}". Verifică email-ul pentru detalii.`
      });
      
      alert('Răspunsul a fost trimis cu succes!');
      setReplyText('');
      await fetchMessages();
    } catch (error) {
      console.error('Eroare la trimiterea răspunsului:', error);
      alert('Eroare la trimiterea răspunsului');
    } finally {
      setSendingReply(false);
    }
  };

  const filteredMessages = messages.filter(message => {
    const matchesSearch = message.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         message.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         message.subject.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || message.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'unread':
        return 'bg-red-100 text-red-800';
      case 'read':
        return 'bg-yellow-100 text-yellow-800';
      case 'replied':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'unread':
        return 'Necitit';
      case 'read':
        return 'Citit';
      case 'replied':
        return 'Răspuns';
      default:
        return status;
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-nature-600"></div>
      </div>
    );
  }

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Mesaje de Contact</h1>
        <p className="text-gray-600 mt-2">Gestionează mesajele primite de la clienți</p>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Messages List */}
        <div className="lg:col-span-2">
          {/* Filters */}
          <div className="bg-white rounded-xl shadow-sm border p-6 mb-6">
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="flex-1">
                <div className="relative">
                  <input
                    type="text"
                    placeholder="Caută mesaje..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-nature-500 focus:border-transparent"
                  />
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                </div>
              </div>
              
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-nature-500 focus:border-transparent"
              >
                <option value="all">Toate statusurile</option>
                <option value="unread">Necitite</option>
                <option value="read">Citite</option>
                <option value="replied">Cu răspuns</option>
              </select>
            </div>
          </div>

          {/* Messages */}
          <div className="space-y-4">
            {filteredMessages.map((message) => (
              <div
                key={message.id}
                className={`bg-white rounded-xl shadow-sm border p-6 cursor-pointer transition-all hover:shadow-md ${
                  selectedMessage?.id === message.id ? 'ring-2 ring-nature-500' : ''
                }`}
                onClick={() => {
                  setSelectedMessage(message);
                  if (message.status === 'unread') {
                    markAsRead(message.id);
                  }
                }}
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-nature-600 rounded-full flex items-center justify-center">
                      <User className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900">{message.name}</h3>
                      <p className="text-sm text-gray-600">{message.email}</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className={`inline-block px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(message.status)}`}>
                      {getStatusText(message.status)}
                    </span>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        deleteMessage(message.id);
                      }}
                      className="text-red-500 hover:text-red-700"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
                
                <h4 className="font-medium text-gray-900 mb-2">{message.subject}</h4>
                <p className="text-gray-600 text-sm line-clamp-2 mb-3">{message.message}</p>
                
                <div className="flex items-center text-xs text-gray-500">
                  <Clock className="w-4 h-4 mr-1" />
                  {new Date(message.createdAt).toLocaleString('ro-RO')}
                </div>
              </div>
            ))}

            {filteredMessages.length === 0 && (
              <div className="text-center py-12">
                <Mail className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <p className="text-gray-500">Nu au fost găsite mesaje</p>
              </div>
            )}
          </div>
        </div>

        {/* Message Detail */}
        <div className="lg:col-span-1">
          {selectedMessage ? (
            <div className="bg-white rounded-xl shadow-sm border p-6 sticky top-24">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-semibold text-gray-900">Detalii mesaj</h2>
                <span className={`inline-block px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(selectedMessage.status)}`}>
                  {getStatusText(selectedMessage.status)}
                </span>
              </div>

              <div className="space-y-4 mb-6">
                <div>
                  <label className="text-sm font-medium text-gray-700">De la:</label>
                  <p className="text-gray-900">{selectedMessage.name}</p>
                  <p className="text-sm text-gray-600">{selectedMessage.email}</p>
                </div>

                <div>
                  <label className="text-sm font-medium text-gray-700">Subiect:</label>
                  <p className="text-gray-900">{selectedMessage.subject}</p>
                </div>

                <div>
                  <label className="text-sm font-medium text-gray-700">Data:</label>
                  <p className="text-gray-900">{new Date(selectedMessage.createdAt).toLocaleString('ro-RO')}</p>
                </div>

                <div>
                  <label className="text-sm font-medium text-gray-700">Mesaj:</label>
                  <div className="bg-gray-50 rounded-lg p-4 mt-2">
                    <p className="text-gray-900 whitespace-pre-wrap">{selectedMessage.message}</p>
                  </div>
                </div>
              </div>

              {/* Reply Section */}
              <div className="border-t pt-6">
                <h3 className="font-semibold text-gray-900 mb-3">Trimite răspuns</h3>
                <textarea
                  value={replyText}
                  onChange={(e) => setReplyText(e.target.value)}
                  placeholder="Scrie răspunsul aici..."
                  rows={4}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-nature-500 focus:border-transparent"
                />
                <button
                  onClick={sendReply}
                  disabled={sendingReply || !replyText.trim()}
                  className="mt-3 w-full bg-earth-600 text-white py-2 px-4 rounded-lg hover:bg-earth-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center justify-center space-x-2"
                >
                  <Reply className="w-4 h-4" />
                  <span>{sendingReply ? 'Se trimite...' : 'Trimite răspuns'}</span>
                </button>
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-xl shadow-sm border p-6 text-center">
              <Mail className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500">Selectează un mesaj pentru a vedea detaliile</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AdminMessages;
