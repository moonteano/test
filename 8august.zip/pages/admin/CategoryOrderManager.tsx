import React, { useState, useEffect } from 'react';
import { productsAPI, adminAPI } from '../../services/api';

const CategoryOrderManager: React.FC = () => {
  const [categories, setCategories] = useState<string[]>([]);
  const [draggedIdx, setDraggedIdx] = useState<number | null>(null);
  const [saving, setSaving] = useState(false);
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    productsAPI.getCategories().then(setCategories);
  }, []);

  const onDragStart = (idx: number) => setDraggedIdx(idx);
  const onDragOver = (idx: number) => {
    if (draggedIdx === null || draggedIdx === idx) return;
    const newOrder = [...categories];
    const [removed] = newOrder.splice(draggedIdx, 1);
    newOrder.splice(idx, 0, removed);
    setCategories(newOrder);
    setDraggedIdx(idx);
  };

  const saveOrder = async () => {
    setSaving(true);
    await adminAPI.setCategoryOrder(categories);
    setSaving(false);
    setSuccess(true);
    setTimeout(() => setSuccess(false), 2000);
  };

  return (
    <div>
      <ul className="space-y-2 mb-4">
        {categories.map((cat, idx) => (
          <li
            key={cat}
            draggable
            onDragStart={() => onDragStart(idx)}
            onDragOver={(e) => { e.preventDefault(); onDragOver(idx); }}
            className="bg-nature-50 border rounded-lg px-4 py-2 cursor-move shadow-sm"
          >
            {cat}
          </li>
        ))}
      </ul>
      <button onClick={saveOrder} disabled={saving} className="btn-earth px-6 py-2 rounded-lg font-semibold">
        {saving ? 'Se salvează...' : 'Salvează ordinea'}
      </button>
      {success && <span className="ml-4 text-green-600 font-medium">Salvat!</span>}
    </div>
  );
};

export default CategoryOrderManager;
