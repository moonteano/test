import React, { useState, useEffect, useRef } from 'react';
import { 
  Upload, 
  FolderPlus, 
  Search, 
  Trash2, 
  Folder,
  File,
  ArrowLeft,
  Grid3X3,
  List,
  SortAsc,
  SortDesc,
  X,
  Eye
} from 'lucide-react';
import { fileAPI } from '../../services/api';
import { useNotifications } from '../../hooks/useNotifications';

interface FileItem {
  name: string;
  type: 'file' | 'image' | 'folder';
  size?: number;
  createdAt?: string;
  url?: string;
  extension?: string;
}

interface FileManagerData {
  folders: FileItem[];
  files: FileItem[];
}

const AdminFileManager: React.FC = () => {
  const [data, setData] = useState<FileManagerData>({ folders: [], files: [] });
  const [currentFolder, setCurrentFolder] = useState('');
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [sortBy, setSortBy] = useState<'name' | 'date' | 'size'>('name');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');
  const [showCreateFolder, setShowCreateFolder] = useState(false);
  const [newFolderName, setNewFolderName] = useState('');
  const [previewImage, setPreviewImage] = useState<string | null>(null);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { showSuccess, showError } = useNotifications();

  const pathSegments = currentFolder ? currentFolder.split('/').filter(Boolean) : [];

  useEffect(() => {
    fetchFiles();
  }, [currentFolder]);

  const fetchFiles = async () => {
    setLoading(true);
    try {
      const response = await fileAPI.list(currentFolder);
      console.log('API Response:', response);
      
      // Ensure we have proper data structure
      const folders = Array.isArray(response.folders) ? response.folders : [];
      const files = Array.isArray(response.files) ? response.files : [];
      
      setData({ folders, files });
    } catch (error) {
      console.error('Error fetching files:', error);
      showError('Error', 'Failed to load files');
      setData({ folders: [], files: [] });
    } finally {
      setLoading(false);
    }
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files || files.length === 0) return;

    setLoading(true);
    try {
      await fileAPI.upload(files, currentFolder);
      showSuccess('Upload Successful', `${files.length} file(s) uploaded successfully`);
      await fetchFiles();
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    } catch (error) {
      console.error('Error uploading files:', error);
      showError('Upload Failed', 'Failed to upload files');
    } finally {
      setLoading(false);
    }
  };

  const handleCreateFolder = async () => {
    if (!newFolderName.trim()) return;
    
    try {
      await fileAPI.createFolder(currentFolder, newFolderName);
      showSuccess('Folder Created', `Folder "${newFolderName}" created successfully`);
      setNewFolderName('');
      setShowCreateFolder(false);
      await fetchFiles();
    } catch (error) {
      console.error('Error creating folder:', error);
      showError('Error', 'Failed to create folder');
    }
  };

  const handleDelete = async (item: FileItem) => {
    if (!confirm(`Are you sure you want to delete "${item.name}"?`)) return;
    
    try {
      await fileAPI.deleteFile(currentFolder, item.name);
      showSuccess('Deleted', `"${item.name}" deleted successfully`);
      await fetchFiles();
    } catch (error) {
      console.error('Error deleting:', error);
      showError('Error', 'Failed to delete item');
    }
  };

  const navigateToFolder = (folderName: string) => {
    const newPath = currentFolder ? `${currentFolder}/${folderName}` : folderName;
    setCurrentFolder(newPath);
  };

  const navigateToPath = (index: number) => {
    const newPath = pathSegments.slice(0, index + 1).join('/');
    setCurrentFolder(newPath);
  };

  const goBack = () => {
    const parentPath = pathSegments.slice(0, -1).join('/');
    setCurrentFolder(parentPath);
  };

  const formatFileSize = (bytes?: number) => {
    if (!bytes || bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const formatDate = (dateString?: string) => {
    if (!dateString) return 'Unknown';
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  // Safe filtering and sorting
  const getFilteredAndSortedItems = () => {
    try {
      const allItems = [...data.folders, ...data.files];
      
      // Filter items safely
      const filtered = allItems.filter(item => {
        if (!item || typeof item !== 'object') return false;
        if (!item.name || typeof item.name !== 'string') return false;
        return item.name.toLowerCase().includes(searchTerm.toLowerCase());
      });

      // Sort items safely
      const sorted = filtered.sort((a, b) => {
        let comparison = 0;
        
        try {
          if (sortBy === 'name') {
            comparison = a.name.localeCompare(b.name);
          } else if (sortBy === 'date' && a.createdAt && b.createdAt) {
            comparison = new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
          } else if (sortBy === 'size') {
            comparison = (a.size || 0) - (b.size || 0);
          }
        } catch (error) {
          console.error('Sorting error:', error);
          return 0;
        }
        
        return sortOrder === 'asc' ? comparison : -comparison;
      });

      return sorted;
    } catch (error) {
      console.error('Error in getFilteredAndSortedItems:', error);
      return [];
    }
  };

  const filteredAndSortedItems = getFilteredAndSortedItems();

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">File Manager</h1>
            <p className="text-gray-500">Manage your uploaded files and folders</p>
          </div>
          
          <div className="flex items-center space-x-3">
            <button
              onClick={() => fileInputRef.current?.click()}
              className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 flex items-center space-x-2"
              disabled={loading}
            >
              <Upload className="w-4 h-4" />
              <span>{loading ? 'Uploading...' : 'Upload Files'}</span>
            </button>
            
            <button
              onClick={() => setShowCreateFolder(true)}
              className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 flex items-center space-x-2"
              disabled={loading}
            >
              <FolderPlus className="w-4 h-4" />
              <span>New Folder</span>
            </button>
          </div>
        </div>

        {/* Breadcrumbs */}
        <div className="bg-white rounded-lg shadow-sm border p-4 mb-6">
          <div className="flex items-center space-x-2 text-sm">
            <button
              onClick={() => setCurrentFolder('')}
              className="text-blue-600 hover:text-blue-800 font-medium"
            >
              Home
            </button>
            {pathSegments.map((segment, index) => (
              <React.Fragment key={index}>
                <span className="text-gray-400">/</span>
                <button
                  onClick={() => navigateToPath(index)}
                  className="text-blue-600 hover:text-blue-800 font-medium"
                >
                  {segment}
                </button>
              </React.Fragment>
            ))}
          </div>
          
          {currentFolder && (
            <button
              onClick={goBack}
              className="mt-2 text-gray-600 hover:text-gray-800 flex items-center space-x-1"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back</span>
            </button>
          )}
        </div>

        {/* Toolbar */}
        <div className="bg-white rounded-lg shadow-sm border p-4 mb-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="relative">
                <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search files..."
                  className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as 'name' | 'date' | 'size')}
                className="border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500"
              >
                <option value="name">Sort by Name</option>
                <option value="date">Sort by Date</option>
                <option value="size">Sort by Size</option>
              </select>
              
              <button
                onClick={() => setSortOrder(prev => prev === 'asc' ? 'desc' : 'asc')}
                className="p-2 text-gray-600 hover:text-gray-800"
              >
                {sortOrder === 'asc' ? <SortAsc className="w-4 h-4" /> : <SortDesc className="w-4 h-4" />}
              </button>
            </div>
            
            <div className="flex items-center space-x-2">
              <button
                onClick={() => setViewMode('grid')}
                className={`p-2 rounded ${viewMode === 'grid' ? 'bg-blue-100 text-blue-600' : 'text-gray-600 hover:text-gray-800'}`}
              >
                <Grid3X3 className="w-4 h-4" />
              </button>
              <button
                onClick={() => setViewMode('list')}
                className={`p-2 rounded ${viewMode === 'list' ? 'bg-blue-100 text-blue-600' : 'text-gray-600 hover:text-gray-800'}`}
              >
                <List className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* File Grid/List */}
        <div className="bg-white rounded-lg shadow-sm border">
          {loading ? (
            <div className="p-8 text-center">
              <div className="animate-spin w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full mx-auto"></div>
              <p className="mt-2 text-gray-600">Loading...</p>
            </div>
          ) : filteredAndSortedItems.length === 0 ? (
            <div className="p-8 text-center">
              <Folder className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500">No files or folders found</p>
              {searchTerm && (
                <p className="text-sm text-gray-400 mt-2">Try adjusting your search terms</p>
              )}
            </div>
          ) : viewMode === 'grid' ? (
            <div className="p-6 grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 xl:grid-cols-8 gap-4">
              {filteredAndSortedItems.map((item, index) => (
                <div
                  key={`${item.name}-${index}`}
                  className="group relative bg-gray-50 rounded-lg p-3 hover:bg-gray-100 cursor-pointer border-2 border-transparent hover:border-gray-200 transition-all"
                  onClick={() => item.type === 'folder' ? navigateToFolder(item.name) : null}
                >
                  <div className="aspect-square mb-2 bg-gray-100 rounded-lg flex items-center justify-center overflow-hidden">
                    {item.type === 'folder' ? (
                      <Folder className="w-12 h-12 text-blue-500" />
                    ) : item.type === 'image' && item.url ? (
                      <img
                        src={item.url}
                        alt={item.name}
                        className="w-full h-full object-cover cursor-pointer"
                        onClick={(e) => {
                          e.stopPropagation();
                          setPreviewImage(item.url || '');
                        }}
                        onError={(e) => {
                          const target = e.target as HTMLImageElement;
                          target.style.display = 'none';
                          const parent = target.parentElement;
                          if (parent) {
                            parent.innerHTML = '<div class="flex items-center justify-center w-full h-full"><svg class="w-6 h-6 text-gray-400" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2H4zm12 12H4l4-8 3 6 2-4 3 6z" clip-rule="evenodd" /></svg></div>';
                          }
                        }}
                      />
                    ) : (
                      <File className="w-12 h-12 text-gray-400" />
                    )}
                  </div>
                  
                  <div className="text-xs font-medium text-gray-900 truncate mb-1" title={item.name}>
                    {item.name}
                  </div>
                  
                  {item.size && item.type !== 'folder' && (
                    <div className="text-xs text-gray-500">
                      {formatFileSize(item.size)}
                    </div>
                  )}
                  
                  {/* Action buttons */}
                  <div className="opacity-0 group-hover:opacity-100 transition-opacity absolute top-2 right-2">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDelete(item);
                      }}
                      className="p-1 bg-red-100 text-red-600 rounded hover:bg-red-200"
                      title="Delete"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50 border-b">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Name</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Type</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Size</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Modified</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {filteredAndSortedItems.map((item, index) => (
                    <tr key={`${item.name}-${index}`} className="hover:bg-gray-50">
                      <td className="px-6 py-4">
                        <div className="flex items-center space-x-3">
                          {item.type === 'folder' ? (
                            <Folder className="w-5 h-5 text-blue-500" />
                          ) : item.type === 'image' && item.url ? (
                            <div className="w-8 h-8 rounded overflow-hidden">
                              <img 
                                src={item.url} 
                                alt={item.name}
                                className="w-full h-full object-cover"
                              />
                            </div>
                          ) : (
                            <File className="w-5 h-5 text-gray-400" />
                          )}
                          
                          <button
                            onClick={() => item.type === 'folder' ? navigateToFolder(item.name) : null}
                            className="text-left hover:text-blue-600 font-medium text-gray-900"
                          >
                            {item.name}
                          </button>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-500">
                        {item.type === 'folder' ? 'Folder' : item.extension?.toUpperCase() || 'File'}
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-500">
                        {item.type === 'folder' ? '-' : formatFileSize(item.size)}
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-500">
                        {formatDate(item.createdAt)}
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center space-x-2">
                          {item.type === 'image' && item.url && (
                            <button
                              onClick={() => setPreviewImage(item.url || '')}
                              className="p-1 text-blue-600 hover:bg-blue-100 rounded"
                              title="Preview"
                            >
                              <Eye className="w-4 h-4" />
                            </button>
                          )}
                          <button
                            onClick={() => handleDelete(item)}
                            className="p-1 text-red-600 hover:bg-red-100 rounded"
                            title="Delete"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Create Folder Modal */}
        {showCreateFolder && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg p-6 w-96">
              <h3 className="text-lg font-semibold mb-4">Create New Folder</h3>
              <input
                type="text"
                placeholder="Folder name"
                className="w-full border border-gray-300 rounded-lg px-3 py-2 mb-4 focus:ring-2 focus:ring-blue-500"
                value={newFolderName}
                onChange={(e) => setNewFolderName(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleCreateFolder();
                  if (e.key === 'Escape') setShowCreateFolder(false);
                }}
                autoFocus
              />
              <div className="flex justify-end space-x-3">
                <button
                  onClick={() => setShowCreateFolder(false)}
                  className="px-4 py-2 text-gray-600 hover:text-gray-800"
                >
                  Cancel
                </button>
                <button
                  onClick={handleCreateFolder}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                  disabled={!newFolderName.trim()}
                >
                  Create
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Image Preview Modal */}
        {previewImage && (
          <div 
            className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50"
            onClick={() => setPreviewImage(null)}
          >
            <div className="max-w-4xl max-h-full p-4 relative">
              <button
                onClick={() => setPreviewImage(null)}
                className="absolute top-4 right-4 bg-white rounded-full p-2 hover:bg-gray-100"
              >
                <X className="w-4 h-4" />
              </button>
              <img
                src={previewImage}
                alt="Preview"
                className="max-w-full max-h-full object-contain"
                onClick={(e) => e.stopPropagation()}
              />
              <div className="flex justify-center mt-4 space-x-4">
                <button
                  onClick={() => {
                    navigator.clipboard.writeText(window.location.origin + previewImage);
                    showSuccess('Copied', 'URL copied to clipboard');
                  }}
                  className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
                >
                  Copy URL
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Hidden file input */}
        <input
          ref={fileInputRef}
          type="file"
          multiple
          accept="image/*"
          className="hidden"
          onChange={handleFileUpload}
        />
      </div>
    </div>
  );
};

export default AdminFileManager;
