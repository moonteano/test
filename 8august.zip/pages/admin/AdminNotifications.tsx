import React, { useState, useEffect } from 'react';
import { Send, Users, User, Bell, Plus, Trash2 } from 'lucide-react';
import { adminAPI } from '../../services/api';
import { User as UserType } from '../../types';

interface Notification {
  id: number;
  userId?: number;
  type: 'success' | 'info' | 'warning' | 'error';
  title: string;
  message: string;
  isRead: boolean;
  createdAt: string;
  userName?: string;
}

const AdminNotifications: React.FC = () => {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [users, setUsers] = useState<UserType[]>([]);
  const [loading, setLoading] = useState(true);
  const [showSendModal, setShowSendModal] = useState(false);
  const [sendingNotification, setSendingNotification] = useState(false);

  const [notificationForm, setNotificationForm] = useState({
    userId: '',
    type: 'info' as 'success' | 'info' | 'warning' | 'error',
    title: '',
    message: ''
  });

  useEffect(() => {
    fetchNotifications();
    fetchUsers();
  }, []);

  const fetchNotifications = async () => {
    try {
      const notificationsData = await adminAPI.getAllNotifications();
      setNotifications(notificationsData);
    } catch (error) {
      console.error('Eroare la încărcarea notificărilor:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchUsers = async () => {
    try {
      const usersData = await adminAPI.getUsers();
      setUsers(usersData.filter(user => user.role === 'user'));
    } catch (error) {
      console.error('Eroare la încărcarea utilizatorilor:', error);
    }
  };

  const sendNotification = async () => {
    if (!notificationForm.title || !notificationForm.message) {
      alert('Te rog completează toate câmpurile obligatorii');
      return;
    }

    setSendingNotification(true);
    try {
      if (notificationForm.userId === 'all') {
        // Trimite la toți utilizatorii
        await adminAPI.sendNotificationToAll({
          type: notificationForm.type,
          title: notificationForm.title,
          message: notificationForm.message
        });
      } else {
        // Trimite la un utilizator specific
        await adminAPI.sendNotification({
          userId: parseInt(notificationForm.userId),
          type: notificationForm.type,
          title: notificationForm.title,
          message: notificationForm.message
        });
      }

      alert('Notificarea a fost trimisă cu succes!');
      setNotificationForm({ userId: '', type: 'info', title: '', message: '' });
      setShowSendModal(false);
      await fetchNotifications();
    } catch (error) {
      console.error('Eroare la trimiterea notificării:', error);
      alert('Eroare la trimiterea notificării');
    } finally {
      setSendingNotification(false);
    }
  };

  const deleteNotification = async (notificationId: number) => {
    if (confirm('Sigur doriți să ștergeți această notificare?')) {
      try {
        await adminAPI.deleteNotification(notificationId);
        await fetchNotifications();
      } catch (error) {
        console.error('Eroare la ștergerea notificării:', error);
        alert('Eroare la ștergerea notificării');
      }
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'success':
        return 'bg-green-100 text-green-800';
      case 'warning':
        return 'bg-yellow-100 text-yellow-800';
      case 'error':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-blue-100 text-blue-800';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'success':
        return '✅';
      case 'warning':
        return '⚠️';
      case 'error':
        return '❌';
      default:
        return 'ℹ️';
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Sistem Notificări</h1>
          <p className="text-gray-600 mt-2">Trimite și gestionează notificările pentru utilizatori</p>
        </div>
        <button
          onClick={() => setShowSendModal(true)}
          className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2 btn-animate"
        >
          <Plus className="w-5 h-5" />
          <span>Trimite Notificare</span>
        </button>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white rounded-xl shadow-sm border p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Notificări</p>
              <p className="text-2xl font-bold text-gray-900">{notifications.length}</p>
            </div>
            <Bell className="w-8 h-8 text-blue-600" />
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-sm border p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Notificări Citite</p>
              <p className="text-2xl font-bold text-gray-900">
                {notifications.filter(n => n.isRead).length}
              </p>
            </div>
            <Bell className="w-8 h-8 text-green-600" />
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-sm border p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Utilizatori Activi</p>
              <p className="text-2xl font-bold text-gray-900">{users.length}</p>
            </div>
            <Users className="w-8 h-8 text-purple-600" />
          </div>
        </div>
      </div>

      {/* Notifications List */}
      <div className="bg-white rounded-xl shadow-sm border overflow-hidden">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-xl font-semibold text-gray-900">Istoric Notificări</h2>
        </div>
        
        <div className="divide-y divide-gray-200">
          {notifications.map((notification) => (
            <div key={notification.id} className="p-6 hover:bg-gray-50">
              <div className="flex items-start justify-between">
                <div className="flex items-start space-x-4">
                  <div className="text-2xl">{getTypeIcon(notification.type)}</div>
                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-2">
                      <h3 className="font-semibold text-gray-900">{notification.title}</h3>
                      <span className={`inline-block px-2 py-1 rounded-full text-xs font-medium ${getTypeColor(notification.type)}`}>
                        {notification.type}
                      </span>
                      {!notification.isRead && (
                        <span className="inline-block w-2 h-2 bg-blue-600 rounded-full"></span>
                      )}
                    </div>
                    <p className="text-gray-600 mb-2">{notification.message}</p>
                    <div className="flex items-center space-x-4 text-sm text-gray-500">
                      <span>
                        {notification.userName ? `Pentru: ${notification.userName}` : 'Pentru: Toți utilizatorii'}
                      </span>
                      <span>{new Date(notification.createdAt).toLocaleString('ro-RO')}</span>
                    </div>
                  </div>
                </div>
                <button
                  onClick={() => deleteNotification(notification.id)}
                  className="text-red-500 hover:text-red-700 p-2"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}

          {notifications.length === 0 && (
            <div className="text-center py-12">
              <Bell className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500">Nu există notificări trimise</p>
            </div>
          )}
        </div>
      </div>

      {/* Send Notification Modal */}
      {showSendModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl max-w-md w-full p-6">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Trimite Notificare</h2>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Destinatar
                </label>
                <select
                  value={notificationForm.userId}
                  onChange={(e) => setNotificationForm({...notificationForm, userId: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="">Selectează utilizatorul</option>
                  <option value="all">Toți utilizatorii</option>
                  {users.map(user => (
                    <option key={user.id} value={user.id}>
                      {user.firstName} {user.lastName} ({user.email})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Tip Notificare
                </label>
                <select
                  value={notificationForm.type}
                  onChange={(e) => setNotificationForm({...notificationForm, type: e.target.value as any})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="info">Informare</option>
                  <option value="success">Succes</option>
                  <option value="warning">Avertisment</option>
                  <option value="error">Eroare</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Titlu *
                </label>
                <input
                  type="text"
                  value={notificationForm.title}
                  onChange={(e) => setNotificationForm({...notificationForm, title: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Titlul notificării"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Mesaj *
                </label>
                <textarea
                  value={notificationForm.message}
                  onChange={(e) => setNotificationForm({...notificationForm, message: e.target.value})}
                  rows={4}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Conținutul notificării"
                />
              </div>
            </div>

            <div className="flex items-center justify-end space-x-4 mt-6">
              <button
                onClick={() => setShowSendModal(false)}
                className="px-6 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
              >
                Anulează
              </button>
              <button
                onClick={sendNotification}
                disabled={sendingNotification}
                className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center space-x-2 btn-animate"
              >
                <Send className="w-4 h-4" />
                <span>{sendingNotification ? 'Se trimite...' : 'Trimite'}</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminNotifications;
