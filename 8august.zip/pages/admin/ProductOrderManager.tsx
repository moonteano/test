import React, { useState, useEffect } from 'react';
import { Product } from '../../types';
import { productsAPI, adminAPI } from '../../services/api';

const ProductOrderManager: React.FC = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [draggedIdx, setDraggedIdx] = useState<number | null>(null);
  const [saving, setSaving] = useState(false);
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    productsAPI.getAll().then(setProducts);
  }, []);

  const onDragStart = (idx: number) => setDraggedIdx(idx);
  const onDragOver = (idx: number) => {
    if (draggedIdx === null || draggedIdx === idx) return;
    const newOrder = [...products];
    const [removed] = newOrder.splice(draggedIdx, 1);
    newOrder.splice(idx, 0, removed);
    setProducts(newOrder);
    setDraggedIdx(idx);
  };

  const saveOrder = async () => {
    setSaving(true);
    await adminAPI.setProductOrder(products.map(p => p.id));
    setSaving(false);
    setSuccess(true);
    // Reîncarcă lista de produse după salvare
    productsAPI.getAll().then(setProducts);
    setTimeout(() => setSuccess(false), 2000);
  };

  return (
    <div>
      <ul className="space-y-2 mb-4">
        {products.map((prod, idx) => (
          <li
            key={prod.id}
            draggable
            onDragStart={() => onDragStart(idx)}
            onDragOver={(e) => { e.preventDefault(); onDragOver(idx); }}
            className="bg-nature-50 border rounded-lg px-4 py-2 cursor-move shadow-sm flex justify-between items-center"
          >
            <span>{prod.name}</span>
            <span className="text-xs text-gray-500">{prod.price} Lei</span>
          </li>
        ))}
      </ul>
      <button onClick={saveOrder} disabled={saving} className="btn-earth px-6 py-2 rounded-lg font-semibold">
        {saving ? 'Se salvează...' : 'Salvează ordinea'}
      </button>
      {success && <span className="ml-4 text-green-600 font-medium">Salvat!</span>}
    </div>
  );
};

export default ProductOrderManager;
