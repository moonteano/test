import React, { useState, useEffect } from 'react';
import { Plus, Edit, Trash2, Save, X, Upload, Eye } from 'lucide-react';
import { useNotifications } from '../../hooks/useNotifications';
import { storiesAPI } from '../../services/api';
import FilePicker from '../../components/FilePicker';

interface StoryCategory {
  id: number;
  name: string;
  image: string;
  link: string;
  bgGradient: string;
  title: string;
  subtitle: string;
  description: string;
  personImage: string;
  isActive: boolean;
  orderIndex: number;
}

const AdminStories: React.FC = () => {
  const { showSuccess, showError } = useNotifications();
  const [stories, setStories] = useState<StoryCategory[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingStory, setEditingStory] = useState<StoryCategory | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [showFilePicker, setShowFilePicker] = useState<'image' | 'personImage' | null>(null);
  const [previewStory, setPreviewStory] = useState<StoryCategory | null>(null);

  // Form data la nivel de componentă principală
  const [formData, setFormData] = useState<StoryCategory>({
    id: 0,
    name: '',
    image: '',
    link: '',
    bgGradient: 'bg-gradient-to-br from-emerald-400 to-emerald-600',
    title: 'Ai tot ce-ți poți imagina în',
    subtitle: '',
    description: '',
    personImage: '',
    isActive: true,
    orderIndex: 0
  });

  const gradientOptions = [
    { name: 'Emerald', value: 'bg-gradient-to-br from-emerald-400 to-emerald-600' },
    { name: 'Orange to Red', value: 'bg-gradient-to-br from-orange-400 to-red-500' },
    { name: 'Cyan to Blue', value: 'bg-gradient-to-br from-cyan-300 to-blue-500' },
    { name: 'Yellow to Orange', value: 'bg-gradient-to-br from-yellow-300 to-orange-400' },
    { name: 'Blue to Purple', value: 'bg-gradient-to-br from-blue-400 to-purple-500' },
    { name: 'Green to Emerald', value: 'bg-gradient-to-br from-green-400 to-emerald-600' },
    { name: 'Pink to Rose', value: 'bg-gradient-to-br from-pink-400 to-rose-500' },
    { name: 'Red to Orange', value: 'bg-gradient-to-br from-red-400 to-orange-500' },
    { name: 'Purple to Pink', value: 'bg-gradient-to-br from-purple-400 to-pink-500' },
    { name: 'Indigo to Purple', value: 'bg-gradient-to-br from-indigo-400 to-purple-600' }
  ];

  useEffect(() => {
    fetchStories();
  }, []);

  const fetchStories = async () => {
    try {
      setLoading(true);
      const fetchedStories = await storiesAPI.getAllAdmin();
      setStories(fetchedStories);
    } catch (error) {
      console.error('Error fetching stories:', error);
      showError('Error', 'Failed to fetch stories');
    } finally {
      setLoading(false);
    }
  };

  const handleSaveStory = async () => {
    try {
      if (formData.id) {
        // Update existing story
        const updatedStory = await storiesAPI.update(formData.id, formData);
        setStories(prev => prev.map(s => s.id === formData.id ? updatedStory : s));
        showSuccess('Success', 'Story updated successfully');
      } else {
        // Create new story
        const newStory = await storiesAPI.create({ ...formData, orderIndex: stories.length + 1 });
        setStories(prev => [...prev, newStory]);
        showSuccess('Success', 'Story created successfully');
      }
      handleCancelForm();
    } catch (error) {
      console.error('Error saving story:', error);
      showError('Error', 'Failed to save story');
    }
  };

  const handleDeleteStory = async (id: number) => {
    if (!confirm('Are you sure you want to delete this story?')) return;
    
    try {
      await storiesAPI.delete(id);
      setStories(prev => prev.filter(s => s.id !== id));
      showSuccess('Success', 'Story deleted successfully');
    } catch (error) {
      console.error('Error deleting story:', error);
      showError('Error', 'Failed to delete story');
    }
  };

  const handleToggleActive = async (id: number) => {
    try {
      const story = stories.find(s => s.id === id);
      if (!story) return;
      
      const updatedStory = await storiesAPI.update(id, { ...story, isActive: !story.isActive });
      setStories(prev => prev.map(s => s.id === id ? updatedStory : s));
      showSuccess('Success', `Story ${updatedStory.isActive ? 'activated' : 'deactivated'}`);
    } catch (error) {
      console.error('Error toggling story status:', error);
      showError('Error', 'Failed to update story status');
    }
  };

  const handleEditStory = (story: StoryCategory) => {
    setFormData(story);
    setEditingStory(story);
    setShowForm(true);
  };

  const handleAddStory = () => {
    setFormData({
      id: 0,
      name: '',
      image: '',
      link: '',
      bgGradient: gradientOptions[0].value,
      title: 'Ai tot ce-ți poți imagina în',
      subtitle: '',
      description: '',
      personImage: '',
      isActive: true,
      orderIndex: stories.length + 1
    });
    setEditingStory(null);
    setShowForm(true);
  };

  const handleCancelForm = () => {
    setShowForm(false);
    setEditingStory(null);
    setFormData({
      id: 0,
      name: '',
      image: '',
      link: '',
      bgGradient: gradientOptions[0].value,
      title: 'Ai tot ce-ți poți imagina în',
      subtitle: '',
      description: '',
      personImage: '',
      isActive: true,
      orderIndex: 0
    });
  };

  const handleFileSelect = (file: any) => {
    console.log('File selected:', file);
    if (showFilePicker === 'image') {
      setFormData({ ...formData, image: file.url || '' });
    } else if (showFilePicker === 'personImage') {
      setFormData({ ...formData, personImage: file.url || '' });
    }
    setShowFilePicker(null);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Stories Management</h1>
          <button
            onClick={handleAddStory}
            className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center gap-2"
          >
            <Plus className="w-4 h-4" />
            Add Story
          </button>
        </div>

        {/* Stories Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {stories.map((story) => (
            <div key={story.id} className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className={`${story.bgGradient} h-32 relative`}>
                <div className="absolute inset-0 flex items-center justify-center text-white">
                  <div className="text-center">
                    <h3 className="font-bold text-lg">{story.name}</h3>
                    <p className="text-sm opacity-90">{story.subtitle}</p>
                  </div>
                </div>
              </div>
              <div className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className={`px-2 py-1 rounded text-xs font-medium ${
                    story.isActive 
                      ? 'bg-green-100 text-green-800' 
                      : 'bg-red-100 text-red-800'
                  }`}>
                    {story.isActive ? 'Active' : 'Inactive'}
                  </span>
                  <div className="flex gap-2">
                    <button
                      onClick={() => setPreviewStory(story)}
                      className="text-blue-600 hover:text-blue-800"
                    >
                      <Eye className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleEditStory(story)}
                      className="text-gray-600 hover:text-gray-800"
                    >
                      <Edit className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleDeleteStory(story.id)}
                      className="text-red-600 hover:text-red-800"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleToggleActive(story.id)}
                      className="text-green-600 hover:text-green-800"
                    >
                      {story.isActive ? '⏸️' : '▶️'}
                    </button>
                  </div>
                </div>
                <p className="text-gray-600 text-sm">{story.description}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Story Form Modal */}
        {showForm && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-xl shadow-xl w-full max-w-2xl max-h-[90vh] overflow-auto">
              <div className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-bold text-gray-900">
                    {editingStory ? 'Edit Story' : 'Add New Story'}
                  </h2>
                  <button
                    onClick={handleCancelForm}
                    className="text-gray-400 hover:text-gray-600"
                  >
                    <X className="w-6 h-6" />
                  </button>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Name
                    </label>
                    <input
                      type="text"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      placeholder="e.g., Fashion Shop"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Image
                    </label>
                    <div className="flex items-center gap-2">
                      <input
                        type="text"
                        value={formData.image}
                        onChange={(e) => setFormData({ ...formData, image: e.target.value })}
                        className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        placeholder="Image URL"
                      />
                      <button
                        onClick={() => setShowFilePicker('image')}
                        className="px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                      >
                        <Upload className="w-4 h-4" />
                      </button>
                    </div>
                    {formData.image && (
                      <div className="mt-2">
                        <img src={formData.image} alt="Preview" className="w-full h-32 object-cover rounded-lg" />
                        <p className="text-xs text-gray-500 mt-1">URL: {formData.image}</p>
                      </div>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Person Image
                    </label>
                    <div className="flex items-center gap-2">
                      <input
                        type="text"
                        value={formData.personImage}
                        onChange={(e) => setFormData({ ...formData, personImage: e.target.value })}
                        className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        placeholder="Person Image URL"
                      />
                      <button
                        onClick={() => setShowFilePicker('personImage')}
                        className="px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                      >
                        <Upload className="w-4 h-4" />
                      </button>
                    </div>
                    {formData.personImage && (
                      <div className="mt-2">
                        <img src={formData.personImage} alt="Person Preview" className="w-20 h-20 object-cover rounded-full border-2 border-gray-300" />
                        <p className="text-xs text-gray-500 mt-1">URL: {formData.personImage}</p>
                      </div>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Other Fields
                    </label>
                    <input
                      type="text"
                      value={formData.subtitle}
                      onChange={(e) => setFormData({ ...formData, subtitle: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent mb-2"
                      placeholder="Subtitle"
                    />
                    <input
                      type="text"
                      value={formData.title}
                      onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent mb-2"
                      placeholder="Title"
                    />
                    <textarea
                      value={formData.description}
                      onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent mb-2"
                      placeholder="Description"
                      rows={3}
                    />
                    <input
                      type="text"
                      value={formData.link}
                      onChange={(e) => setFormData({ ...formData, link: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      placeholder="Link URL"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Background Gradient
                    </label>
                    <div className="grid grid-cols-5 gap-2">
                      {gradientOptions.map((option) => (
                        <button
                          key={option.name}
                          onClick={() => setFormData({ ...formData, bgGradient: option.value })}
                          className={`h-12 rounded-lg border-2 ${
                            formData.bgGradient === option.value ? 'border-gray-900' : 'border-transparent'
                          } ${option.value}`}
                          title={option.name}
                        />
                      ))}
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-end gap-4 mt-6 pt-6 border-t">
                  <button
                    onClick={handleCancelForm}
                    className="px-4 py-2 text-gray-600 hover:text-gray-800"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleSaveStory}
                    className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center gap-2"
                  >
                    <Save className="w-4 h-4" />
                    Save Story
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* File Picker Modal */}
        {showFilePicker && (
          <FilePicker
            isOpen={true}
            onClose={() => setShowFilePicker(null)}
            onSelect={handleFileSelect}
            title="Select Image"
          />
        )}

        {/* Preview Modal */}
        {previewStory && (
          <div className="fixed inset-0 bg-black bg-opacity-80 flex items-center justify-center z-50 p-2">
            <div className="relative w-full max-w-xs h-full max-h-[85vh]">
              <div className={`${previewStory.bgGradient} rounded-2xl overflow-hidden h-full relative shadow-2xl`}>
                <button
                  onClick={() => setPreviewStory(null)}
                  className="absolute top-4 right-4 z-20 w-8 h-8 bg-black bg-opacity-50 rounded-full flex items-center justify-center text-white hover:bg-opacity-70"
                >
                  <X className="w-4 h-4" />
                </button>
                <div className="p-6 h-full flex flex-col justify-between text-white">
                  <div>
                    <h3 className="text-sm font-medium opacity-90 mb-1">
                      {previewStory.subtitle}
                    </h3>
                  </div>
                  <div>
                    <h2 className="text-lg font-light mb-2">{previewStory.title}</h2>
                    <h3 className="text-xl font-bold mb-4">
                      {previewStory.subtitle}
                    </h3>
                    <p className="text-base opacity-90">{previewStory.description}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminStories;
