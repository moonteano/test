import React, { useState, useEffect } from 'react';
import { Routes, Route, Link, useLocation } from 'react-router-dom';
import { 
  BarChart3, 
  Users, 
  Package, 
  ShoppingCart, 
  Plus,
  TrendingUp,
  DollarSign,
  MessageSquare,
  Bell,
  FolderOpen,
  BookOpen,
  Tag
} from 'lucide-react';
import { DashboardStats } from '../../types';
import { adminAPI } from '../../services/api';

// Lazy load admin components
const AdminUsers = React.lazy(() => import('./AdminUsers'));
const AdminProducts = React.lazy(() => import('./AdminProducts'));
const AdminOrders = React.lazy(() => import('./AdminOrders'));
const AdminCoupons = React.lazy(() => import('./AdminCoupons'));
const AdminMessages = React.lazy(() => import('./AdminMessages'));
const AdminNotifications = React.lazy(() => import('./AdminNotifications'));
const AdminFileManager = React.lazy(() => import('./AdminFileManager'));
const AdminStories = React.lazy(() => import('./AdminStories'));
const CategoryOrderManager = React.lazy(() => import('./CategoryOrderManager'));

const AdminDashboard: React.FC = () => {
  const location = useLocation();
  const [stats, setStats] = useState<DashboardStats>({
    totalUsers: 0,
    totalProducts: 0,
    totalOrders: 0,
    totalRevenue: 0
  });

  useEffect(() => {
    fetchDashboardStats();
  }, []);

  const fetchDashboardStats = async () => {
    try {
      const statsData = await adminAPI.getDashboard();
      setStats(statsData);
    } catch (error) {
      console.error('Error fetching dashboard stats:', error);
    }
  };

  const navigation = [
    { name: 'Dashboard', href: '/admin', icon: BarChart3 },
    { name: 'Users', href: '/admin/users', icon: Users },
    { name: 'Products', href: '/admin/products', icon: Package },
    { name: 'Orders', href: '/admin/orders', icon: ShoppingCart },
    { name: 'Coupons', href: '/admin/coupons', icon: Tag },
    { name: 'Stories', href: '/admin/stories', icon: BookOpen },
    { name: 'Messages', href: '/admin/messages', icon: MessageSquare },
    { name: 'Notifications', href: '/admin/notifications', icon: Bell },
    { name: 'File Manager', href: '/admin/files', icon: FolderOpen },
  ];

  const statCards = [
    {
      title: 'Total Users',
      value: stats.totalUsers,
      icon: Users,
      color: 'bg-blue-500',
      change: '+12%'
    },
    {
      title: 'Total Products',
      value: stats.totalProducts,
      icon: Package,
      color: 'bg-green-500',
      change: '+8%'
    },
    {
      title: 'Total Orders',
      value: stats.totalOrders,
      icon: ShoppingCart,
      color: 'bg-purple-500',
      change: '+23%'
    },
    {
      title: 'Total Revenue',
      value: `${stats.totalRevenue.toFixed(2)} Lei`,
      icon: DollarSign,
      color: 'bg-yellow-500',
      change: '+15%'
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="flex">
        {/* Sidebar */}
        <div className="w-64 bg-white shadow-sm border-r min-h-screen">
          <div className="p-6">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">A</span>
              </div>
              <span className="text-xl font-bold text-gray-900">Admin Panel</span>
            </div>
          </div>
          
          <nav className="px-4 pb-4">
            <ul className="space-y-2">
              {navigation.map((item) => {
                const Icon = item.icon;
                const isActive = location.pathname === item.href;
                
                return (
                  <li key={item.name}>
                    <Link
                      to={item.href}
                      className={`flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${
                        isActive
                          ? 'bg-blue-50 text-blue-600 border border-blue-200'
                          : 'text-gray-700 hover:bg-gray-50'
                      }`}
                    >
                      <Icon className="w-5 h-5" />
                      <span className="font-medium">{item.name}</span>
                    </Link>
                  </li>
                );
              })}
            </ul>
          </nav>
        </div>

        {/* Main Content */}
        <div className="flex-1">
          <div className="p-8">
            <React.Suspense fallback={
              <div className="flex items-center justify-center py-12">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
              </div>
            }>
              <Routes>
                <Route path="/" element={
                  <div>
                    <div className="mb-8">
                      <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
                      <p className="text-gray-600 mt-2">Welcome to the admin dashboard</p>
                    </div>

                    {/* Stats Cards */}
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                      {statCards.map((card, index) => {
                        const Icon = card.icon;
                        return (
                          <div key={index} className="bg-white rounded-xl shadow-sm border p-6">
                            <div className="flex items-center justify-between">
                              <div>
                                <p className="text-sm text-gray-600 mb-1">{card.title}</p>
                                <p className="text-2xl font-bold text-gray-900">{card.value}</p>
                                <div className="flex items-center mt-2">
                                  <TrendingUp className="w-4 h-4 text-green-500 mr-1" />
                                  <span className="text-sm text-green-500 font-medium">{card.change}</span>
                                </div>
                              </div>
                              <div className={`w-12 h-12 ${card.color} rounded-lg flex items-center justify-center`}>
                                <Icon className="w-6 h-6 text-white" />
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>

                    {/* Quick Actions */}
                    <div className="bg-white rounded-xl shadow-sm border p-6">
                      <h2 className="text-xl font-semibold text-gray-900 mb-4">Quick Actions</h2>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <Link
                          to="/admin/products"
                          className="flex items-center space-x-3 p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
                        >
                          <Plus className="w-5 h-5 text-blue-600" />
                          <span className="font-medium">Add New Product</span>
                        </Link>
                        <Link
                          to="/admin/orders"
                          className="flex items-center space-x-3 p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
                        >
                          <ShoppingCart className="w-5 h-5 text-green-600" />
                          <span className="font-medium">View Orders</span>
                        </Link>
                        <Link
                          to="/admin/users"
                          className="flex items-center space-x-3 p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
                        >
                          <Users className="w-5 h-5 text-purple-600" />
                          <span className="font-medium">Manage Users</span>
                        </Link>
                      </div>
                    </div>

                    {/* Reordonare Categorii */}
                    <div className="bg-white rounded-xl shadow-sm border p-6 mt-8">
                      <h2 className="text-xl font-semibold text-gray-900 mb-4">Ordine Categorii Filtru Produse</h2>
                      <CategoryOrderManager />
                    </div>
                  </div>
                } />
                <Route path="/users" element={<AdminUsers />} />
                <Route path="/products" element={<AdminProducts />} />
                <Route path="/orders" element={<AdminOrders />} />
                <Route path="/coupons" element={<AdminCoupons />} />
                <Route path="/stories" element={<AdminStories />} />
                <Route path="/messages" element={<AdminMessages />} />
                <Route path="/notifications" element={<AdminNotifications />} />
                <Route path="/files" element={<AdminFileManager />} />
              </Routes>
            </React.Suspense>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
