import React, { useEffect, useState } from 'react';
import { adminAPI } from '../../services/api';

const fetchTableList = () => adminAPI.getSQLTables();
const fetchTableData = (table: string) => adminAPI.getSQLTable(table);
const updateTableRow = (table: string, id: number, data: any) => adminAPI.updateSQLRow(table, id, data);
const addTableRow = (table: string, data: any) => adminAPI.addSQLRow(table, data);
const deleteTableRow = (table: string, id: number) => adminAPI.deleteSQLRow(table, id);
const runSQL = async (query: string) => adminAPI.runSQL(query);

const AdminSQLPage: React.FC = () => {
  const [tables, setTables] = useState<string[]>([]);
  const [selectedTable, setSelectedTable] = useState<string | null>(null);
  const [tableData, setTableData] = useState<{ columns: string[]; rows: any[] } | null>(null);
  const [editRow, setEditRow] = useState<any | null>(null);
  const [addRow, setAddRow] = useState<any | null>(null);
  const [error, setError] = useState('');
  const [sqlQuery, setSQLQuery] = useState('');
  const [sqlResult, setSQLResult] = useState<any>(null);
  const [sqlError, setSQLError] = useState('');

  useEffect(() => {
    fetchTableList().then(setTables).catch(() => setTables([]));
  }, []);

  useEffect(() => {
    if (selectedTable) {
      fetchTableData(selectedTable)
        .then(setTableData)
        .catch(() => setTableData(null));
    }
  }, [selectedTable]);

  const handleEdit = (row: any) => setEditRow({ ...row });
  const handleEditChange = (col: string, value: any) => setEditRow((r: any) => ({ ...r, [col]: value }));
  const handleEditSave = async () => {
    if (!selectedTable || !editRow) return;
    try {
      await updateTableRow(selectedTable, editRow.id, editRow);
      setEditRow(null);
      setTableData(await fetchTableData(selectedTable));
    } catch (e: any) {
      setError(e.message || 'Eroare la salvare.');
    }
  };
  const handleEditCancel = () => setEditRow(null);

  const handleAdd = () => {
    if (!tableData) return;
    const empty = Object.fromEntries(tableData.columns.map(c => [c, '']));
    setAddRow(empty);
  };
  const handleAddChange = (col: string, value: any) => setAddRow((r: any) => ({ ...r, [col]: value }));
  const handleAddSave = async () => {
    if (!selectedTable || !addRow) return;
    try {
      await addTableRow(selectedTable, addRow);
      setAddRow(null);
      setTableData(await fetchTableData(selectedTable));
    } catch (e: any) {
      setError(e.message || 'Eroare la adăugare.');
    }
  };
  const handleAddCancel = () => setAddRow(null);

  const handleDelete = async (row: any) => {
    if (!selectedTable || !window.confirm('Sigur ștergi această linie?')) return;
    try {
      await deleteTableRow(selectedTable, row.id);
      setTableData(await fetchTableData(selectedTable));
    } catch (e: any) {
      setError(e.message || 'Eroare la ștergere.');
    }
  };

  const handleRunSQL = async () => {
    setSQLError('');
    setSQLResult(null);
    try {
      const result = await runSQL(sqlQuery);
      setSQLResult(result);
    } catch (e: any) {
      setSQLError(e.message || 'Eroare la execuția SQL.');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Sidebar with tables */}
      <div className="w-64 bg-white border-r p-4">
        <h2 className="font-bold text-lg mb-4">Tabele</h2>
        <ul className="space-y-2">
          {tables.map((t) => (
            <li key={t}>
              <button
                className={`w-full text-left px-3 py-2 rounded-lg ${selectedTable === t ? 'bg-blue-100 text-blue-700' : 'hover:bg-gray-100'}`}
                onClick={() => setSelectedTable(t)}
              >
                {t}
              </button>
            </li>
          ))}
        </ul>
      </div>
      {/* Main content: table viewer/editor */}
      <div className="flex-1 p-8">
        {selectedTable && tableData ? (
          <div>
            <div className="flex items-center justify-between mb-4">
              <h1 className="text-2xl font-bold text-gray-900">{selectedTable}</h1>
              <button onClick={handleAdd} className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">Adaugă rând</button>
            </div>
            {error && <div className="text-red-600 mb-2">{error}</div>}
            <div className="overflow-x-auto">
              <table className="min-w-full border text-xs">
                <thead>
                  <tr>
                    {tableData.columns.map((col) => (
                      <th key={col} className="border px-2 py-1 bg-gray-100">{col}</th>
                    ))}
                    <th className="border px-2 py-1 bg-gray-100">Acțiuni</th>
                  </tr>
                </thead>
                <tbody>
                  {addRow && (
                    <tr>
                      {tableData.columns.map((col) => (
                        <td key={col} className="border px-2 py-1">
                          <input
                            className="w-full border rounded px-1 py-0.5"
                            value={addRow[col] || ''}
                            onChange={e => handleAddChange(col, e.target.value)}
                          />
                        </td>
                      ))}
                      <td className="border px-2 py-1">
                        <button onClick={handleAddSave} className="bg-blue-600 text-white px-2 py-1 rounded mr-1">Salvează</button>
                        <button onClick={handleAddCancel} className="bg-gray-300 text-gray-800 px-2 py-1 rounded">Anulează</button>
                      </td>
                    </tr>
                  )}
                  {tableData.rows.map((row) => (
                    editRow && editRow.id === row.id ? (
                      <tr key={row.id} className="bg-yellow-50">
                        {tableData.columns.map((col) => (
                          <td key={col} className="border px-2 py-1">
                            <input
                              className="w-full border rounded px-1 py-0.5"
                              value={editRow[col] || ''}
                              onChange={e => handleEditChange(col, e.target.value)}
                            />
                          </td>
                        ))}
                        <td className="border px-2 py-1">
                          <button onClick={handleEditSave} className="bg-blue-600 text-white px-2 py-1 rounded mr-1">Salvează</button>
                          <button onClick={handleEditCancel} className="bg-gray-300 text-gray-800 px-2 py-1 rounded">Anulează</button>
                        </td>
                      </tr>
                    ) : (
                      <tr key={row.id}>
                        {tableData.columns.map((col) => (
                          <td key={col} className="border px-2 py-1">{row[col]}</td>
                        ))}
                        <td className="border px-2 py-1">
                          <button onClick={() => handleEdit(row)} className="bg-yellow-500 text-white px-2 py-1 rounded mr-1">Editează</button>
                          <button onClick={() => handleDelete(row)} className="bg-red-600 text-white px-2 py-1 rounded">Șterge</button>
                        </td>
                      </tr>
                    )
                  ))}
                </tbody>
              </table>
              {(!tableData.rows || tableData.rows.length === 0) && <div className="text-gray-500 mt-2">Niciun rezultat.</div>}
            </div>
            {/* SQL Console */}
            <div className="mt-8">
              <h2 className="text-lg font-bold mb-2">SQL Console</h2>
              <textarea
                className="w-full border rounded p-2 mb-2 font-mono text-xs"
                rows={3}
                value={sqlQuery}
                onChange={e => setSQLQuery(e.target.value)}
                placeholder="Ex: SELECT * FROM products;"
              />
              <button
                onClick={handleRunSQL}
                className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
              >
                Rulează SQL
              </button>
              {sqlError && <div className="text-red-600 mt-2">{sqlError}</div>}
              {sqlResult && (
                <div className="mt-4">
                  <pre className="bg-gray-100 p-2 rounded text-xs overflow-x-auto">{JSON.stringify(sqlResult, null, 2)}</pre>
                </div>
              )}
            </div>
          </div>
        ) : (
          <div className="text-gray-500 text-lg">Selectează un tabel pentru a vizualiza datele.</div>
        )}
      </div>
    </div>
  );
};

export default AdminSQLPage;
