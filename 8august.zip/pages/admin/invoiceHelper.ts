// Helper for PDF invoice generation in admin
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { Order } from '../../types';

export function generateInvoice(order: Order) {
  const doc = new jsPDF();
  doc.setFontSize(18);
  doc.text('Factura', 14, 18);
  doc.setFontSize(12);
  doc.text(`Numar comanda: #${order.orderNumber}`, 14, 30);
  doc.text(`Data: ${new Date(order.createdAt).toLocaleDateString()}`, 14, 38);
  doc.text(`Client: ${order.firstName || ''} ${order.lastName || ''}`, 14, 46);
  doc.text(`Email: ${order.email || ''}`, 14, 54);

  let shipping: any = null;
  try {
    shipping = order.shippingAddress ? JSON.parse(order.shippingAddress) : null;
  } catch {}
  if (shipping) {
    doc.text(`Adresa: ${shipping.address || ''}, ${shipping.city || ''}, ${shipping.zipCode || ''}`, 14, 62);
    if (shipping.phone) doc.text(`Telefon: ${shipping.phone}`, 14, 70);
  }

  // Table with products
  let items: any[] = [];
  if (Array.isArray(order.items)) {
    items = order.items;
  } else if (typeof order.items === 'string' && (order.items as string).length > 0) {
    items = (order.items as string).split(',').map((str: string) => {
      const match = str.match(/^(.*) x(\d+)$/);
      if (match) {
        return { name: match[1].trim(), quantity: match[2], price: '' };
      }
      return { name: str.trim(), quantity: '', price: '' };
    });
  }

  if (items.length > 0) {
    autoTable(doc, {
      startY: 80,
      head: [['Produs', 'Cantitate', 'Pret/unit']],
      body: items.map((item: any) => [
        item.name,
        item.quantity,
        (item.price !== undefined && item.price !== null && item.price !== '') ? `${Number(item.price).toFixed(2)} Lei` : ''
      ]),
    });
    const finalY = (doc as any).lastAutoTable?.finalY || 90;
    doc.text(`Total: ${order.totalAmount.toFixed(2)} Lei`, 14, finalY + 10);
  } else {
    doc.text('Nu există produse în această comandă.', 14, 90);
  }
  doc.save(`Factura_${order.orderNumber}.pdf`);
}
