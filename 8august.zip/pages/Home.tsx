"use client"

import React, { useState, useEffect, useRef, useMemo, useCallback, lazy, Suspense } from "react"
import { Link } from "react-router-dom"
import {
  ShoppingBag,
  TrendingUp,
  Shield,
  Truck,
  Headphones,
  ChevronRight,
  Play,
  Award,
  Users,
  Leaf,
} from "lucide-react"
import { FaWhatsapp } from "react-icons/fa"
import ProductCard from "../components/ProductCard"
import type { Product } from "../types"
import { productsAPI, storiesAPI, toAssetUrl } from "../services/api"

// Lazy load heavy components
const AccessibilityMenu = lazy(() => import("../components/AccessibilityMenu"))
const StoryModal = lazy(() => import("../components/StoryModal"))

// Modern Hero Section with enhanced visual appeal
const HeroSection = React.memo(() => (
  <section className="relative min-h-[600px] flex items-center justify-center overflow-hidden bg-gradient-to-br from-nature-50 via-white to-sage-50">
    {/* Background decorative elements */}
    <div className="absolute inset-0">
      <div className="absolute top-20 left-10 w-32 h-32 bg-nature-200/20 rounded-full blur-3xl"></div>
      <div className="absolute bottom-20 right-10 w-40 h-40 bg-earth-200/20 rounded-full blur-3xl"></div>
      <div className="absolute top-1/2 left-1/4 w-24 h-24 bg-sage-200/20 rounded-full blur-2xl"></div>
    </div>

    <div className="relative z-10 max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
      <div className="mb-6">
        <span className="inline-flex items-center px-4 py-2 rounded-full bg-nature-100 text-nature-700 text-sm font-medium mb-4">
          <Leaf className="w-4 h-4 mr-2" />
          100% Produse Naturale
        </span>
      </div>

      <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold mb-6 leading-tight">
        <span className="bg-gradient-to-r from-nature-600 via-nature-700 to-earth-600 bg-clip-text text-transparent">
          Simplitatea
        </span>
        <br />
        <span className="text-sage-900">Naturii</span>
      </h1>

      <p className="text-lg md:text-xl text-sage-600 mb-8 max-w-3xl mx-auto leading-relaxed">
        Descoperă o lume de produse naturale, atent selecționate pentru o viață sănătoasă și echilibrată. Fără
        artificii, doar esențialul naturii.
      </p>

      <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12">
        <Link
          to="/products"
          className="group bg-gradient-to-r from-nature-500 to-nature-600 hover:from-nature-600 hover:to-nature-700 text-white font-semibold px-8 py-4 rounded-2xl shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300 flex items-center"
        >
          <span>Explorează Produsele</span>
          <ChevronRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
        </Link>

        <button className="group flex items-center text-sage-700 hover:text-nature-600 font-medium transition-colors">
          <div className="w-12 h-12 bg-white shadow-lg rounded-full flex items-center justify-center mr-3 group-hover:shadow-xl transition-shadow">
            <Play className="w-5 h-5 text-nature-600 ml-1" />
          </div>
          <span>Vezi Povestea Noastră</span>
        </button>
      </div>

      {/* Trust indicators */}
      <div className="flex flex-wrap justify-center items-center gap-8 text-sm text-sage-500">
        <div className="flex items-center">
          <Award className="w-4 h-4 mr-2 text-nature-500" />
          <span>Certificat Organic</span>
        </div>
        <div className="flex items-center">
          <Users className="w-4 h-4 mr-2 text-nature-500" />
          <span>1000+ Clienți Mulțumiți</span>
        </div>
        <div className="flex items-center">
          <Shield className="w-4 h-4 mr-2 text-nature-500" />
          <span>Garanție 30 Zile</span>
        </div>
      </div>
    </div>
  </section>
))

// Enhanced Features Section
const FeaturesSection = React.memo(() => (
  <section className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="text-center mb-16">
        <h2 className="text-3xl md:text-4xl font-bold text-sage-900 mb-4">De Ce Să Ne Alegi Pe Noi?</h2>
        <p className="text-lg text-sage-600 max-w-2xl mx-auto">
          Tehnologiile și standardele pe care le folosim sunt aliniate cu cele europene, garantând calitatea și
          siguranța produselor noastre.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
        {[
          {
            icon: Shield,
            title: "100% Natural",
            description: "Produse certificate organic, fără adaosuri chimice sau conservanți artificiali",
            color: "nature",
          },
          {
            icon: Truck,
            title: "Livrare Rapidă",
            description: "Livrare în 24-48h în toată țara, cu ambalaje eco-friendly",
            color: "earth",
          },
          {
            icon: Headphones,
            title: "Suport Expert",
            description: "Echipa noastră de specialiști te ghidează în alegerea produselor potrivite",
            color: "sage",
          },
          {
            icon: TrendingUp,
            title: "Calitate Premium",
            description: "Standarde înalte de calitate, testate și verificate în laboratoare specializate",
            color: "nature",
          },
        ].map(({ icon: Icon, title, description, color }, index) => (
          <div key={index} className="group">
            <div className="bg-gradient-to-br from-white to-gray-50 rounded-3xl p-8 shadow-sm hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 border border-gray-100">
              <div
                className={`w-16 h-16 bg-gradient-to-br from-${color}-100 to-${color}-200 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform`}
              >
                <Icon className={`w-8 h-8 text-${color}-600`} />
              </div>
              <h3 className="text-xl font-bold text-sage-900 mb-3">{title}</h3>
              <p className="text-sage-600 leading-relaxed">{description}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  </section>
))

// Modern Stats Section
const StatsSection = React.memo(({ statsVisible }: { statsVisible: boolean }) => (
  <section className="py-20 bg-gradient-to-r from-nature-600 via-nature-700 to-earth-600 relative overflow-hidden">
    <div className="absolute inset-0 bg-black/10"></div>
    <div className="relative z-10 max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="text-center mb-12">
        <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Încrederea Clienților Noștri</h2>
        <p className="text-nature-100 text-lg">Cifre care vorbesc despre calitatea și dedicarea noastră</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
        <AnimatedStat
          value={2004}
          suffix=""
          label="Anul înființării"
          isVisible={statsVisible}
          delay={0}
          isYear={true}
        />
        <AnimatedStat value={50} suffix="+" label="Produse disponibile" isVisible={statsVisible} delay={200} />
        <AnimatedStat value={1000} suffix="+" label="Clienți mulțumiți" isVisible={statsVisible} delay={400} />
        <AnimatedStat value={99} suffix="%" label="Satisfacție client" isVisible={statsVisible} delay={600} />
      </div>
    </div>
  </section>
))

// Enhanced Newsletter Section
const NewsletterSection = React.memo(() => (
  <section className="py-20 bg-gradient-to-br from-sage-50 to-nature-50">
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
      <div className="bg-white rounded-3xl shadow-xl p-8 md:p-12">
        <div className="mb-8">
          <h2 className="text-3xl md:text-4xl font-bold text-sage-900 mb-4">Rămâi Conectat cu Natura</h2>
          <p className="text-lg text-sage-600 max-w-2xl mx-auto">
            Alătură-te comunității noastre și primește actualizări despre produse noi, rețete sănătoase și sfaturi
            pentru un stil de viață natural.
          </p>
        </div>

        <form className="flex flex-col sm:flex-row gap-4 max-w-lg mx-auto mb-6">
          <input
            type="email"
            placeholder="Adresa ta de email"
            className="flex-1 px-6 py-4 rounded-2xl border-2 border-sage-200 focus:border-nature-500 focus:ring-4 focus:ring-nature-100 transition-all outline-none"
          />
          <button
            type="submit"
            className="bg-gradient-to-r from-earth-500 to-earth-600 hover:from-earth-600 hover:to-earth-700 text-white font-semibold px-8 py-4 rounded-2xl shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300"
          >
            Abonează-te
          </button>
        </form>

        <p className="text-sm text-sage-500">Nu spam, doar conținut valoros. Poți să te dezabonezi oricând.</p>
      </div>
    </div>
  </section>
))

// Enhanced WhatsApp Button
const WhatsAppButton = React.memo(() => (
  <div className="fixed bottom-6 left-6 z-50">
    <a
      href={`https://wa.me/PHONE_NUMBER?text=${encodeURIComponent("Salut! Am o întrebare despre produsele voastre.")}`}
      target="_blank"
      rel="noopener noreferrer"
      className="group flex items-center bg-green-500 hover:bg-green-600 text-white rounded-full shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105"
    >
      <div className="flex items-center px-4 py-3">
        <FaWhatsapp className="w-6 h-6" />
        <span className="ml-3 font-medium hidden sm:block group-hover:block">Contactează-ne</span>
      </div>
    </a>
  </div>
))

const Home: React.FC = () => {
  const [featuredProducts, setFeaturedProducts] = useState<Product[]>([])
  const [storyCategories, setStoryCategories] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedStory, setSelectedStory] = useState<number | null>(null)
  const [statsVisible, setStatsVisible] = useState(false)
  const statsRef = useRef<HTMLElement>(null)

  const fetchFeaturedProducts = useCallback(async () => {
    try {
      const products = await productsAPI.getAll({ featured: true })
      setFeaturedProducts(products.slice(0, 8))
    } catch (error) {
      console.error("Error fetching featured products:", error)
    } finally {
      setLoading(false)
    }
  }, [])

  const fetchStoryCategories = useCallback(async () => {
    try {
      const stories = await storiesAPI.getAll()
      setStoryCategories(stories)
    } catch (error) {
      console.error("Error fetching story categories:", error)
    }
  }, [])

  useEffect(() => {
    Promise.all([fetchFeaturedProducts(), fetchStoryCategories()])
  }, [fetchFeaturedProducts, fetchStoryCategories])

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting && !statsVisible) {
            setStatsVisible(true)
          }
        })
      },
      { threshold: 0.3, rootMargin: "50px" },
    )

    if (statsRef.current) {
      observer.observe(statsRef.current)
    }

    return () => observer.disconnect()
  }, [statsVisible])

  const StoryCategoriesSection = useMemo(
    () => (
      <section className="py-16 bg-gradient-to-br from-white to-sage-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-sage-900 mb-4">Poveștile Noastre</h2>
            <p className="text-lg text-sage-600">Descoperă povestea din spatele fiecărui produs natural</p>
          </div>

          <div className="flex gap-6 overflow-x-auto scrollbar-hide pb-4">
            {storyCategories.map((category) => (
              <div key={category.id} className="flex-shrink-0">
                <div
                  className={`${category.bgGradient} rounded-3xl p-6 w-64 h-80 cursor-pointer hover:scale-105 transition-all duration-300 relative overflow-hidden shadow-lg hover:shadow-xl`}
                  onClick={() => setSelectedStory(category.id)}
                >
                  {category.image && (
                    <div
                      className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-20"
                      style={{ backgroundImage: `url(${toAssetUrl(category.image)})` }}
                    />
                  )}

                  <div className="relative z-10 text-white h-full flex flex-col justify-between">
                    <div>
                      <h3 className="font-bold text-xl leading-tight mb-3 whitespace-pre-line">{category.name}</h3>
                      <p className="text-white/90 text-sm leading-relaxed">{category.description}</p>
                    </div>

                    {category.personImage && (
                      <div className="flex items-center">
                        <img
                          src={toAssetUrl(category.personImage) || "/placeholder.svg"}
                          alt="Person"
                          className="w-12 h-12 rounded-full border-2 border-white object-cover mr-3"
                          loading="lazy"
                        />
                        <div className="text-sm">
                          <div className="font-medium">Expert Natural</div>
                          <div className="text-white/80">Specialist</div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    ),
    [storyCategories],
  )

  const FeaturedProductsSection = useMemo(
    () => (
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-12">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-sage-900 mb-4">Produse Recomandate</h2>
              <p className="text-lg text-sage-600">Selecție premium din cele mai apreciate produse naturale</p>
            </div>
            <Link
              to="/products"
              className="hidden sm:inline-flex items-center text-nature-600 hover:text-nature-700 font-semibold group"
            >
              <span>Vezi toate produsele</span>
              <ChevronRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
            </Link>
          </div>

          {loading ? (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {[...Array(8)].map((_, index) => (
                <div key={index} className="bg-white rounded-2xl shadow-sm border p-4 animate-pulse">
                  <div className="h-48 bg-sage-100 rounded-xl mb-4"></div>
                  <div className="h-4 bg-sage-100 rounded mb-2"></div>
                  <div className="h-3 bg-sage-100 rounded mb-3"></div>
                  <div className="h-6 bg-sage-100 rounded"></div>
                </div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {featuredProducts.map((product) => (
                <div key={product.id} className="group">
                  <ProductCard product={product} viewMode="grid" />
                </div>
              ))}
            </div>
          )}

          <div className="text-center mt-12">
            <Link
              to="/products"
              className="inline-flex items-center bg-gradient-to-r from-earth-500 to-earth-600 hover:from-earth-600 hover:to-earth-700 text-white font-semibold px-8 py-4 rounded-2xl shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300"
            >
              <ShoppingBag className="w-5 h-5 mr-2" />
              Explorează Toate Produsele
            </Link>
          </div>
        </div>
      </section>
    ),
    [featuredProducts, loading],
  )

  return (
    <div className="min-h-screen bg-white">
      <HeroSection />
      {StoryCategoriesSection}
      <FeaturesSection />
      <div ref={statsRef}>
        <StatsSection statsVisible={statsVisible} />
      </div>
      {FeaturedProductsSection}
      <NewsletterSection />
      <WhatsAppButton />

      <Suspense fallback={null}>
        {selectedStory && (
          <StoryModal
            selectedStory={selectedStory}
            storyCategories={storyCategories}
            onClose={() => setSelectedStory(null)}
          />
        )}
        <AccessibilityMenu />
      </Suspense>
    </div>
  )
}

interface AnimatedStatProps {
  value: number
  suffix: string
  label: string
  isVisible: boolean
  delay: number
  isYear?: boolean
}

const AnimatedStat: React.FC<AnimatedStatProps> = React.memo(
  ({ value, suffix, label, isVisible, delay, isYear = false }) => {
    const [displayValue, setDisplayValue] = useState(0)
    const [hasAnimated, setHasAnimated] = useState(false)

    useEffect(() => {
      if (isVisible && !hasAnimated) {
        const timer = setTimeout(() => {
          const duration = 2000
          const steps = 60
          const stepValue = value / steps
          const stepDelay = duration / steps

          let currentStep = 0
          const interval = setInterval(() => {
            currentStep++
            if (currentStep <= steps) {
              setDisplayValue(Math.min(currentStep * stepValue, value))
            } else {
              setDisplayValue(value)
              clearInterval(interval)
            }
          }, stepDelay)

          setHasAnimated(true)
          return () => clearInterval(interval)
        }, delay)

        return () => clearTimeout(timer)
      }
    }, [isVisible, hasAnimated, value, delay])

    const formatValue = () => {
      if (isYear) {
        return Math.floor(displayValue).toString()
      }
      return Math.floor(displayValue)
    }

    return (
      <div
        className={`text-center transform transition-all duration-1000 ${
          isVisible ? "translate-y-0 opacity-100" : "translate-y-8 opacity-0"
        }`}
        style={{ transitionDelay: `${delay}ms` }}
      >
        <div className="text-4xl md:text-5xl font-bold mb-2 text-white">
          <span className="inline-block transition-all duration-500 ease-out">
            {formatValue()}
            {suffix}
          </span>
        </div>
        <div className="text-nature-100 font-medium">{label}</div>
      </div>
    )
  },
)

export default Home
