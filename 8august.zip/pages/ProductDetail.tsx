import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ShoppingCart, Star, Heart, Truck, Shield, ArrowLeft, Plus, Minus, Send } from 'lucide-react';
import { Product } from '../types';
import { productsAPI, cartAPI, toAssetUrl } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { useNotifications } from '../hooks/useNotifications';
import ProductCard from '../components/ProductCard';

interface Review {
  id: number;
  userId: number;
  userName: string;
  rating: number;
  title?: string;
  comment: string;
  createdAt: string;
}

const ProductDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { isAuthenticated, user } = useAuth();
  const { showSuccess, showError } = useNotifications();
  const [product, setProduct] = useState<Product | null>(null);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [loading, setLoading] = useState(true);
  const [quantity, setQuantity] = useState(1);
  const [addingToCart, setAddingToCart] = useState(false);
  const [isFavorite, setIsFavorite] = useState(false);
  const [showReviewForm, setShowReviewForm] = useState(false);
  const [reviewForm, setReviewForm] = useState({
    rating: 5,
    title: '',
    comment: ''
  });
  const [visibleReviews, setVisibleReviews] = useState(3);
  // Mobile search bar state
  const [isMobile, setIsMobile] = useState(false);
  const [showAddToCartPopup, setShowAddToCartPopup] = useState(false);
  const [recommendations, setRecommendations] = useState<Product[]>([]);
  useEffect(() => {
    const checkMobile = () => setIsMobile(window.innerWidth < 768);
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  useEffect(() => {
    if (id) {
      fetchProduct();
      fetchReviews();
      checkIfFavorite();
    }
  }, [id]);

  const fetchProduct = async () => {
    try {
      const productData = await productsAPI.getById(Number(id));
      setProduct(productData);
    } catch (error) {
      console.error('Error fetching product:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchReviews = async () => {
    try {
      const reviewsData = await productsAPI.getReviews(Number(id));
      setReviews(reviewsData);
    } catch (error) {
      console.error('Error fetching reviews:', error);
    }
  };

  const checkIfFavorite = async () => {
    if (!isAuthenticated) return;
    try {
      const favorites = await productsAPI.getFavorites();
      setIsFavorite(favorites.some((fav: any) => fav.productId === Number(id)));
    } catch (error) {
      console.error('Error checking favorites:', error);
    }
  };

  const handleAddToCart = async () => {
    if (!isAuthenticated || user?.role !== 'user') {
      showError('Autentificare necesară', 'Te rugăm să te autentifici ca și client pentru a adăuga produse în coș');
      return;
    }
    if (!product) return;
    setAddingToCart(true);
    try {
      await cartAPI.addItem(product.id, quantity);
      setShowAddToCartPopup(true);
      // Recomandări: un produs din fiecare categorie (excluzând categoria produsului adăugat)
      const categories = await productsAPI.getCategories();
      const allProducts = await productsAPI.getAll();
      const recs: Product[] = [];
      for (const cat of categories) {
        const found = allProducts.find(p => p.category === cat && p.id !== product.id);
        if (found) recs.push(found);
      }
      setRecommendations(recs);
    } catch (error) {
      console.error('Error adding to cart:', error);
      showError('Eroare', 'Nu s-a putut adăuga produsul în coș');
    } finally {
      setAddingToCart(false);
    }
  };

  const toggleFavorite = async () => {
    if (!isAuthenticated || user?.role !== 'user') {
      showError('Autentificare necesară', 'Te rugăm să te autentifici pentru a adăuga la favorite');
      return;
    }

    try {
      if (isFavorite) {
        await productsAPI.removeFromFavorites(Number(id));
        showSuccess('Removed from Favorites', 'Product removed from your favorites');
      } else {
        await productsAPI.addToFavorites(Number(id));
        showSuccess('Added to Favorites', 'Product added to your favorites');
      }
      setIsFavorite(!isFavorite);
    } catch (error) {
      console.error('Error toggling favorite:', error);
      showError('Eroare', 'Nu s-a putut actualiza lista de favorite');
    }
  };

  const submitReview = async () => {
    if (!isAuthenticated || user?.role !== 'user') {
      showError('Autentificare necesară', 'Te rugăm să te autentifici pentru a lăsa o recenzie');
      return;
    }
    if (!reviewForm.comment.trim()) {
      showError('Recenzie necesară', 'Te rugăm să scrii un comentariu pentru recenzie');
      return;
    }
    
    console.log('Submitting review:', { 
      productId: id, 
      reviewData: reviewForm,
      user: user
    });
    
    try {
      await productsAPI.addReview(Number(id), reviewForm);
      showSuccess('Recenzie adăugată!', 'Mulțumim pentru recenzie');
      setReviewForm({ rating: 5, title: '', comment: '' });
      setShowReviewForm(false);
      await fetchReviews();
    } catch (error: any) {
      console.error('Error adding review:', error);
      console.error('Error response:', error?.response);
      
      if (error?.response?.status === 404) {
        showError('Eroare', 'API-ul pentru recenzii nu este disponibil momentan');
      } else if (error?.response?.status === 500) {
        const errorMessage = error?.response?.data?.error || 'Eroare internă de server';
        showError('Eroare server', `Eroare 500: ${errorMessage}`);
      } else if (error?.response?.data?.error === 'You have already reviewed this product twice') {
        showError('Limită recenzii', 'Poți lăsa maxim 2 review-uri la acest produs!');
      } else if (error?.response?.data?.error === 'You have already reviewed this product') {
        showError('Recenzie existentă', 'Ai deja un review la acest produs!');
      } else if (error?.response?.status === 401) {
        showError('Neautorizat', 'Sesiunea a expirat. Te rugăm să te autentifici din nou');
      } else {
        const errorMessage = error?.response?.data?.message || error?.message || 'Eroare necunoscută';
        showError('Eroare', `Nu s-a putut adăuga recenzia: ${errorMessage}`);
      }
    }
  };

  const adjustQuantity = (change: number) => {
    const newQuantity = quantity + change;
    if (newQuantity >= 1) {
      setQuantity(newQuantity);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-nature-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-4 border-nature-200 border-t-nature-500 mb-4 mx-auto"></div>
          <p className="text-sage-600 font-medium">Încarcă detaliile produsului...</p>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen bg-nature-50 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-sage-900 mb-4">Produsul nu a fost găsit</h2>
          <button
            onClick={() => navigate('/products')}
            className="btn-nature"
          >
            Înapoi la produse
          </button>
        </div>
      </div>
    );
  }

  const discountPercentage = product.discountPrice 
    ? Math.round(((product.price - product.discountPrice) / product.price) * 100)
    : 0;

  const finalPrice = product.discountPrice || product.price;

  return (
    <div className="min-h-screen bg-gray-50">
      <AddToCartPopup
        product={product}
        open={showAddToCartPopup}
        onClose={() => setShowAddToCartPopup(false)}
        recommendations={recommendations}
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Breadcrumb */}
        <div className="flex items-center space-x-2 text-sm text-sage-600 mb-8">
          <button
            onClick={() => navigate('/products')}
            className="flex items-center hover:text-nature-600 transition-colors"
          >
            <ArrowLeft className="w-4 h-4 mr-1" />
            Înapoi la produse
          </button>
          <span>/</span>
          <span>{product.category}</span>
          <span>/</span>
          <span className="text-sage-900">{product.name}</span>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Product Image */}
          <div className="space-y-4">
            <div className="card-organic relative w-full aspect-[4/3] bg-gray-100 rounded-3xl overflow-hidden flex items-center justify-center">
              <img
                src={toAssetUrl(product.imageUrl)}
                alt={product.name}
                className="w-full h-full object-cover object-center"
                style={{ minHeight: '100%', minWidth: '100%' }}
              />
              {product.featured && (
                <span className="absolute top-4 left-4 bg-nature-500 text-white text-sm px-3 py-1 rounded-full font-medium shadow-organic">
                  Recomandat
                </span>
              )}
              {discountPercentage > 0 && (
                <span className="absolute top-4 right-4 bg-earth-500 text-white text-sm px-3 py-1 rounded-full font-medium shadow-earth animate-pulse">
                  -{discountPercentage}% REDUCERE
                </span>
              )}
            </div>
          </div>

          {/* Product Info */}
          <div className="space-y-6">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-nature-600 font-medium bg-nature-50 px-3 py-1 rounded-full border border-nature-200">
                  {product.category}
                </span>
                <button 
                  onClick={toggleFavorite}
                  className={`transition-colors p-2 rounded-full hover:bg-earth-50 ${isFavorite ? 'text-earth-500' : 'text-sage-400 hover:text-earth-500'}`}
                >
                  <Heart className={`w-6 h-6 ${isFavorite ? 'fill-current' : ''}`} />
                </button>
              </div>
              <h1 className="text-3xl font-bold text-sage-900 mb-2">{product.name}</h1>
              <div className="flex items-center space-x-2 mb-4">
                <div className="flex items-center">
                  {[...Array(5)].map((_, i) => {
                    const avgRating = reviews.length > 0 ? reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length : 0;
                    return <Star key={i} className={`w-5 h-5 ${i < avgRating ? 'text-yellow-400 fill-current' : 'text-gray-300'}`} />;
                  })}
                </div>
                {reviews.length > 0 ? (
                  <span className="text-gray-600">
                    ({(reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length).toFixed(1)}) • {reviews.length} recenzii
                  </span>
                ) : (
                  <span className="text-gray-400 italic">Încă nu există evaluări</span>
                )}
              </div>
            </div>

            {/* Price */}
            <div className="space-y-2">
              <div className="flex items-center space-x-3">
                <span className="text-3xl font-bold text-gray-900">
                  {finalPrice.toFixed(2)} Lei
                </span>
                {product.discountPrice && (
                  <span className="text-xl text-gray-500 line-through">
                    {product.price.toFixed(2)} Lei
                  </span>
                )}
              </div>
              {discountPercentage > 0 && (
                <p className="text-green-600 font-medium">
                  Economisești {(product.price - product.discountPrice!).toFixed(2)} Lei ({discountPercentage}%)
                </p>
              )}
            </div>

            {/* Description */}
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Descriere</h3>
              <p className="text-gray-600 leading-relaxed">{product.description}</p>
            </div>

            {/* Product Details */}
            <div className="grid grid-cols-2 gap-4 py-4 border-t border-b border-gray-200">
              <div>
                <span className="text-sm text-gray-500">Brand</span>
                <p className="font-medium text-gray-900">{product.brand}</p>
              </div>
              <div>
                <span className="text-sm text-gray-500">Disponibilitate</span>
                <p className={`font-medium ${
                  product.inStock ? 'text-green-600' : 'text-red-600'
                }`}>
                  {product.inStock ? 'În stoc' : 'Indisponibil'}
                </p>
              </div>
            </div>

            {/* Quantity and Add to Cart */}
            {product.inStock && (
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Cantitate
                  </label>
                  <div className="flex items-center space-x-3">
                    <button
                      onClick={() => adjustQuantity(-1)}
                      disabled={quantity <= 1}
                      className="w-10 h-10 rounded-lg border border-gray-300 flex items-center justify-center hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      <Minus className="w-4 h-4" />
                    </button>
                    <span className="text-xl font-semibold w-12 text-center">{quantity}</span>
                    <button
                      onClick={() => adjustQuantity(1)}
                      className="w-10 h-10 rounded-lg border border-gray-300 flex items-center justify-center hover:bg-gray-50"
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                <div className="flex space-x-4">
                  <button
                    onClick={handleAddToCart}
                    disabled={addingToCart || !isAuthenticated || user?.role !== 'user'}
                    className="flex-1 btn-nature disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
                  >
                    <ShoppingCart className="w-5 h-5" />
                    <span>{addingToCart ? 'Se adaugă...' : 'Adaugă în coș'}</span>
                  </button>
                  <button className="btn-outline-nature">
                    Cumpără acum
                  </button>
                </div>
              </div>
            )}

            {/* Out of Stock Message */}
            {!product.inStock && (
              <div className="p-4 bg-earth-50 border border-earth-200 rounded-2xl">
                <p className="text-earth-800 font-medium">Acest produs nu este momentan în stoc.</p>
              </div>
            )}

            {/* Features */}
            <div className="space-y-3 pt-6">
              <div className="flex items-center space-x-3 text-sage-600">
                <Truck className="w-5 h-5 text-nature-600" />
                <span>Livrare gratuită pentru comenzi peste 50 Lei</span>
              </div>
              <div className="flex items-center space-x-3 text-sage-600">
                <Shield className="w-5 h-5 text-nature-600" />
                <span>Garanție de returnare în 30 de zile</span>
              </div>
            </div>
          </div>
        </div>

        {/* Reviews Section */}
        <div className="mt-16">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-2xl font-bold text-sage-900">Recenzii clienți</h2>
            {isAuthenticated && user?.role === 'user' && (
              <button
                onClick={() => setShowReviewForm(!showReviewForm)}
                className="btn-nature"
              >
                Scrie o recenzie
              </button>
            )}
          </div>

          {/* Review Form */}
          {showReviewForm && (
            <div className="card-organic p-6 mb-8">
              <h3 className="text-lg font-semibold text-sage-900 mb-4">Scrie o recenzie</h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-sage-700 mb-2">Evaluare</label>
                  <div className="flex items-center space-x-1">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        onClick={() => setReviewForm({...reviewForm, rating: star})}
                        className={`w-8 h-8 transition-colors ${star <= reviewForm.rating ? 'text-earth-400' : 'text-sage-300'}`}
                      >
                        <Star className="w-full h-full fill-current" />
                      </button>
                    ))}
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-sage-700 mb-2">Titlul recenziei</label>
                  <input
                    type="text"
                    value={reviewForm.title}
                    onChange={(e) => setReviewForm({...reviewForm, title: e.target.value})}
                    className="input-nature mb-2"
                    placeholder="Titlu scurt pentru recenzia ta..."
                  />
                </div>
                <div>                    <label className="block text-sm font-medium text-sage-700 mb-2">Recenzia</label>
                  <textarea
                    value={reviewForm.comment}
                    onChange={(e) => setReviewForm({...reviewForm, comment: e.target.value})}
                    rows={4}
                    className="input-nature resize-none"
                    placeholder="Împărtășește experiența ta cu acest produs..."
                  />
                </div>
                <div className="flex items-center space-x-4">
                  <button
                    onClick={submitReview}
                    className="btn-nature flex items-center space-x-2"
                  >
                    <Send className="w-4 h-4" />
                    <span>Trimite recenzia</span>
                  </button>
                  <button
                    onClick={() => setShowReviewForm(false)}
                    className="text-sage-600 hover:text-sage-800 px-4 py-2 rounded-2xl hover:bg-sage-50 transition-colors"
                  >
                    Anulează
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Reviews List */}
          <div className="space-y-6">
            {reviews.slice(0, visibleReviews).map((review) => {
              const isOwnReview = isAuthenticated && user && review.userId === user.id;
              return (
                <div key={review.id} className="card-organic p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h4 className="font-semibold text-sage-900">{review.userName}</h4>
                      {review.title && (
                        <div className="text-base font-semibold text-nature-700 mb-1">{review.title}</div>
                      )}
                      <div className="flex items-center space-x-2 mt-1">
                        <div className="flex items-center">
                          {[...Array(5)].map((_, i) => (
                            <Star key={i} className={`w-4 h-4 ${i < review.rating ? 'text-earth-400 fill-current' : 'text-sage-300'}`} />
                          ))}
                        </div>
                        <span className="text-sm text-sage-500">
                          {new Date(review.createdAt).toLocaleDateString()}
                        </span>
                      </div>
                    </div>
                    {isOwnReview && (
                      <button
                        className="text-earth-600 hover:text-earth-700 hover:bg-earth-50 px-3 py-1 rounded-2xl text-sm font-medium transition-colors"
                        onClick={async () => {
                          try {
                            await productsAPI.deleteReview(Number(id), review.id);
                            showSuccess('Recenzia a fost ștearsă!', 'Recenzia ta a fost ștearsă.');
                            await fetchReviews();
                          } catch (err) {
                            showError('Eroare', 'Nu s-a putut șterge recenzia');
                          }
                        }}
                      >
                        Șterge recenzia
                      </button>
                    )}
                  </div>
                  <p className="text-sage-700 mb-4">{review.comment}</p>
                </div>
              );
            })}
            {reviews.length > visibleReviews && (
              <div className="text-center mt-4">
                <button
                  className="text-nature-600 hover:text-nature-700 font-medium px-6 py-2 rounded-2xl hover:bg-nature-50 transition-colors"
                  onClick={() => setVisibleReviews(visibleReviews + 5)}
                >
                  Arată mai multe recenzii
                </button>
              </div>
            )}
            {reviews.length === 0 && (
              <div className="text-center py-12 text-gray-500">
                <p>Încă nu există recenzii. Fii primul care evaluează acest produs!</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

const AddToCartPopup: React.FC<{
  product: Product;
  open: boolean;
  onClose: () => void;
  recommendations: Product[];
}> = ({ product, open, onClose, recommendations }) => {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center bg-black bg-opacity-40">
      <div className="bg-white rounded-xl shadow-xl mt-12 w-full max-w-2xl sm:max-w-2xl relative animate-slide-in mx-2">
        <button
          className="absolute top-4 right-4 text-gray-400 hover:text-gray-600 text-2xl"
          onClick={onClose}
        >
          &times;
        </button>
        <div className="flex flex-col sm:flex-row items-center gap-4 border-b p-4 sm:p-6">
          <img src={toAssetUrl(product.imageUrl)} alt={product.name} className="w-16 h-16 sm:w-20 sm:h-20 object-cover rounded-lg border" />
          <div className="flex-1 min-w-0">
            <div className="font-bold text-base sm:text-lg mb-1 truncate">Produsul a fost adăugat în coș</div>
            <div className="text-gray-700 text-xs sm:text-sm truncate">{product.name}</div>
            <div className="text-earth-600 font-bold text-lg sm:text-xl mt-1">{(product.discountPrice || product.price).toFixed(2)} Lei</div>
          </div>
          <button
            className="sm:ml-auto bg-earth-600 text-white px-3 py-2 sm:px-4 sm:py-2 rounded-lg hover:bg-earth-700 transition-colors text-xs sm:text-base"
            onClick={() => { onClose(); window.location.href = '/cart'; }}
          >
            Vezi detalii coș
          </button>
        </div>
        <div className="p-4 sm:p-6 max-h-96 overflow-y-auto">
          <div className="font-semibold mb-3 sm:mb-4 text-sm sm:text-base">Vezi și alte recomandări</div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 sm:gap-4">
            {recommendations.map((rec) => (
              <ProductCard key={rec.id} product={rec} />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetail;
