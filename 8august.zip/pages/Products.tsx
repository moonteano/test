import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Filter, SlidersHorizontal } from 'lucide-react';
import ProductCard from '../components/ProductCard';
import { Product } from '../types';
import { productsAPI } from '../services/api';

const Products: React.FC = () => {
  const [searchParams] = useSearchParams();
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [viewMode, setViewMode] = useState<'grid' | 'grid-mobile' | 'list'>('grid');
  const [showFilters, setShowFilters] = useState(false);
  const [isMobile, setIsMobile] = useState(false);

  // Filter states
  const [selectedCategory, setSelectedCategory] = useState(searchParams.get('category') || '');
  const [searchQuery, setSearchQuery] = useState(searchParams.get('search') || '');
  const [minPrice, setMinPrice] = useState(searchParams.get('minPrice') || '');
  const [maxPrice, setMaxPrice] = useState(searchParams.get('maxPrice') || '');
  const [sortBy, setSortBy] = useState('newest');

  useEffect(() => {
    fetchCategories();
    fetchProducts();
    
    // Check if mobile
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768);
      if (window.innerWidth < 768 && viewMode === 'grid') {
        setViewMode('grid-mobile');
      }
    };
    
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, [selectedCategory, searchQuery, minPrice, maxPrice, sortBy]);

  const fetchCategories = async () => {
    try {
      const categoriesData = await productsAPI.getCategories();
      setCategories(categoriesData);
    } catch (error) {
      console.error('Error fetching categories:', error);
    }
  };

  const fetchProducts = async () => {
    setLoading(true);
    try {
      const params: any = {};
      if (selectedCategory) params.category = selectedCategory;
      if (searchQuery) params.search = searchQuery;
      if (minPrice) params.minPrice = minPrice;
      if (maxPrice) params.maxPrice = maxPrice;

      const productsData = await productsAPI.getAll(params);
      
      // Sort products
      let sortedProducts = [...productsData];
      switch (sortBy) {
        case 'price-low':
          sortedProducts.sort((a, b) => (a.discountPrice || a.price) - (b.discountPrice || b.price));
          break;
        case 'price-high':
          sortedProducts.sort((a, b) => (b.discountPrice || b.price) - (a.discountPrice || a.price));
          break;
        case 'name':
          sortedProducts.sort((a, b) => a.name.localeCompare(b.name));
          break;
        default: // newest
          sortedProducts.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      }
      
      setProducts(sortedProducts);
    } catch (error) {
      console.error('Error fetching products:', error);
    } finally {
      setLoading(false);
    }
  };

  const clearFilters = () => {
    setSelectedCategory('');
    setSearchQuery('');
    setMinPrice('');
    setMaxPrice('');
    setSortBy('newest');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Produse</h1>
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
            <p className="text-gray-600">
              {loading ? 'Se încarcă...' : `${products.length} produse găsite`}
            </p>
            <div className="flex items-center space-x-4">
              {/* Mobile Filters Button */}
              <button
                onClick={() => setShowFilters(!showFilters)}
                className="lg:hidden bg-nature-600 text-white px-4 py-2 rounded-lg flex items-center space-x-2 hover:bg-nature-700 transition-colors"
              >
                <SlidersHorizontal className="w-4 h-4" />
                <span>Filtre</span>
              </button>

              {/* Sort */}
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-nature-500 focus:border-transparent transition-colors"
              >
                <option value="newest">Cele mai noi</option>
                <option value="price-low">Preț: Crescător</option>
                <option value="price-high">Preț: Descrescător</option>
                <option value="name">Nume: A la Z</option>
              </select>
            </div>
          </div>
        </div>

        <div className="flex flex-col lg:flex-row gap-8">
          {/* Mobile Overlay */}
          {showFilters && (
            <div 
              className="lg:hidden fixed inset-0 bg-black bg-opacity-50 z-40"
              onClick={() => setShowFilters(false)}
            />
          )}
          
          {/* Filters Sidebar */}
          <div className={`lg:w-64 ${showFilters ? 'block' : 'hidden lg:block'} ${showFilters ? 'lg:static fixed inset-x-4 top-4 bottom-4 z-50 lg:z-auto' : ''}`}>
            <div className="bg-white rounded-xl shadow-sm border p-6 sticky top-24 lg:static h-full lg:h-auto overflow-y-auto">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-gray-900">Filtre</h3>
                <div className="flex items-center space-x-2">
                  <button
                    onClick={clearFilters}
                    className="text-sm text-nature-600 hover:text-nature-700 transition-colors"
                  >
                    Resetează Tot
                  </button>
                  {/* Close button for mobile */}
                  <button
                    onClick={() => setShowFilters(false)}
                    className="lg:hidden text-gray-500 hover:text-gray-700 transition-colors ml-2"
                  >
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  </button>
                </div>
              </div>

              {/* Category */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Categoria
                </label>
                {/* Lista verticală de categorii cu "Afișează mai multe" */}
                {(() => {
                  const maxVisible = 6;
                  const [showAll, setShowAll] = React.useState(false);
                  const visibleCategories = showAll ? categories : categories.slice(0, maxVisible);
                  return (
                    <div>
                      <button
                        className={`w-full text-left px-3 py-2 rounded-lg mb-1 border ${selectedCategory === '' ? 'bg-nature-50 text-nature-700 border-nature-200' : 'bg-white text-gray-700 border-gray-300'} hover:bg-nature-100 transition-colors`}
                        onClick={() => setSelectedCategory('')}
                      >
                        Toate categoriile
                      </button>
                      {visibleCategories.map((category) => (
                        <button
                          key={category}
                          className={`w-full text-left px-3 py-2 rounded-lg mb-1 border ${selectedCategory === category ? 'bg-nature-50 text-nature-700 border-nature-200' : 'bg-white text-gray-700 border-gray-300'} hover:bg-nature-100 transition-colors`}
                          onClick={() => setSelectedCategory(category)}
                        >
                          {category}
                        </button>
                      ))}
                      {categories.length > maxVisible && !showAll && (
                        <button
                          className="w-full text-center px-3 py-2 rounded-lg bg-gray-100 text-gray-700 border border-gray-300 mt-2 hover:bg-gray-200 transition"
                          onClick={() => setShowAll(true)}
                        >
                          Afișează mai multe
                        </button>
                      )}
                      {categories.length > maxVisible && showAll && (
                        <button
                          className="w-full text-center px-3 py-2 rounded-lg bg-gray-100 text-gray-700 border border-gray-300 mt-2 hover:bg-gray-200 transition"
                          onClick={() => setShowAll(false)}
                        >
                          Arată mai puține
                        </button>
                      )}
                    </div>
                  );
                })()}
              </div>

              {/* Price Range */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Interval de preț
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="number"
                    value={minPrice}
                    onChange={(e) => setMinPrice(e.target.value)}
                    placeholder="Min"
                    className="border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-nature-500 focus:border-transparent transition-colors"
                  />
                  <input
                    type="number"
                    value={maxPrice}
                    onChange={(e) => setMaxPrice(e.target.value)}
                    placeholder="Max"
                    className="border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-nature-500 focus:border-transparent transition-colors"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Products Grid */}
          <div className="flex-1">
            {loading ? (
              <div className="grid grid-cols-2 md:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-8">
                {[...Array(4)].map((_, index) => (
                  <div key={index} className="bg-white rounded-lg sm:rounded-xl shadow border p-2 flex flex-col h-full relative animate-pulse">
                    <div className="h-32 sm:h-48 bg-nature-100 rounded-xl mb-2"></div>
                    <div className="flex-1 flex flex-col justify-between">
                      <div>
                        <div className="font-semibold text-xs sm:text-sm mb-1 line-clamp-2 bg-gray-200 h-4 w-3/4"></div>
                        <div className="flex items-center text-yellow-400 text-xs mb-1 bg-gray-200 h-3 w-1/2"></div>
                      </div>
                      <div className="flex items-end justify-between mt-2">
                        <div>
                          <div className="text-xs text-gray-400 line-through bg-gray-200 h-3 w-1/3"></div>
                          <div className="text-lg font-bold text-red-600 bg-gray-200 h-5 w-1/2"></div>
                        </div>
                        <button className="bg-blue-600 hover:bg-blue-700 text-white rounded-full p-2 shadow">
                          <svg width="22" height="22" fill="none" viewBox="0 0 24 24"><path d="M6 6h15l-1.5 9h-13z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/><circle cx="9" cy="21" r="1" stroke="currentColor" strokeWidth="2"/><circle cx="19" cy="21" r="1" stroke="currentColor" strokeWidth="2"/></svg>
                        </button>
                      </div>
                    </div>
                    <button className="absolute top-2 right-2 bg-white rounded-full p-1 shadow text-gray-400 hover:text-red-500">
                      <svg width="20" height="20" fill="none" viewBox="0 0 24 24"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41 0.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
                    </button>
                  </div>
                ))}
              </div>
            ) : products.length === 0 ? (
              <div className="text-center py-12">
                <Filter className="w-24 h-24 text-gray-300 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Niciun produs găsit</h3>
                <p className="text-gray-600 mb-4">Încearcă să ajustezi filtrele sau termenii de căutare</p>
                <button
                  onClick={clearFilters}
                  className="bg-earth-600 text-white px-6 py-2 rounded-lg hover:bg-earth-700 transition-colors"
                >
                  Resetează Filtrele
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-8">
                {products.map((product) => (
                  <div key={product.id} className="rounded-lg sm:rounded-xl bg-white shadow border p-2 flex flex-col h-full relative">
                    <ProductCard product={product} viewMode="grid-mobile" />
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Products;
