import React from 'react';

const PrivacyPolicy: React.FC = () => (
  <div className="max-w-3xl mx-auto px-4 py-12">
    <h1 className="text-3xl font-display font-bold mb-6 text-nature-700">Politica de Confidențialitate</h1>
    <div className="prose prose-sage max-w-none">
      <p className="mb-2 text-sm text-right text-gray-500">Data ultimei actualizări: [05/08/2025]</p>
      <h2>1. INTRODUCERE</h2>
      <p>SC APACHE COM SRL, persoană juridică română, cu sediul social în DJ248 31, Lunca Cetățuii 707085, Iași, înregistrată la Registrul Comerțului sub nr. J22/989/2004, având cod unic de înregistrare fiscală 16431883, reprezentată legal prin [NUME REPREZENTANT LEGAL], în calitate de [FUNCȚIE] (denumită în continuare "Operatorul" sau "noi"), în calitate de operator de date cu caracter personal, respectă confidențialitatea datelor dumneavoastră și se obligă să le protejeze în conformitate cu prevederile legale aplicabile, în special cu prevederile Regulamentului (UE) 2016/679 al Parlamentului European și al Consiliului din 27 aprilie 2016 privind protecția persoanelor fizice în ceea ce privește prelucrarea datelor cu caracter personal și privind libera circulație a acestor date și de abrogare a Directivei 95/46/CE (Regulamentul general privind protecția datelor - GDPR).</p>
      <p>Prezenta Politică de Confidențialitate are scopul de a vă informa cu privire la modul în care colectăm, prelucrăm și protejăm datele dumneavoastră cu caracter personal atunci când utilizați site-ul nostru web [ADRESA WEBSITE] ("Site-ul") sau serviciile noastre.</p>
      <p>Vă rugăm să citiți cu atenție această Politică de Confidențialitate pentru a înțelege practicile noastre cu privire la datele dumneavoastră cu caracter personal și modul în care le vom trata.</p>
      <p>Prin accesarea și utilizarea Site-ului, precum și prin furnizarea datelor dumneavoastră, confirmați că ați citit, înțeles și acceptat termenii prezentei Politici de Confidențialitate.</p>
      <h2>2. DEFINIȚII</h2>
      <ul>
        <li>"Date cu caracter personal" - orice informații privind o persoană fizică identificată sau identificabilă ("persoana vizată"); o persoană fizică identificabilă este o persoană care poate fi identificată, direct sau indirect, în special prin referire la un element de identificare, cum ar fi un nume, un număr de identificare, date de localizare, un identificator online, sau la unul sau mai multe elemente specifice, proprii identității sale fizice, fiziologice, genetice, psihice, economice, culturale sau sociale.</li>
        <li>"Prelucrare" - orice operațiune sau set de operațiuni efectuate asupra datelor cu caracter personal sau asupra seturilor de date cu caracter personal, cu sau fără utilizarea de mijloace automatizate, cum ar fi colectarea, înregistrarea, organizarea, structurarea, stocarea, adaptarea sau modificarea, extragerea, consultarea, utilizarea, divulgarea prin transmitere, diseminarea sau punerea la dispoziție în orice alt mod, alinierea sau combinarea, restricționarea, ștergerea sau distrugerea.</li>
        <li>"Operator" - persoana fizică sau juridică, autoritatea publică, agenția sau alt organism care, singur sau împreună cu altele, stabilește scopurile și mijloacele de prelucrare a datelor cu caracter personal.</li>
        <li>"Persoană vizată" - persoana fizică ale cărei date cu caracter personal sunt prelucrate.</li>
        <li>"Destinatar" - persoana fizică sau juridică, autoritatea publică, agenția sau alt organism căreia (căruia) îi sunt divulgate datele cu caracter personal, indiferent dacă este sau nu o parte terță.</li>
        <li>"Consimțământ" - orice manifestare de voință liberă, specifică, informată și lipsită de ambiguitate a persoanei vizate prin care aceasta acceptă, printr-o declarație sau printr-o acțiune fără echivoc, ca datele cu caracter personal care o privesc să fie prelucrate.</li>
      </ul>
      <h2>3. CATEGORII DE DATE CU CARACTER PERSONAL PRELUCRATE</h2>
      <ul>
        <li>În funcție de interacțiunea dumneavoastră cu Site-ul nostru, putem prelucra următoarele categorii de date cu caracter personal:</li>
        <li>3.1.1. Date de identificare și contact: Nume și prenume, Adresă de e-mail, Număr de telefon, Adresă de domiciliu/reședință/livrare, Adresă de facturare</li>
        <li>3.1.2. Date privind contul de utilizator: Nume de utilizator, Parolă (stocată în formă criptată), Istoricul comenzilor, Preferințele de comunicare</li>
        <li>3.1.3. Date privind tranzacțiile: Produsele achiziționate, Data și ora tranzacției, Valoarea tranzacției, Modalitatea de plată aleasă</li>
        <li>3.1.4. Date financiare: Nu stocăm date complete de carduri bancare. În cazul plăților online, acestea sunt procesate în siguranță prin intermediul procesatorului de plăți [NUME PROCESATOR PLĂȚI], conform standardelor de securitate PCI-DSS.</li>
        <li>3.1.5. Date tehnice: Adresa IP, Informații despre dispozitiv și browser, Date de navigare și cookie-uri, Date privind sesiunile de utilizare a Site-ului</li>
        <li>3.1.6. Date de marketing și comunicare: Preferințele dumneavoastră în ceea ce privește primirea comunicărilor de marketing, Răspunsurile dumneavoastră la sondaje și chestionare</li>
        <li>3.1.7. Alte date furnizate voluntar: Informații pe care le furnizați atunci când ne contactați, Recenzii și opinii despre produse sau servicii, Conținut generat de utilizator, cum ar fi comentarii sau imagini încărcate pe Site</li>
        <li>Nu colectăm în mod intenționat date cu caracter personal de la persoane cu vârsta sub 16 ani. Dacă sunteți părinte sau tutore și credeți că copilul dumneavoastră ne-a furnizat date cu caracter personal, vă rugăm să ne contactați pentru a solicita ștergerea acestora.</li>
      </ul>
      <h2>4. SCOPURILE ȘI TEMEIURILE JURIDICE ALE PRELUCRĂRII</h2>
      <ul>
        <li>Prelucrăm datele dumneavoastră cu caracter personal în următoarele scopuri și pe baza următoarelor temeiuri juridice:</li>
        <li>Executarea unui contract la care sunteți parte sau pentru a face demersuri la cererea dumneavoastră înainte de încheierea unui contract (Art. 6 alin. (1) lit. b) din GDPR): Crearea și administrarea contului de utilizator, Procesarea și gestionarea comenzilor, Livrarea produselor comandate, Procesarea plăților, Furnizarea serviciului de asistență clienți, Gestionarea retururilor și a reclamațiilor</li>
        <li>Îndeplinirea unei obligații legale care ne revine (Art. 6 alin. (1) lit. c) din GDPR): Emiterea și păstrarea documentelor financiar-contabile, Soluționarea litigiilor, Respectarea obligațiilor legale privind garanția produselor, Îndeplinirea obligațiilor fiscale</li>
        <li>În baza intereselor noastre legitime (Art. 6 alin. (1) lit. f) din GDPR): Îmbunătățirea produselor și serviciilor noastre, Asigurarea securității Site-ului și a tranzacțiilor, Prevenirea fraudelor, Gestionarea relației cu clienții, Analize de business și statistici, Protejarea drepturilor și intereselor noastre legale</li>
        <li>În baza consimțământului dumneavoastră (Art. 6 alin. (1) lit. a) din GDPR): Marketing direct și comunicări promoționale, Personalizarea experienței pe Site, Studii de piață și sondaje de opinie, Utilizarea cookie-urilor non-esențiale</li>
      </ul>
      <h2>5. PERIOADA DE PĂSTRARE A DATELOR</h2>
      <ul>
        <li>Vom păstra datele dumneavoastră cu caracter personal doar atât timp cât este necesar pentru îndeplinirea scopurilor pentru care au fost colectate, inclusiv în vederea respectării oricăror cerințe legale, contabile sau de raportare.</li>
        <li>Pentru a determina perioada adecvată de păstrare a datelor cu caracter personal, luăm în considerare cantitatea, natura și sensibilitatea datelor, riscul potențial de prejudiciu cauzat de utilizarea sau divulgarea neautorizată a datelor, scopurile pentru care prelucrăm datele și dacă putem atinge aceste scopuri prin alte mijloace, precum și cerințele legale aplicabile.</li>
        <li>În particular, vom păstra datele dumneavoastră în următoarele perioade:</li>
        <li>Datele contului de utilizator: pe durata existenței contului dumneavoastră și încă [X] luni după închiderea acestuia</li>
        <li>Datele privind comenzile și tranzacțiile: [X] ani, conform legislației financiar-contabile</li>
        <li>Datele de marketing: până la retragerea consimțământului sau timp de [X] ani de la ultima interacțiune cu dumneavoastră</li>
        <li>Date tehnice și de navigare: maxim [X] luni</li>
        <li>În anumite circumstanțe, vă putem anonimiza datele cu caracter personal (astfel încât acestea să nu mai poată fi asociate cu dumneavoastră) în scopuri de cercetare sau statistică, caz în care putem utiliza aceste informații pe o perioadă nedeterminată, fără a vă notifica în prealabil.</li>
      </ul>
      <h2>6. DESTINATARII DATELOR CU CARACTER PERSONAL</h2>
      <ul>
        <li>În scopul îndeplinirii activităților noastre și pentru furnizarea serviciilor solicitate, putem divulga datele dumneavoastră cu caracter personal următoarelor categorii de destinatari:</li>
        <li>Furnizori de servicii care acționează ca persoane împuternicite de operator: Furnizori de servicii de găzduire și mentenanță a Site-ului, Procesatori de plăți online, Furnizori de servicii de curierat și livrare, Furnizori de servicii de marketing și comunicare, Furnizori de servicii de asistență clienți, Furnizori de servicii IT și de securitate a datelor</li>
        <li>Autorități publice și organisme de reglementare: Autorități fiscale, Organe de aplicare a legii, Instanțe judecătorești, Alte autorități competente, în conformitate cu legislația aplicabilă</li>
        <li>Alți terți: Consultanți profesionali (avocați, auditori, contabili), Potențiali cumpărători sau investitori în afacerea noastră (în cazul unei vânzări, fuziuni sau reorganizări)</li>
        <li>Solicităm tuturor terților cărora le divulgăm datele dumneavoastră cu caracter personal să respecte securitatea acestora și să le trateze în conformitate cu legislația aplicabilă privind protecția datelor cu caracter personal.</li>
        <li>Nu permitem furnizorilor noștri de servicii terți să utilizeze datele dumneavoastră cu caracter personal în scopuri proprii și le permitem să prelucreze datele dumneavoastră cu caracter personal doar în scopuri specificate și în conformitate cu instrucțiunile noastre.</li>
      </ul>
      <h2>7. TRANSFERUL DATELOR CU CARACTER PERSONAL</h2>
      <ul>
        <li>Unii dintre furnizorii noștri de servicii pot avea sediul în afara Spațiului Economic European (SEE), ceea ce poate implica transferul datelor dumneavoastră cu caracter personal în afara SEE.</li>
        <li>Ori de câte ori transferăm datele dumneavoastră cu caracter personal în afara SEE, ne asigurăm că acestea beneficiază de un nivel de protecție similar prin implementarea cel puțin a uneia dintre următoarele garanții: Transferăm date doar către țări care au fost considerate de Comisia Europeană ca oferind un nivel adecvat de protecție a datelor cu caracter personal, Utilizăm clauze contractuale standard aprobate de Comisia Europeană, În cazul furnizorilor din SUA, putem transfera date către cei care fac parte din mecanismul Privacy Shield (dacă este aplicabil) sau care au implementat clauze contractuale standard</li>
        <li>Puteți obține mai multe informații despre mecanismele de transfer pe care le utilizăm contactându-ne conform secțiunii 13 de mai jos.</li>
      </ul>
      <h2>8. SECURITATEA DATELOR</h2>
      <ul>
        <li>Am implementat măsuri tehnice și organizatorice adecvate pentru a proteja datele dumneavoastră cu caracter personal împotriva pierderii, utilizării sau accesului neautorizat, modificării sau divulgării accidentale.</li>
        <li>Printre măsurile de securitate implementate se numără: Criptarea datelor sensibile, Protecția prin parolă a sistemelor informatice, Proceduri stricte de control al accesului, Firewall-uri și sisteme de protecție împotriva virușilor și malware, Instruirea regulată a personalului cu privire la importanța confidențialității și securității datelor, Evaluări periodice ale riscurilor și testări de securitate</li>
        <li>Am implementat proceduri pentru a gestiona orice suspiciune de încălcare a securității datelor cu caracter personal și vă vom notifica pe dumneavoastră și orice autoritate de reglementare aplicabilă cu privire la o suspiciune de încălcare a securității datelor, atunci când suntem obligați legal să facem acest lucru.</li>
        <li>Cu toate acestea, trebuie să fiți conștient că nicio metodă de transmitere prin internet sau metodă de stocare electronică nu este 100% sigură, și nu putem garanta securitatea absolută a datelor dumneavoastră.</li>
      </ul>
      <h2>9. COOKIE-URI ȘI TEHNOLOGII SIMILARE</h2>
      <ul>
        <li>Site-ul nostru utilizează cookie-uri și tehnologii similare pentru a vă îmbunătăți experiența de navigare, pentru a analiza modul în care interacționați cu Site-ul nostru și pentru a personaliza conținutul și publicitatea în funcție de interesele dumneavoastră.</li>
        <li>Un cookie este un mic fișier text care este stocat pe dispozitivul dumneavoastră atunci când vizitați un site web. Cookie-urile ne permit să recunoaștem dispozitivul dumneavoastră și să stocăm informații despre preferințele dumneavoastră sau activitățile anterioare pe Site-ul nostru.</li>
        <li>Utilizăm următoarele tipuri de cookie-uri:</li>
        <li>Cookie-uri strict necesare: Acestea sunt esențiale pentru funcționarea Site-ului și vă permit să utilizați funcționalitățile sale de bază. Nu puteți refuza aceste cookie-uri dacă doriți să utilizați Site-ul nostru</li>
        <li>Cookie-uri de preferințe: Acestea ne permit să memorăm informații care modifică comportamentul sau aspectul Site-ului, cum ar fi limba preferată sau regiunea în care vă aflați. Puteți bloca sau șterge aceste cookie-uri, dar acest lucru poate afecta funcționalitatea Site-ului</li>
        <li>Cookie-uri statistice: Acestea ne ajută să înțelegem modul în care utilizatorii interacționează cu Site-ul, colectând și raportând informații în mod anonim. Ne ajută să îmbunătățim funcționalitatea Site-ului</li>
        <li>Cookie-uri de marketing: Acestea sunt utilizate pentru a vă urmări activitatea pe Site și pe alte site-uri web. Scopul este de a afișa reclame personalizate în funcție de interesele dumneavoastră. Acestea stochează informații despre preferințele dumneavoastră și alegerile făcute pe Site</li>
        <li>Puteți controla și gestiona cookie-urile în diverse moduri. Majoritatea browserelor web vă permit să controlați cookie-urile prin setările de preferințe. Pentru informații despre cum puteți gestiona cookie-urile, vă rugăm să vizitați pagina de ajutor a browserului dumneavoastră.</li>
        <li>De asemenea, puteți seta preferințele dumneavoastră privind cookie-urile prin intermediul bannerului de cookie-uri afișat la prima vizită pe Site-ul nostru.</li>
        <li>Vă rugăm să rețineți că blocarea anumitor cookie-uri poate afecta funcționalitatea Site-ului și experiența dumneavoastră de utilizare.</li>
        <li>Informații detaliate despre cookie-urile utilizate pe Site-ul nostru și scopurile pentru care le utilizăm pot fi găsite în [POLITICA NOASTRĂ DE COOKIE-URI] disponibilă pe Site.</li>
      </ul>
      <h2>10. DREPTURILE DUMNEAVOASTRĂ</h2>
      <ul>
        <li>În conformitate cu GDPR, aveți următoarele drepturi cu privire la datele dumneavoastră cu caracter personal:</li>
        <li>Dreptul de acces (Art. 15 din GDPR): Dreptul de a obține confirmarea dacă prelucrăm sau nu date cu caracter personal care vă privesc și, în caz afirmativ, acces la datele respective și la informații despre modul în care sunt prelucrate.</li>
        <li>Dreptul la rectificare (Art. 16 din GDPR): Dreptul de a obține, fără întârzieri nejustificate, rectificarea datelor inexacte sau completarea datelor incomplete.</li>
        <li>Dreptul la ștergere ("dreptul de a fi uitat") (Art. 17 din GDPR): Dreptul de a obține ștergerea datelor care vă privesc, fără întârzieri nejustificate, în anumite condiții prevăzute de lege.</li>
        <li>Dreptul la restricționarea prelucrării (Art. 18 din GDPR): Dreptul de a obține restricționarea prelucrării în anumite cazuri prevăzute de lege.</li>
        <li>Dreptul la portabilitatea datelor (Art. 20 din GDPR): Dreptul de a primi datele care vă privesc într-un format structurat, utilizat în mod curent și care poate fi citit automat, precum și dreptul de a transmite aceste date altui operator.</li>
        <li>Dreptul la opoziție (Art. 21 din GDPR): Dreptul de a vă opune, din motive legate de situația particulară în care vă aflați, prelucrării datelor bazate pe interesul nostru legitim, inclusiv creării de profiluri. Dreptul de a vă opune oricând prelucrării în scopuri de marketing direct.</li>
        <li>Dreptul de a nu face obiectul unei decizii bazate exclusiv pe prelucrarea automată (Art. 22 din GDPR): Dreptul de a nu face obiectul unei decizii bazate exclusiv pe prelucrarea automată, inclusiv crearea de profiluri, care produce efecte juridice care vă privesc sau vă afectează în mod similar într-o măsură semnificativă.</li>
        <li>Dreptul de a retrage consimțământul: Atunci când prelucrarea se bazează pe consimțământul dumneavoastră, aveți dreptul să îl retrageți în orice moment, fără a afecta legalitatea prelucrării efectuate pe baza consimțământului înainte de retragerea acestuia.</li>
        <li>Pentru a vă exercita oricare dintre aceste drepturi, vă rugăm să ne contactați utilizând datele de contact prevăzute în secțiunea 13 de mai jos.</li>
        <li>Nu veți fi supus niciunei discriminări pentru exercitarea acestor drepturi.</li>
        <li>În cazul în care considerați că prelucrarea datelor dumneavoastră cu caracter personal încalcă prevederile GDPR, aveți dreptul de a depune o plângere la autoritatea de supraveghere competentă, în special în statul membru din Uniunea Europeană în care aveți reședința obișnuită, în care se află locul dumneavoastră de muncă sau în care a avut loc presupusa încălcare. În România, autoritatea de supraveghere este Autoritatea Națională de Supraveghere a Prelucrării Datelor cu Caracter Personal (ANSPDCP), cu sediul în B-dul G-ral. Gheorghe Magheru nr. 28-30, Sector 1, cod poștal 010336, București, România, www.dataprotection.ro.</li>
      </ul>
      <h2>11. MODIFICĂRI ALE POLITICII DE CONFIDENȚIALITATE</h2>
      <ul>
        <li>Ne rezervăm dreptul de a actualiza și modifica prezenta Politică de Confidențialitate ori de câte ori este necesar, pentru a reflecta modificările legislative, modificările practicilor noastre de afaceri sau evoluțiile tehnologice.</li>
        <li>Versiunea actualizată va fi publicată pe Site, cu indicarea datei ultimei actualizări.</li>
        <li>Vă recomandăm să verificați periodic această Politică de Confidențialitate pentru a fi informat cu privire la modul în care protejăm datele dumneavoastră cu caracter personal.</li>
        <li>Continuarea utilizării Site-ului nostru după publicarea modificărilor aduse Politicii de Confidențialitate va fi considerată drept acceptare a acestor modificări.</li>
      </ul>
      <h2>12. LINKURI CĂTRE ALTE SITE-URI</h2>
      <ul>
        <li>Site-ul nostru poate conține linkuri către alte site-uri web, aplicații și servicii furnizate de terți.</li>
        <li>Aceste linkuri externe sunt furnizate doar pentru confortul dumneavoastră și nu implică aprobarea sau asumarea responsabilității din partea noastră pentru conținutul sau practicile de confidențialitate ale acestor site-uri terțe.</li>
        <li>Dacă accesați aceste linkuri, veți părăsi Site-ul nostru. Nu avem control asupra conținutului sau disponibilității acestor site-uri și nu suntem responsabili pentru politicile de confidențialitate sau practicile operatorilor acestor site-uri.</li>
        <li>Vă recomandăm să citiți politicile de confidențialitate ale oricărui site web pe care îl vizitați.</li>
      </ul>
      <h2>13. CONTACT</h2>
      <ul>
        <li>Pentru orice întrebări sau solicitări cu privire la prezenta Politică de Confidențialitate sau la prelucrarea datelor dumneavoastră cu caracter personal, vă rugăm să ne contactați utilizând următoarele date de contact:</li>
      </ul>
      <p>
        <b>Denumire:</b> [NUMELE COMPANIEI]<br />
        <b>Adresă:</b> [ADRESA COMPLETĂ]<br />
        <b>E-mail:</b> [ADRESA DE E-MAIL PENTRU PROTECȚIA DATELOR]<br />
        <b>Telefon:</b> [NUMĂR DE TELEFON]<br />
        <b>Persoana responsabilă cu protecția datelor:</b> [NUME RESPONSABIL / FUNCȚIE]
      </p>
      <p>Vom răspunde solicitării dumneavoastră fără întârzieri nejustificate și, în orice caz, în termen de o lună de la primirea cererii. Această perioadă poate fi prelungită cu două luni atunci când este necesar, ținând seama de complexitatea și numărul cererilor. Vă vom informa cu privire la orice astfel de prelungire în termen de o lună de la primirea cererii, prezentând și motivele întârzierii.</p>
      <h2>14. DISPOZIȚII FINALE</h2>
      <ul>
        <li>Prezenta Politică de Confidențialitate, împreună cu Termenii și Condițiile noastre, stabilește baza pe care orice date cu caracter personal pe care le colectăm de la dumneavoastră, sau pe care ni le furnizați, vor fi prelucrate de noi.</li>
        <li>Legea aplicabilă prezentei Politici de Confidențialitate este legea română, iar orice litigiu va fi soluționat de instanțele judecătorești competente din România.</li>
      </ul>
      <p className="mt-6 text-sm text-right text-gray-500">Ultima actualizare: [ZZ/LL/AAAA]</p>
      <p className="mt-2 text-xs text-center text-gray-400">© [AN] [NUMELE COMPANIEI]. Toate drepturile rezervate.</p>
    </div>
  </div>
);

export default PrivacyPolicy;
