import React from 'react';

const Terms: React.FC = () => (
  <div className="max-w-3xl mx-auto px-4 py-12">
    <h1 className="text-3xl font-display font-bold mb-6 text-nature-700">Termeni și Condiții</h1>
    <div className="prose prose-sage max-w-none">
      <p className="mb-2 text-sm text-right text-gray-500">Data ultimei actualizări: [05/08/2025]</p>
      <h2>1. DISPOZIȚII GENERALE</h2>
      <p>Prezentul document stabilește termenii și condițiile de utilizare a site-ului web <b>apachecom.ro</b> ("apachecom.ro"), operat de societatea comercială <b>SC APACHE COM SRL</b>, persoană juridică română, cu sediul social în <b>DJ248 31, Lunca Cetățuii 707085, Iași</b>, înregistrată la Registrul Comerțului sub nr. <b>J22/989/2004</b>, având cod unic de înregistrare fiscală <b>16431883</b>, reprezentată legal prin <b>[NUME REPREZENTANT LEGAL]</b>, în calitate de <b>[FUNCȚIE]</b> (denumită în continuare "Vânzătorul" sau "Operatorul").</p>
      <p>Accesarea, vizitarea și/sau utilizarea Site-ului implică acceptarea integrală, expresă și neechivocă a tuturor termenilor și condițiilor conținute în prezentul document.</p>
      <p>Vânzătorul își rezervă dreptul de a modifica unilateral, în orice moment și fără notificare prealabilă, conținutul acestor termeni și condiții. Modificările devin aplicabile și opozabile utilizatorilor de la data publicării lor pe Site.</p>
      <p>În cazul în care oricare dintre clauzele prezentelor termeni și condiții va fi declarată nulă sau inaplicabilă, din orice motiv, aceasta nu va afecta validitatea celorlalte clauze.</p>
      <h2>2. DEFINIȚII</h2>
      <ul>
        <li>"Client" sau "Utilizator" - persoana fizică sau juridică care utilizează Site-ul și care efectuează o comandă prin intermediul acestuia.</li>
        <li>"Comandă" - document electronic ce reprezintă voința Clientului de a achiziționa produse și/sau servicii de pe Site, reprezentând o acceptare din partea sa a ofertei de vânzare a unuia sau mai multor produse făcută de către Vânzător prin intermediul Site-ului.</li>
        <li>"Contract la distanță" - contractul de vânzare-cumpărare încheiat între Vânzător și Client, fără prezența fizică simultană a acestora.</li>
        <li>"Produs" - bun material oferit spre vânzare prin intermediul Site-ului.</li>
        <li>"Serviciu" - activitate prestată de Vânzător în beneficiul Clientului.</li>
      </ul>
      <h2>3. CONTUL DE UTILIZATOR</h2>
      <ul>
        <li>Pentru a efectua comenzi prin intermediul Site-ului, Clientul trebuie să își creeze un cont de utilizator, furnizând informații corecte, complete și actualizate, așa cum sunt solicitate în formularul de înregistrare.</li>
        <li>Clientul este responsabil pentru păstrarea confidențialității datelor de acces la contul său de utilizator (nume de utilizator și parolă) și pentru toate activitățile care se desfășoară prin intermediul acestuia.</li>
        <li>Clientul se obligă să notifice imediat Vânzătorul cu privire la orice utilizare neautorizată a contului său sau cu privire la orice altă încălcare a securității.</li>
        <li>Vânzătorul își rezervă dreptul de a suspenda, dezactiva sau șterge contul de utilizator, temporar sau permanent, fără notificare prealabilă, în cazul în care consideră că au fost încălcate prezentele termeni și condiții sau în cazul în care există suspiciuni rezonabile privind frauda sau utilizarea abuzivă a Site-ului.</li>
      </ul>
      <h2>4. PROCESUL DE COMANDĂ</h2>
      <ul>
        <li>Produsele și serviciile prezentate pe Site sunt oferite în limita stocului disponibil.</li>
        <li>Prețurile afișate pe Site sunt exprimate în <b>LEI</b> și includ TVA conform legislației în vigoare.</li>
        <li>Pentru a efectua o comandă, Clientul trebuie să parcurgă următorii pași:
          <ul>
            <li>a) Selectarea produselor și/sau serviciilor dorite și adăugarea acestora în coșul de cumpărături;</li>
            <li>b) Completarea informațiilor necesare procesării comenzii (adresa de livrare, modalitatea de plată, etc.);</li>
            <li>c) Verificarea corectitudinii informațiilor furnizate și a produselor selectate;</li>
            <li>d) Confirmarea comenzii prin acționarea butonului "Finalizare comandă" sau similar.</li>
          </ul>
        </li>
        <li>După finalizarea comenzii, Clientul va primi o confirmare a acesteia prin e-mail, la adresa furnizată în contul de utilizator.</li>
        <li>Contractul de vânzare-cumpărare se consideră încheiat în momentul în care Vânzătorul confirmă comanda prin e-mail sau prin alt mijloc de comunicare electronică.</li>
        <li>Vânzătorul își rezervă dreptul de a anula o comandă în următoarele situații, fără a se limita la acestea:
          <ul>
            <li>a) Informațiile furnizate de Client sunt incomplete sau incorecte;</li>
            <li>b) Există suspiciuni rezonabile de fraudă;</li>
            <li>c) Produsele comandate nu mai sunt disponibile în stoc;</li>
            <li>d) Din motive tehnice care nu țin de controlul Vânzătorului.</li>
          </ul>
        </li>
      </ul>
      <h2>5. MODALITĂȚI DE PLATĂ</h2>
      <ul>
        <li>Site-ul acceptă următoarele modalități de plată:
          <ul>
            <li>a) Plata online cu cardul bancar prin intermediul procesatorului de plăți <b>NETOPIA PAYMENTS</b>;</li>
            <li>b) Plata prin transfer bancar (ordin de plată);</li>
            <li>c) Plata ramburs, la livrarea produselor;</li>
          </ul>
        </li>
        <li>În cazul plății online cu cardul bancar, tranzacția se realizează prin intermediul sistemului securizat al procesatorului de plăți, care procesează datele de card conform standardelor de securitate internaționale.</li>
        <li>În cazul plății prin transfer bancar, comanda va fi procesată după confirmarea încasării sumei în contul bancar al Vânzătorului.</li>
        <li>Factura fiscală aferentă comenzii va fi emisă în format electronic și va fi transmisă Clientului prin e-mail sau va fi disponibilă în contul de utilizator.</li>
      </ul>
      <h2>6. LIVRAREA PRODUSELOR</h2>
      <ul>
        <li>Livrarea produselor se face prin intermediul serviciilor de curierat <b>[NUME COMPANII DE CURIERAT]</b> sau prin alte mijloace convenite cu Clientul.</li>
        <li>Termenul de livrare este de <b>1-3</b> zile lucrătoare de la confirmarea comenzii, în funcție de adresa de livrare și de disponibilitatea produselor în stoc.</li>
        <li>Costurile de livrare sunt suportate de către Client, cu excepția cazurilor în care Vânzătorul specifică altfel, și sunt comunicate înainte de finalizarea comenzii.</li>
        <li>La primirea produselor, Clientul are obligația de a verifica integritatea coletului și conformitatea produselor cu comanda plasată. În cazul în care există neconformități, acestea trebuie semnalate imediat curierului și Vânzătorului.</li>
        <li>Riscul de pierdere sau deteriorare a produselor se transferă Clientului în momentul în care acesta sau un terț desemnat de acesta, altul decât transportatorul, intră în posesia fizică a produselor.</li>
      </ul>
      <h2>7. DREPTUL DE RETRAGERE</h2>
      <ul>
        <li>Conform O.U.G. nr. 34/2014 privind drepturile consumatorilor în cadrul contractelor încheiate cu profesioniștii, Clientul beneficiază de o perioadă de 14 zile calendaristice pentru a se retrage din contract, fără a fi nevoit să justifice decizia de retragere și fără a suporta alte costuri decât cele prevăzute de lege.</li>
        <li>Perioada de retragere expiră în termen de 14 zile calendaristice de la:
          <ul>
            <li>a) ziua în care Clientul sau un terț desemnat de acesta, altul decât transportatorul, intră în posesia fizică a produselor (în cazul unui contract de vânzare);</li>
            <li>b) ziua în care Clientul sau un terț desemnat de acesta, altul decât transportatorul, intră în posesia fizică a ultimului produs (în cazul unui contract privind bunuri multiple comandate de consumator printr-o singură comandă și livrate separat).</li>
          </ul>
        </li>
        <li>Pentru a-și exercita dreptul de retragere, Clientul trebuie să informeze Vânzătorul cu privire la decizia sa de retragere din contract printr-o declarație neechivocă, care poate fi transmisă prin:
          <ul>
            <li>a) E-mail la adresa <b>apache_com@yahoo.com</b>;</li>
            <li>b) Poștă la adresa <b>DJ248 31, Lunca Cetățuii 707085, Iași</b>;</li>
            <li>c) Formular de contact disponibil pe Site.</li>
          </ul>
        </li>
        <li>Clientul poate utiliza modelul de formular de retragere disponibil pe Site, dar nu este obligat să folosească acest formular.</li>
        <li>În cazul retragerii din contract, Vânzătorul va rambursa toate sumele primite de la Client, inclusiv costurile de livrare (cu excepția costurilor suplimentare determinate de alegerea de către Client a unei modalități de livrare diferite de modalitatea standard oferită de Vânzător), fără întârzieri nejustificate și, în orice caz, nu mai târziu de 14 zile calendaristice de la data la care este informat cu privire la decizia de retragere.</li>
        <li>Rambursarea se va efectua folosind aceleași modalități de plată ca și cele folosite de Client pentru tranzacția inițială, cu excepția cazului în care Clientul a convenit altfel.</li>
        <li>Vânzătorul poate amâna rambursarea până la data la care primește produsele înapoi sau până la momentul la care Clientul face dovada că a trimis produsele înapoi, fiind valabilă data cea mai apropiată.</li>
        <li>Clientul trebuie să returneze produsele fără întârzieri nejustificate și, în orice caz, nu mai târziu de 14 zile calendaristice de la data la care a comunicat retragerea din contract.</li>
        <li>Clientul va suporta costurile directe legate de returnarea produselor.</li>
        <li>Clientul este responsabil doar pentru diminuarea valorii produselor care rezultă din manipulări, altele decât cele necesare pentru determinarea naturii, calităților și funcționării produselor.</li>
      </ul>
      <h2>8. GARANȚII</h2>
      <ul>
        <li>Toate produsele comercializate pe Site beneficiază de condițiile de garanție conform legislației în vigoare și specificațiilor producătorilor.</li>
        <li>Certificatul de garanție va fi livrat împreună cu produsul comandat și va conține informații cu privire la drepturile conferite prin lege consumatorului și elementele de identificare a produsului.</li>
        <li>Vânzătorul va asigura repararea sau înlocuirea gratuită a produselor în perioada de garanție, conform legislației în vigoare și condițiilor specificate în certificatul de garanție.</li>
        <li>Pentru a beneficia de serviciile de garanție, Clientul trebuie să păstreze factura și certificatul de garanție și să le prezinte în original reprezentanților autorizați.</li>
      </ul>
      <h2>9. POLITICA DE CONFIDENȚIALITATE</h2>
      <ul>
        <li>Vânzătorul respectă confidențialitatea datelor cu caracter personal furnizate de Client și se obligă să le prelucreze în conformitate cu prevederile Regulamentului (UE) 2016/679 privind protecția persoanelor fizice în ceea ce privește prelucrarea datelor cu caracter personal și libera circulație a acestor date (GDPR).</li>
        <li>Informații detaliate cu privire la prelucrarea datelor cu caracter personal sunt disponibile în Politica de Confidențialitate, accesibilă pe Site.</li>
      </ul>
      <h2>10. PROPRIETATE INTELECTUALĂ</h2>
      <ul>
        <li>Toate elementele prezente pe Site (texte, imagini, elemente grafice, logo-uri, etc.) sunt protejate prin legislația privind drepturile de autor și drepturile conexe, precum și prin legislația privind mărcile și sunt proprietatea exclusivă a Vânzătorului sau a partenerilor săi.</li>
        <li>Este interzisă reproducerea, distribuirea, modificarea, afișarea, crearea de lucrări derivate, sau orice altă utilizare a conținutului Site-ului fără acordul prealabil scris al Vânzătorului.</li>
      </ul>
      <h2>11. LIMITAREA RĂSPUNDERII</h2>
      <ul>
        <li>Vânzătorul depune toate eforturile pentru a asigura acuratețea și actualitatea informațiilor prezentate pe Site, însă nu garantează că acestea sunt complete, exacte sau actualizate.</li>
        <li>Vânzătorul nu poate fi ținut responsabil pentru eventualele erori de afișare a prețurilor sau a caracteristicilor produselor, rezervându-și dreptul de a anula comenzile afectate de astfel de erori.</li>
        <li>Vânzătorul nu își asumă răspunderea pentru daunele de orice natură pe care Clientul le-ar putea suferi ca urmare a:
          <ul>
            <li>a) Indisponibilității temporare sau permanente a Site-ului;</li>
            <li>b) Întreruperii funcționării Site-ului din cauze independente de voința Vânzătorului;</li>
            <li>c) Utilizării necorespunzătoare a produselor achiziționate prin intermediul Site-ului;</li>
            <li>d) Imposibilității de livrare a produselor din motive independente de voința Vânzătorului.</li>
          </ul>
        </li>
      </ul>
      <h2>12. FORȚA MAJORĂ</h2>
      <ul>
        <li>Niciuna dintre părți nu va fi răspunzătoare pentru neexecutarea obligațiilor sale contractuale, dacă o astfel de neexecutare este datorată unui eveniment de forță majoră, așa cum este definit de legislația în vigoare.</li>
        <li>Partea care invocă forța majoră este obligată să notifice celeilalte părți, în termen de 5 zile, producerea evenimentului și să ia toate măsurile posibile în vederea limitării consecințelor lui.</li>
      </ul>
      <h2>13. LITIGII</h2>
      <ul>
        <li>Orice litigiu decurgând din sau în legătură cu contractul încheiat între Vânzător și Client se va soluționa pe cale amiabilă. În cazul în care nu se poate ajunge la o înțelegere, litigiul va fi soluționat de instanțele judecătorești competente de la sediul Vânzătorului.</li>
        <li>Clientul poate apela și la soluționarea alternativă a litigiilor, conform O.G. nr. 38/2015 privind soluționarea alternativă a litigiilor dintre consumatori și comercianți, prin intermediul entităților SAL (Soluționarea Alternativă a Litigiilor) competente, disponibile la adresa <b>[LINK CĂTRE LISTA ENTITĂȚILOR SAL]</b>.</li>
        <li>De asemenea, Clientul poate utiliza platforma europeană de soluționare online a litigiilor (SOL), disponibilă la adresa <a href="https://ec.europa.eu/consumers/odr/" target="_blank" rel="noopener noreferrer" className="text-nature-600 underline">https://ec.europa.eu/consumers/odr/</a>.</li>
      </ul>
      <h2>14. DISPOZIȚII FINALE</h2>
      <ul>
        <li>Prezentele termeni și condiții sunt guvernate și interpretate conform legislației române în vigoare.</li>
        <li>Prin utilizarea Site-ului, Clientul confirmă că a citit, înțeles și acceptat integral și necondiționat prezentele termeni și condiții.</li>
        <li>Pentru orice nelămuriri sau informații suplimentare cu privire la prezentele termeni și condiții, vă rugăm să ne contactați la:</li>
      </ul>
      <p>
        <b>Adresă:</b> DJ248 31, Lunca Cetățuii 707085, Iași<br />
        <b>Telefon:</b> 0744 137 032<br />
        <b>E-mail:</b> apache_com@yahoo.com<br />
        <b>Program:</b> Luni - Vineri: 09:00 - 17:00
      </p>
      <p className="mt-6 text-sm text-right text-gray-500">Ultima actualizare: [05/08/2025]</p>
      <p className="mt-2 text-xs text-center text-gray-400">© 2025 SC APACHE COM SRL. Toate drepturile rezervate.</p>
    </div>
  </div>
);

export default Terms;
