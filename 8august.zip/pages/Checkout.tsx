import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { CreditCard, MapPin, User, Phone, Tag } from 'lucide-react';
import { CartItem, ShippingAddress, CouponValidation } from '../types';
import { cartAPI, ordersAPI, couponsAPI, toAssetUrl } from '../services/api';
import { useNotifications } from '../hooks/useNotifications';
import { useCart } from '../context/CartContext';

const Checkout: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { showSuccess, showError } = useNotifications();
  const { updateCartCount } = useCart();
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  
  const [shippingAddress, setShippingAddress] = useState<ShippingAddress>({
    firstName: '',
    lastName: '',
    address: '',
    city: '',
    zipCode: '',
    phone: ''
  });
  
  const [paymentMethod, setPaymentMethod] = useState('credit-card');
  const [notes, setNotes] = useState('');
  
  // Coupon state
  const [couponCode, setCouponCode] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState<CouponValidation | null>(null);
  const [couponLoading, setCouponLoading] = useState(false);
  const [discountError, setDiscountError] = useState<string | null>(null);

  useEffect(() => {
    fetchCartItems();
    // Stripe redirect logic
    const params = new URLSearchParams(location.search);
    const status = params.get('status');
    if (status === 'success') {
      // Recuperează datele comenzii din localStorage dacă există
      const savedOrder = localStorage.getItem('stripeOrderData');
      if (savedOrder) {
        const parsed = JSON.parse(savedOrder);
        localStorage.removeItem('stripeOrderData');
        handleStripeOrder(parsed); // Transmite datele restaurate direct
        return;
      }
      handleStripeOrder(); // fallback
    } else if (status === 'cancel') {
      showError('Plata nereușită', 'Tranzacția a fost anulată. Produsele au rămas în coș.');
      localStorage.removeItem('stripeOrderData');
    }
  }, []);

  const fetchCartItems = async () => {
    try {
      const items = await cartAPI.getItems();
      if (items.length === 0) {
        navigate('/cart');
        return;
      }
      setCartItems(items);
    } catch (error) {
      console.error('Error fetching cart items:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setShippingAddress(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleApplyCoupon = async () => {
    if (!couponCode.trim()) return;
    
    setCouponLoading(true);
    setDiscountError(null);
    try {
      const validation = await couponsAPI.validate(couponCode, subtotal);
      setAppliedCoupon(validation);
      if (validation.valid) {
        showSuccess('Cupon aplicat!', `Ai economisit ${validation.discountAmount?.toFixed(2)} Lei`);
      } else {
        setDiscountError(validation.message);
        showError('Cupon invalid', validation.message);
      }
    } catch (error) {
      console.error('Error applying coupon:', error);
      setDiscountError('Nu am putut verifica cuponul');
      showError('Eroare', 'Nu am putut verifica cuponul');
    } finally {
      setCouponLoading(false);
    }
  };

  const handleRemoveCoupon = () => {
    setAppliedCoupon(null);
    setCouponCode('');
    showSuccess('Cupon eliminat', 'Cuponul a fost eliminat din comandă');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);

    try {
      const orderItems = cartItems.map(item => ({
        productId: item.productId,
        name: item.name, // trimite și numele produsului
        quantity: item.quantity,
        price: Number(item.discountPrice ?? item.price) // asigură-te că e număr
      }));

      const orderData = {
        items: orderItems,
        shippingAddress,
        paymentMethod,
        notes,
        couponCode: appliedCoupon?.valid ? couponCode : undefined,
        totalAmount: total
      };

      await ordersAPI.create(orderData);

      // Apply coupon if valid
      if (appliedCoupon?.valid && couponCode) {
        try {
          await couponsAPI.apply(couponCode, subtotal);
        } catch (error) {
          console.error('Error applying coupon:', error);
        }
      }

      // Update cart count after successful order
      updateCartCount();
      
      showSuccess('Comandă plasată!', 'Comanda ta a fost plasată cu succes. Vei primi o confirmare prin email.');
      navigate('/account');
    } catch (error) {
      console.error('Error placing order:', error);
      showError('Eroare!', 'Nu am putut plasa comanda. Te rog încearcă din nou.');
    } finally {
      setSubmitting(false);
    }
  };

  // handleStripeOrder primește datele restaurate ca parametru
  const handleStripeOrder = async (restoredData?: any) => {
    setSubmitting(true);
    try {
      let orderItems, shippingAddr, orderNotes, coupon, applied;
      if (restoredData) {
        orderItems = restoredData.cartItems;
        shippingAddr = restoredData.shippingAddress;
        orderNotes = restoredData.notes;
        coupon = restoredData.couponCode;
        applied = restoredData.appliedCoupon;
      } else {
        orderItems = cartItems;
        shippingAddr = shippingAddress;
        orderNotes = notes;
        coupon = couponCode;
        applied = appliedCoupon;
      }
      const items = orderItems.map((item: any) => ({
        productId: item.productId,
        name: item.name,
        quantity: item.quantity,
        price: Number(item.discountPrice ?? item.price)
      }));
      const orderData = {
        items,
        shippingAddress: shippingAddr,
        paymentMethod: 'credit-card',
        notes: orderNotes,
        couponCode: applied?.valid ? coupon : undefined,
        totalAmount: items.reduce((sum: number, item: any) => sum + item.price * item.quantity, 0) + (subtotal > 50 ? 0 : 0) - (applied?.valid ? (Number(applied.discountAmount) || 0) : 0)
      };
      await ordersAPI.create(orderData);
      if (applied?.valid && coupon) {
        try {
          await couponsAPI.apply(coupon, subtotal);
        } catch (error) {}
      }
      updateCartCount();
      showSuccess('Comandă plasată!', 'Plata Stripe a fost finalizată și comanda a fost adăugată în cont.');
      navigate('/account');
    } catch (error) {
      showError('Eroare!', 'Nu am putut plasa comanda după plata Stripe.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleStripePay = async () => {
    // Salvează toate datele comenzii în localStorage înainte de redirect
    localStorage.setItem('stripeOrderData', JSON.stringify({
      cartItems,
      shippingAddress,
      notes,
      couponCode,
      appliedCoupon
    }));
    try {
      const response = await fetch('/api/create-checkout-session', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ amount: total, success_url: window.location.origin + '/checkout?status=success', cancel_url: window.location.origin + '/checkout?status=cancel' }),
      });
      const data = await response.json();
      if (data.url) {
        window.location.href = data.url;
      } else {
        showError('Stripe', data.error || 'Eroare la inițierea plății');
      }
    } catch (err) {
      showError('Stripe', 'Eroare la inițierea plății');
    }
  };

  const subtotal = cartItems.reduce((sum, item) => {
    const price = item.discountPrice || item.price;
    return sum + (price * item.quantity);
  }, 0);

  const shipping = subtotal > 50 ? 0 : 0;
  const couponDiscount = appliedCoupon?.valid ? (Number(appliedCoupon.discountAmount) || 0) : 0;
  const total = subtotal + shipping - couponDiscount;

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-nature-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-6 sm:mb-8">Finalizare comandă</h1>

        <form onSubmit={async (e) => {
  e.preventDefault();
  if (paymentMethod === 'credit-card') {
    await handleStripePay();
  } else {
    await handleSubmit(e);
  }
}} className="grid lg:grid-cols-2 gap-8">
          {/* Left Column - Forms */}
          <div className="space-y-6">
            {/* Shipping Address */}
            <div className="bg-white p-4 sm:p-6 rounded-xl shadow-sm border">
              <div className="flex items-center mb-4 sm:mb-6">
                <MapPin className="w-4 h-4 sm:w-5 sm:h-5 mr-2 text-nature-600" />
                <h2 className="text-lg sm:text-xl font-semibold">Adresa de livrare</h2>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
                <div className="relative">
                  <label className="block text-sm font-medium text-gray-700 mb-2">Prenume *</label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <User className="h-4 w-4 sm:h-5 sm:w-5 text-gray-400" />
                    </div>
                    <input
                      type="text"
                      required
                      value={shippingAddress.firstName}
                      onChange={(e) => setShippingAddress({ ...shippingAddress, firstName: e.target.value })}
                      className="w-full pl-10 pr-4 py-2 sm:py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-nature-500 focus:border-transparent text-sm sm:text-base transition-colors"
                      placeholder="Prenume"
                    />
                  </div>
                </div>

                <div className="relative">
                  <label className="block text-sm font-medium text-gray-700 mb-2">Nume *</label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <User className="h-4 w-4 sm:h-5 sm:w-5 text-gray-400" />
                    </div>
                    <input
                      type="text"
                      required
                      value={shippingAddress.lastName}
                      onChange={(e) => setShippingAddress({ ...shippingAddress, lastName: e.target.value })}
                      className="w-full pl-10 pr-4 py-2 sm:py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-nature-500 focus:border-transparent text-sm sm:text-base transition-colors"
                      placeholder="Nume"
                    />
                  </div>
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-2">Adresa *</label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <MapPin className="h-4 w-4 sm:h-5 sm:w-5 text-gray-400" />
                    </div>
                    <input
                      type="text"
                      required
                      value={shippingAddress.address}
                      onChange={(e) => setShippingAddress({ ...shippingAddress, address: e.target.value })}
                      className="w-full pl-10 pr-4 py-2 sm:py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-nature-500 focus:border-transparent text-sm sm:text-base transition-colors"
                      placeholder="Strada, numărul"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Oraș *</label>
                  <input
                    type="text"
                    required
                    value={shippingAddress.city}
                    onChange={(e) => setShippingAddress({ ...shippingAddress, city: e.target.value })}
                    className="w-full px-4 py-2 sm:py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-nature-500 focus:border-transparent text-sm sm:text-base transition-colors"
                    placeholder="Orașul"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Cod poștal *</label>
                  <input
                    type="text"
                    required
                    value={shippingAddress.zipCode}
                    onChange={(e) => setShippingAddress({ ...shippingAddress, zipCode: e.target.value })}
                    className="w-full px-4 py-2 sm:py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-nature-500 focus:border-transparent text-sm sm:text-base transition-colors"
                    placeholder="Cod poștal"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-2">Telefon *</label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <Phone className="h-4 w-4 sm:h-5 sm:w-5 text-gray-400" />
                    </div>
                    <input
                      type="tel"
                      required
                      value={shippingAddress.phone}
                      onChange={(e) => setShippingAddress({ ...shippingAddress, phone: e.target.value })}
                      className="w-full pl-10 pr-4 py-2 sm:py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-nature-500 focus:border-transparent text-sm sm:text-base transition-colors"
                      placeholder="Numărul de telefon"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Payment Method */}
            <div className="bg-white p-4 sm:p-6 rounded-xl shadow-sm border">
              <div className="flex items-center mb-4 sm:mb-6">
                <CreditCard className="w-4 h-4 sm:w-5 sm:h-5 mr-2 text-nature-600" />
                <h2 className="text-lg sm:text-xl font-semibold">Metodă de plată</h2>
              </div>
              <div className="space-y-3">
                <label className="flex items-center space-x-3 p-3 border border-gray-200 rounded-xl hover:bg-gray-50 cursor-pointer transition-colors">
                  <input
                    type="radio"
                    name="paymentMethod"
                    value="credit-card"
                    checked={paymentMethod === 'credit-card'}
                    onChange={(e) => setPaymentMethod(e.target.value)}
                    className="text-nature-600 focus:ring-nature-500"
                  />
                  <CreditCard className="w-5 h-5 text-gray-600" />
                  <span className="font-medium">Plătește cu cardul (Stripe)</span>
                </label>
                <label className="flex items-center space-x-3 p-3 border border-gray-200 rounded-xl hover:bg-gray-50 cursor-pointer transition-colors">
                  <input
                    type="radio"
                    name="paymentMethod"
                    value="cash"
                    checked={paymentMethod === 'cash'}
                    onChange={(e) => setPaymentMethod(e.target.value)}
                    className="text-nature-600 focus:ring-nature-500"
                  />
                  <span className="font-medium">Plată la livrare (cash)</span>
                </label>
              </div>
            </div>

            {/* Discount Code */}
            <div className="bg-white p-4 sm:p-6 rounded-xl shadow-sm border">
              <div className="flex items-center mb-4 sm:mb-6">
                <Tag className="w-4 h-4 sm:w-5 sm:h-5 mr-2 text-nature-600" />
                <h2 className="text-lg sm:text-xl font-semibold">Cod de reducere</h2>
              </div>

              <div className="flex space-x-2">
                <input
                  type="text"
                  value={couponCode}
                  onChange={(e) => setCouponCode(e.target.value.toUpperCase())}
                  placeholder="Introduceți codul de reducere"
                  className="flex-1 px-4 py-2 sm:py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-nature-500 focus:border-transparent text-sm sm:text-base transition-colors"
                />
                <button
                  type="button"
                  onClick={handleApplyCoupon}
                  disabled={couponLoading || !couponCode.trim()}
                  className="px-4 sm:px-6 py-2 sm:py-3 bg-earth-600 text-white rounded-xl font-semibold hover:bg-earth-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors text-sm sm:text-base"
                >
                  {couponLoading ? 'Se verifică...' : 'Aplică'}
                </button>
              </div>
              {discountError && (
                <p className="mt-2 text-sm text-red-600">{discountError}</p>
              )}
              {appliedCoupon && (
                <p className="mt-2 text-sm text-green-600">
                  Cod aplicat cu succes! Reducere: {Number(appliedCoupon.discountAmount).toFixed(2)} Lei
                </p>
              )}
            </div>

            {/* Order Notes */}
            <div className="bg-white p-4 sm:p-6 rounded-xl shadow-sm border">
              <h2 className="text-lg sm:text-xl font-semibold mb-4 sm:mb-6">Note pentru comandă (opțional)</h2>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Instrucțiuni speciale pentru livrare..."
                rows={4}
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-nature-500 focus:border-transparent transition-colors"
              />
            </div>
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl shadow-sm border p-4 sm:p-6 lg:sticky lg:top-24">
              <h2 className="text-lg sm:text-xl font-semibold text-gray-900 mb-4 sm:mb-6">Sumar comandă</h2>
              
              {/* Items */}
              <div className="space-y-3 sm:space-y-4 mb-4 sm:mb-6">
                {cartItems.map((item) => (
                  <div key={item.id} className="flex items-center space-x-3">
                    <img
                      src={toAssetUrl(item.imageUrl)}
                      alt={item.name}
                      className="w-10 h-10 sm:w-12 sm:h-12 object-cover rounded-lg"
                    />
                    <div className="flex-1">
                      <h4 className="font-medium text-gray-900 text-xs sm:text-sm">{item.name}</h4>
                      <p className="text-gray-600 text-xs sm:text-sm">Cant: {item.quantity}</p>
                    </div>
                    <span className="font-semibold text-gray-900 text-xs sm:text-sm">
                      {((item.discountPrice || item.price) * item.quantity).toFixed(2)} Lei
                    </span>
                  </div>
                ))}
              </div>

              {/* Totals */}
              <div className="space-y-2 sm:space-y-3 mb-4 sm:mb-6 border-t pt-3 sm:pt-4">
                <div className="flex justify-between">
                  <span className="text-gray-600 text-sm sm:text-base">Subtotal</span>
                  <span className="font-semibold text-sm sm:text-base">{subtotal.toFixed(2)} Lei</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600 text-sm sm:text-base">Transport</span>
                  <span className="font-semibold text-sm sm:text-base">
                    {shipping === 0 ? 'Gratuit' : `${Number(shipping).toFixed(2)} Lei`}
                  </span>
                </div>
                {appliedCoupon?.valid && (
                  <div className="flex justify-between">
                    <span className="text-green-600 text-sm sm:text-base">Reducere cupon ({couponCode})</span>
                    <span className="text-green-600 font-semibold text-sm sm:text-base">-{couponDiscount.toFixed(2)} Lei</span>
                  </div>
                )}
                <div className="border-t pt-2 sm:pt-3">
                  <div className="flex justify-between">
                    <span className="text-base sm:text-lg font-semibold">Total</span>
                    <span className="text-base sm:text-lg font-bold text-earth-600">{total.toFixed(2)} Lei</span>
                  </div>
                </div>
              </div>

              <button
                type="submit"
                disabled={submitting}
                className="w-full bg-earth-600 text-white py-2 sm:py-3 px-4 sm:px-6 rounded-xl font-semibold hover:bg-earth-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors text-sm sm:text-base transform hover:-translate-y-0.5 shadow-lg"
              >
                {submitting ? 'Se plasează comanda...' : 'Plasează comanda'}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Checkout;
