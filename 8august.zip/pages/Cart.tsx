import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Trash2, Plus, Minus, ShoppingBag, ArrowRight } from 'lucide-react';
import { CartItem } from '../types';
import { cartAPI, toAssetUrl } from '../services/api';
import { useNotifications } from '../hooks/useNotifications';
import { useCart } from '../context/CartContext';

const Cart: React.FC = () => {
  const navigate = useNavigate();
  const { showSuccess, showError } = useNotifications();
  const { updateCartCount } = useCart();
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [updating, setUpdating] = useState<number | null>(null);

  useEffect(() => {
    fetchCartItems();
  }, []);

  const fetchCartItems = async () => {
    try {
      const items = await cartAPI.getItems();
      setCartItems(items);
      updateCartCount(); // Update cart count in context
    } catch (error) {
      console.error('Error fetching cart items:', error);
    } finally {
      setLoading(false);
    }
  };

  const updateQuantity = async (productId: number, newQuantity: number) => {
    if (newQuantity < 1) return;
    
    setUpdating(productId);
    try {
      await cartAPI.addItem(productId, newQuantity);
      await fetchCartItems();
      updateCartCount(); // Update cart count in context
    } catch (error) {
      console.error('Error updating quantity:', error);
    } finally {
      setUpdating(null);
    }
  };

  const removeItem = async (productId: number) => {
    try {
      await cartAPI.removeItem(productId);
      showSuccess('Produs eliminat', 'Produsul a fost eliminat din coșul tău');
      await fetchCartItems();
      updateCartCount(); // Update cart count in context
    } catch (error) {
      console.error('Error removing item:', error);
      showError('Eroare', 'Nu s-a putut elimina produsul din coș');
    }
  };

  const subtotal = cartItems.reduce((sum, item) => {
    const price = item.discountPrice || item.price;
    return sum + (price * item.quantity);
  }, 0);

  const shipping = subtotal > 50 ? 0 : 9.99;
  const total = subtotal + shipping;

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-nature-50 via-white to-sage-50">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-nature-600"></div>
      </div>
    );
  }

  if (cartItems.length === 0) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-nature-50 via-white to-sage-50 flex items-center justify-center">
        <div className="text-center">
          <ShoppingBag className="mx-auto h-24 w-24 text-gray-400 mb-4" />
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Coșul tău este gol</h2>
          <p className="text-gray-600 mb-8">Adaugă produse în coș pentru a continua cumpărăturile</p>
          <Link
            to="/products"
            className="inline-flex items-center bg-earth-600 text-white px-8 py-3 rounded-xl font-semibold hover:bg-earth-700 transition-colors shadow-lg transform hover:-translate-y-0.5"
          >
            <ArrowRight className="w-5 h-5 mr-2" />
            Continuă cumpărăturile
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 sm:py-8">
        <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-6 sm:mb-8">Coșul de cumpărături</h1>

        <div className="grid lg:grid-cols-3 gap-4 sm:gap-8">
          {/* Cart Items */}
          <div className="lg:col-span-2 space-y-2 sm:space-y-4">
            {cartItems.map((item) => (
              <div key={item.id} className="bg-white rounded-lg sm:rounded-xl shadow-sm border p-3 sm:p-6 hover:shadow-md transition-shadow">
                <div className="flex items-start sm:items-center space-x-3 sm:space-x-4">
                  <Link to={`/products/${item.productId}`} className="flex-shrink-0">
                    <img
                      src={toAssetUrl(item.imageUrl)}
                      alt={item.name}
                      className="w-16 h-16 sm:w-24 sm:h-24 object-cover rounded-md sm:rounded-lg hover:opacity-75 transition-opacity"
                    />
                  </Link>
                  <div className="flex-1 min-w-0">
                    <Link to={`/products/${item.productId}`} className="block hover:text-nature-600 transition-colors">
                      <h3 className="text-sm sm:text-lg font-semibold text-gray-900 mb-1 line-clamp-2">{item.name}</h3>
                    </Link>
                    <div className="flex items-center space-x-2 mb-2">
                      {item.discountPrice ? (
                        <>
                          <span className="font-semibold text-sm sm:text-base">{item.discountPrice.toFixed(2)} Lei</span>
                          <span className="text-gray-400 line-through text-xs sm:text-sm">{item.price.toFixed(2)} Lei</span>
                        </>
                      ) : (
                        <span className="font-semibold text-sm sm:text-base">{item.price.toFixed(2)} Lei</span>
                      )}
                    </div>
                    <p className="text-xs sm:text-sm text-gray-500">
                      {item.inStock ? (
                        <span className="text-green-600 font-medium">In stoc</span>
                      ) : (
                        <span className="text-red-600 font-medium">Indisponibil</span>
                      )}
                    </p>
                    
                    {/* Mobile: Quantity and Actions in same row */}
                    <div className="flex items-center justify-between mt-3 sm:hidden">
                      {/* Quantity Controls */}
                      <div className="flex items-center space-x-2 bg-gray-50 rounded-md p-1">
                        <button
                          onClick={() => updateQuantity(item.productId, item.quantity - 1)}
                          disabled={updating === item.productId || item.quantity <= 1}
                          className="w-7 h-7 rounded-md bg-white border border-gray-300 flex items-center justify-center hover:bg-gray-100 disabled:opacity-50 transition-colors"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="text-sm font-semibold w-8 text-center">{item.quantity}</span>
                        <button
                          onClick={() => updateQuantity(item.productId, item.quantity + 1)}
                          disabled={updating === item.productId || !item.inStock}
                          className="w-7 h-7 rounded-md bg-white border border-gray-300 flex items-center justify-center hover:bg-gray-100 disabled:opacity-50 transition-colors"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>
                      
                      {/* Action Buttons */}
                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => removeItem(item.productId)}
                          className="text-gray-400 hover:text-red-500 transition-colors p-1"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                  
                  {/* Desktop: Traditional layout */}
                  <div className="hidden sm:flex items-center space-x-4">
                    {/* Quantity Controls */}
                    <div className="flex items-center space-x-3 bg-gray-50 rounded-lg p-2">
                      <button
                        onClick={() => updateQuantity(item.productId, item.quantity - 1)}
                        disabled={updating === item.productId || item.quantity <= 1}
                        className="w-8 h-8 rounded-lg bg-white border border-gray-300 flex items-center justify-center hover:bg-gray-100 disabled:opacity-50 transition-colors"
                      >
                        <Minus className="w-4 h-4" />
                      </button>
                      <span className="text-lg font-semibold w-12 text-center bg-white px-2 py-1 rounded border">{item.quantity}</span>
                      <button
                        onClick={() => updateQuantity(item.productId, item.quantity + 1)}
                        disabled={updating === item.productId || !item.inStock}
                        className="w-8 h-8 rounded-lg bg-white border border-gray-300 flex items-center justify-center hover:bg-gray-100 disabled:opacity-50 transition-colors"
                      >
                        <Plus className="w-4 h-4" />
                      </button>
                    </div>
                    
                    {/* Action Buttons */}
                    <div className="flex flex-col space-y-2">
                      <button
                        onClick={() => removeItem(item.productId)}
                        className="text-gray-400 hover:text-red-500 transition-colors p-1"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </div>
                  </div>
                </div>
                
                {/* Item Total */}
                <div className="mt-3 sm:mt-4 pt-3 sm:pt-4 border-t border-gray-100 flex justify-between items-center">
                  <span className="text-xs sm:text-sm text-gray-600">Total produs:</span>
                  <span className="text-sm sm:text-lg font-bold text-gray-900">
                    {((item.discountPrice || item.price) * item.quantity).toFixed(2)} Lei
                  </span>
                </div>
              </div>
            ))}
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg sm:rounded-xl shadow-lg border p-4 sm:p-6 lg:sticky lg:top-24">
              <h2 className="text-lg sm:text-xl font-semibold text-gray-900 mb-4 sm:mb-6">Sumar comandă</h2>
              
              <div className="space-y-3 sm:space-y-4 mb-4 sm:mb-6">
                <div className="flex justify-between items-center">
                  <span className="text-gray-600 text-sm sm:text-base">Subtotal</span>
                  <span className="font-semibold text-sm sm:text-lg">{subtotal.toFixed(2)} Lei</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600 text-sm sm:text-base">Transport</span>
                  <span className="font-semibold text-sm sm:text-lg">
                    {shipping === 0 ? 'Gratuit' : `${shipping.toFixed(2)} Lei`}
                  </span>
                </div>
                {shipping > 0 && (
                  <p className="text-xs sm:text-sm text-nature-600 bg-nature-50 p-2 rounded">
                    Transport gratuit pentru comenzi peste 50 Lei
                  </p>
                )}
                <div className="border-t pt-3 sm:pt-4">
                  <div className="flex justify-between items-center">
                    <span className="text-lg sm:text-xl font-semibold">Total</span>
                    <span className="text-lg sm:text-2xl font-bold text-earth-600">{total.toFixed(2)} Lei</span>
                  </div>
                </div>
              </div>

              <button
                onClick={() => navigate('/checkout')}
                className="w-full bg-earth-600 text-white py-3 sm:py-4 px-4 sm:px-6 rounded-lg sm:rounded-xl font-semibold hover:bg-earth-700 transition-colors flex items-center justify-center space-x-2 shadow-lg text-sm sm:text-base transform hover:-translate-y-0.5"
              >
                <span>Continuă spre checkout</span>
                <ArrowRight className="w-4 h-4 sm:w-5 sm:h-5" />
              </button>

              <Link
                to="/products"
                className="block text-center text-nature-600 hover:text-nature-700 font-medium mt-3 sm:mt-6 text-sm sm:text-base transition-colors"
              >
                Continuă cumpărăturile
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Cart;
