import React, { useState, useEffect } from 'react';
import { User, Package, Settings, LogOut, Eye } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { Order } from '../types';
import { ordersAPI } from '../services/api';

const Account: React.FC = () => {
  const { user, logout } = useAuth();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('orders');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);

  useEffect(() => {
    fetchOrders();
  }, []);

  const fetchOrders = async () => {
    try {
      const ordersData = await ordersAPI.getMyOrders();
      setOrders(ordersData);
    } catch (error) {
      console.error('Error fetching orders:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending':
        return 'bg-earth-100 text-earth-800';
      case 'processing':
        return 'bg-nature-100 text-nature-800';
      case 'shipped':
        return 'bg-sage-100 text-sage-800';
      case 'delivered':
        return 'bg-nature-200 text-nature-900';
      case 'cancelled':
        return 'bg-earth-200 text-earth-900';
      default:
        return 'bg-sage-100 text-sage-800';
    }
  };

  const tabs = [
    { id: 'orders', label: 'Comenzile mele', icon: Package },
    { id: 'profile', label: 'Profil', icon: User },
    { id: 'settings', label: 'Setări', icon: Settings },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">


        <div className="grid grid-cols-1 lg:grid-cols-5 gap-6 lg:gap-8">
          {/* Sidebar */}
          <div className="lg:col-span-1 lg:min-w-0">
            <div className="card-organic p-4 lg:p-6 lg:sticky lg:top-24 lg:min-w-0">
              <div className="flex flex-col items-center text-center mb-6">
                <div className="w-12 h-12 bg-gradient-to-br from-nature-500 to-nature-600 rounded-full flex items-center justify-center shadow-organic mb-3">
                  <User className="w-6 h-6 text-white" />
                </div>
                <div className="w-full min-w-0">
                  <h3 className="font-semibold text-sage-900 leading-tight">
                    {user?.firstName} {user?.lastName}
                  </h3>
                  <p className="text-sm text-sage-600 break-all lg:break-words leading-tight mt-1 overflow-wrap-anywhere">{user?.email}</p>
                </div>
              </div>

              <nav className="space-y-2">
                {tabs.map((tab) => {
                  const Icon = tab.icon;
                  return (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id)}
                      className={`w-full flex items-center space-x-3 px-4 py-3 rounded-2xl text-left transition-all duration-200 ${
                        activeTab === tab.id
                          ? 'bg-nature-50 text-nature-600 border border-nature-200 shadow-sm'
                          : 'text-sage-700 hover:bg-sage-50'
                      }`}
                    >
                      <Icon className="w-5 h-5 flex-shrink-0" />
                      <span className="font-medium whitespace-nowrap">{tab.label}</span>
                    </button>
                  );
                })}
                
                <button
                  onClick={logout}
                  className="w-full flex items-center space-x-3 px-4 py-3 rounded-2xl text-left text-earth-600 hover:bg-earth-50 transition-colors"
                >
                  <LogOut className="w-5 h-5 flex-shrink-0" />
                  <span className="font-medium whitespace-nowrap">Deconectare</span>
                </button>
              </nav>
            </div>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-4 min-w-0">
            <div className="w-full max-w-none overflow-hidden">
              {activeTab === 'orders' && (
                <div className="card-organic p-4 lg:p-6">
                  <h2 className="text-xl font-semibold text-sage-900 mb-6">Istoricul comenzilor</h2>
                
                {loading ? (
                  <div className="flex items-center justify-center py-12">
                    <div className="text-center">
                      <div className="animate-spin rounded-full h-12 w-12 border-4 border-nature-200 border-t-nature-500 mx-auto mb-4"></div>
                      <p className="text-sage-600">Se încarcă comenzile...</p>
                    </div>
                  </div>
                ) : orders.length === 0 ? (
                  <div className="text-center py-12">
                    <Package className="w-16 h-16 text-sage-300 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-sage-900 mb-2">Încă nu ai comenzi</h3>
                    <p className="text-sage-600">Când vei plasa comenzi, acestea vor apărea aici</p>
                  </div>
                ) : (
                  <div className="space-y-4 max-w-none overflow-x-auto">
                    {orders.map((order) => (
                      <div key={order.id} className="border border-nature-200 rounded-2xl p-4 hover:shadow-soft transition-all duration-200 min-w-0">
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-3 gap-3">
                          <div className="min-w-0 flex-1">
                            <h3 className="font-semibold text-sage-900 truncate">
                              Comanda #{order.orderNumber}
                            </h3>
                            <p className="text-sm text-sage-600">
                              {new Date(order.createdAt).toLocaleDateString()}
                            </p>
                          </div>
                          <div className="text-left sm:text-right flex-shrink-0">
                            <span className={`inline-block px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(order.status)}`}>
                              {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                            </span>
                            <p className="text-lg font-bold text-sage-900 mt-1">
                              {order.totalAmount.toFixed(2)} Lei
                            </p>
                          </div>
                        </div>
                        
                        {order.items && Array.isArray(order.items) && (
                          <div className="mb-3">
                            <p className="text-sm text-sage-600">
                              <strong>Produse:</strong>
                            </p>
                            <ul className="ml-4 list-disc">
                              {order.items.map((item, idx) => (
                                <li key={idx} className="text-xs text-gray-800">
                                  {item.name} x{item.quantity} ({item.price} Lei)
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}
                        
                        <div className="flex items-center justify-between">
                          <div className="text-sm text-gray-600">
                            <p><strong>Metodă de plată:</strong> {order.paymentMethod}</p>
                          </div>
                          <button
                            className="flex items-center space-x-2 text-nature-600 hover:text-nature-700 font-medium"
                            onClick={() => setSelectedOrder(order)}
                          >
                            <Eye className="w-4 h-4" />
                            <span>Vezi detalii</span>
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {activeTab === 'profile' && (
              <div className="bg-white rounded-xl shadow-sm border p-4 lg:p-6">
                <h2 className="text-xl font-semibold text-gray-900 mb-6">Informații profil</h2>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Prenume
                    </label>
                    <input
                      type="text"
                      value={user?.firstName || ''}
                      readOnly
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg bg-gray-50"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Nume
                    </label>
                    <input
                      type="text"
                      value={user?.lastName || ''}
                      readOnly
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg bg-gray-50"
                    />
                  </div>
                  
                  <div className="lg:col-span-2">
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Email
                    </label>
                    <input
                      type="email"
                      value={user?.email || ''}
                      readOnly
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg bg-gray-50"
                    />
                  </div>
                </div>
                
                <div className="mt-6">
                  <button className="bg-earth-600 text-white px-6 py-2 rounded-lg hover:bg-earth-700 transition-colors">
                    Editează profilul
                  </button>
                </div>
              </div>
            )}            {activeTab === 'settings' && (
              <div className="bg-white rounded-xl shadow-sm border p-4 lg:p-6">
                <h2 className="text-xl font-semibold text-gray-900 mb-6">Setări cont</h2>

                <div className="space-y-6 max-w-none">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between p-4 border border-gray-200 rounded-lg gap-4">
                    <div className="min-w-0 flex-1">
                      <h3 className="font-medium text-gray-900">Notificări prin email</h3>
                      <p className="text-sm text-gray-600">Primește actualizări despre comenzi prin email</p>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer flex-shrink-0">
                      <input type="checkbox" className="sr-only peer" defaultChecked />
                      <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-nature-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-nature-600"></div>
                    </label>
                  </div>

                  <div className="flex flex-col sm:flex-row sm:items-center justify-between p-4 border border-gray-200 rounded-lg gap-4">
                    <div className="min-w-0 flex-1">
                      <h3 className="font-medium text-gray-900">Notificări prin SMS</h3>
                      <p className="text-sm text-gray-600">Primește actualizări despre livrare prin SMS</p>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer flex-shrink-0">
                      <input type="checkbox" className="sr-only peer" />
                      <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-nature-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-nature-600"></div>
                    </label>
                  </div>
                </div>

              </div>
            )}
            </div>
          </div>
        </div>
      </div>

      {/* Modal detalii comandă */}
      {selectedOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-40">
          <div className="bg-white rounded-xl shadow-xl w-full max-w-lg p-6 relative animate-slide-in overflow-y-auto max-h-[90vh]" style={{overflowX: 'hidden'}}>
            <button className="absolute top-4 right-4 text-gray-400 hover:text-gray-600 text-2xl" onClick={() => setSelectedOrder(null)}>&times;</button>
            <h2 className="text-xl font-bold mb-4 text-gray-900">Comanda #{selectedOrder.orderNumber}</h2>
            <div className="mb-4">
              <p className="text-gray-700"><strong>Status:</strong> <span className={`inline-block px-2 py-1 rounded text-xs font-medium ${getStatusColor(selectedOrder.status)}`}>{selectedOrder.status.charAt(0).toUpperCase() + selectedOrder.status.slice(1)}</span></p>
              <p className="text-gray-700"><strong>Data:</strong> {new Date(selectedOrder.createdAt).toLocaleDateString()}</p>
              <p className="text-gray-700"><strong>Total:</strong> {selectedOrder.totalAmount.toFixed(2)} Lei</p>
              <p className="text-gray-700"><strong>Metodă de plată:</strong> {selectedOrder.paymentMethod}</p>
              {/* Adresa de livrare pretty print */}
              <p className="text-gray-700"><strong>Adresă de livrare:</strong></p>
              {(() => {
                let addr = selectedOrder.shippingAddress;
                try {
                  const parsed = typeof addr === 'string' ? JSON.parse(addr) : addr;
                  if (parsed && typeof parsed === 'object') {
                    return (
                      <div className="pl-4 text-gray-600 text-sm space-y-1">
                        {parsed.firstName && <div><strong>Nume:</strong> {parsed.firstName} {parsed.lastName}</div>}
                        {parsed.address && <div><strong>Adresă:</strong> {parsed.address}</div>}
                        {parsed.city && <div><strong>Oraș:</strong> {parsed.city}</div>}
                        {parsed.zipCode && <div><strong>Cod poștal:</strong> {parsed.zipCode}</div>}
                        {parsed.phone && <div><strong>Telefon:</strong> {parsed.phone}</div>}
                        {/* orice alt câmp */}
                      </div>
                    );
                  }
                } catch {}
                return <span className="pl-4 text-gray-600 text-sm">{addr}</span>;
              })()}
              {selectedOrder.notes && <p className="text-gray-700"><strong>Note:</strong> {selectedOrder.notes}</p>}
              {selectedOrder.estimatedDelivery && (
                <p className="text-earth-700 font-semibold"><strong>Livrare estimată:</strong> {new Date(selectedOrder.estimatedDelivery).toLocaleDateString()}</p>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Account;
