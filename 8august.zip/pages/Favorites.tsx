import React, { useEffect, useState } from 'react';
import { productsAPI } from '../services/api';
import { Product } from '../types';
import ProductCard from '../components/ProductCard';

const Favorites: React.FC = () => {
  const [favorites, setFavorites] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [favoriteIds, setFavoriteIds] = useState<number[]>([]);

  useEffect(() => {
    fetchFavorites();
  }, []);

  const fetchFavorites = async () => {
    try {
      const favs = await productsAPI.getFavorites();
      // Normalizează ratingAvg și reviewsCount la 0 dacă lipsesc
      favs.forEach((f: any) => {
        f.ratingAvg = f.ratingAvg !== null && f.ratingAvg !== undefined ? Number(f.ratingAvg) : 0;
        f.reviewsCount = f.reviewsCount !== null && f.reviewsCount !== undefined ? Number(f.reviewsCount) : 0;
      });
      setFavorites(favs);
      setFavoriteIds(favs.map((f: any) => f.productId || f.id));
    } catch (e) {
      setFavorites([]);
      setFavoriteIds([]);
    } finally {
      setLoading(false);
    }
  };

  const handleRemove = async (productId: number) => {
    await productsAPI.removeFromFavorites(productId);
    setFavorites(favorites.filter(p => (p.productId || p.id) !== productId));
    setFavoriteIds(favoriteIds.filter(id => id !== productId));
  };

  if (loading) return <div className="p-8 text-center">Se încarcă...</div>;

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <h1 className="text-2xl font-bold mb-6 text-center md:text-left">Favoritele mele</h1>
        {favorites.length === 0 ? (
          <div className="text-gray-500 text-center">Nu ai produse favorite.</div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 md:gap-6">
            {favorites.map(product => (
              <div key={product.productId || product.id} className="relative group">
                <ProductCard product={{ ...product, id: product.productId || product.id, inStock: product.inStock ?? true }} favoriteIds={favoriteIds} viewMode="favorites" />
                <button
                  className="absolute bottom-2 left-2 bg-white rounded-full p-1 shadow hover:bg-red-100"
                  title="Elimină din favorite"
                  onClick={() => handleRemove(product.productId || product.id)}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6 text-red-500">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default Favorites;
