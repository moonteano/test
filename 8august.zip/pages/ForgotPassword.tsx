import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Mail } from 'lucide-react';
import { userAPI } from '../services/api';

const ForgotPassword: React.FC = () => {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setSuccess('');
    try {
      await userAPI.forgotPassword(email); // Now using userAPI
      setSuccess('Un email cu instrucțiuni de resetare a parolei a fost trimis.');
    } catch (err: any) {
      setError(err?.response?.data?.message || 'Eroare la trimiterea emailului.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white p-8 rounded-xl shadow-md w-full max-w-md">
        <h2 className="text-2xl font-bold mb-2 text-gray-900">Ai uitat parola?</h2>
        <p className="mb-6 text-gray-600">Introdu adresa de email și vei primi instrucțiuni pentru resetarea parolei.</p>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="email" className="block text-gray-700 font-medium mb-1">Email</label>
            <div className="relative">
              <input
                id="email"
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                required
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-nature-500 focus:border-transparent transition-colors"
                placeholder="exemplu@email.com"
                disabled={loading}
              />
              <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            </div>
          </div>
          {error && <div className="text-red-600 text-sm">{error}</div>}
          {success && <div className="text-green-600 text-sm">{success}</div>}
          <button
            type="submit"
            className="w-full bg-earth-600 text-white py-2 rounded-xl font-semibold hover:bg-earth-700 transition-colors disabled:opacity-50 shadow-lg transform hover:-translate-y-0.5"
            disabled={loading}
          >
            {loading ? 'Se trimite...' : 'Trimite email de resetare'}
          </button>
        </form>
        <div className="mt-6 text-center">
          <Link to="/login" className="text-nature-600 hover:underline transition-colors">Înapoi la autentificare</Link>
        </div>
      </div>
    </div>
  );
};

export default ForgotPassword;
