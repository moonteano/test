import React from 'react';

const About: React.FC = () => (
  <div className="max-w-3xl mx-auto px-4 py-12">
    <h1 className="text-3xl font-display font-bold mb-6 text-nature-700">Despre Noi</h1>
    <p className="text-lg text-sage-700 mb-4">
      <b>Indianul</b> este mai mult decât un magazin – este o comunitate dedicată stilului de viață sănătos, natural și sustenabil. Povestea noastră a început din dorința de a aduce pe masa ta produse autentice, curate, provenite direct din natură: soia organică, sare artizanală, condimente naturale și amestecuri de sezon.
    </p>
    <p className="text-sage-600 mb-4">
      Ne mândrim cu parteneriatele noastre cu fermieri locali și producători artizanali, selectând cu grijă fiecare produs pentru a garanta calitate, prospețime și trasabilitate. Fiecare comandă este ambalată cu grijă în materiale eco-friendly, iar pentru fiecare achiziție plantăm un copac.
    </p>
    <p className="text-sage-600 mb-4">
      Misiunea noastră este să inspirăm cât mai mulți oameni să descopere gustul autentic al naturii și să adopte obiceiuri sustenabile, pentru o planetă mai verde și o viață mai sănătoasă.
    </p>
    <div className="mt-8 bg-nature-50 border-l-4 border-nature-400 p-6 rounded-xl shadow-organic">
      <h2 className="text-xl font-semibold text-nature-700 mb-2">Valorile noastre:</h2>
      <ul className="list-disc pl-6 text-sage-700 space-y-2">
        <li>100% produse naturale, certificate organic</li>
        <li>Respect pentru natură și comunitate</li>
        <li>Transparență și etică în tot ceea ce facem</li>
        <li>Ambalaje sustenabile și inițiative verzi</li>
        <li>Sprijin pentru producătorii locali</li>
      </ul>
    </div>
    <div className="mt-10 text-sage-500 text-sm">
      <b>Contact:</b> Pentru orice întrebare sau colaborare, scrie-ne la <a href="mailto:hello@indianul.ro" className="text-nature-600 underline">hello@indianul.ro</a> sau folosește formularul de contact.
    </div>
  </div>
);

export default About;
