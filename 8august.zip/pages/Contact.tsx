import React, { useState } from 'react';
import { Mail, Phone, MapPin, Send, Clock, MessageSquare, CheckCircle, User } from 'lucide-react';
import { useNotifications } from '../hooks/useNotifications';
import { useAuth } from '../context/AuthContext';
import api from '../services/api';
import SimpleCaptcha from '../components/SimpleCaptcha';
import { FaWhatsapp } from 'react-icons/fa'; // Add WhatsApp icon

const Contact: React.FC = () => {
  const { user, isAuthenticated } = useAuth();
  const { showSuccess, showError } = useNotifications();
  const [formData, setFormData] = useState({
    name: isAuthenticated ? `${user?.firstName} ${user?.lastName}` : '',
    email: isAuthenticated ? user?.email || '' : '',
    subject: '',
    message: ''
  });
  const [loading, setLoading] = useState(false);
  const [showSuccessAnimation, setShowSuccessAnimation] = useState(false);
  const [captchaValid, setCaptchaValid] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    if (!captchaValid) {
      showError('Captcha incorect!', 'Vă rugăm să introduceți codul corect din imagine.');
      setLoading(false);
      return;
    }
    try {
      await api.post('/contact', formData);
      showSuccess('Mesaj trimis!', 'Mesajul dumneavoastră a fost trimis cu succes. Vă vom răspunde în cel mai scurt timp.');
      setShowSuccessAnimation(true);
      setFormData({ 
        name: isAuthenticated ? `${user?.firstName} ${user?.lastName}` : '', 
        email: isAuthenticated ? user?.email || '' : '', 
        subject: '', 
        message: '' 
      });
      setTimeout(() => setShowSuccessAnimation(false), 3000);
    } catch (error) {
      showError('Eroare!', 'Nu am putut trimite mesajul. Vă rugăm să încercați din nou.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Contactează-ne</h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Suntem aici să te ajutăm! Trimite-ne un mesaj și îți vom răspunde în cel mai scurt timp.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Contact Form */}
          <div className="bg-white rounded-3xl shadow-soft border p-8 backdrop-blur-sm">
            <div className="flex items-center space-x-3 mb-6">
              <MessageSquare className="w-6 h-6 text-nature-600" />
              <h2 className="text-2xl font-semibold text-gray-900">Trimite un mesaj</h2>
            </div>

            {showSuccessAnimation && (
              <div className="mb-6 p-4 bg-nature-50 border border-nature-200 rounded-xl animate-bounce">
                <div className="flex items-center space-x-3">
                  <CheckCircle className="w-8 h-8 text-nature-600" />
                  <div>
                    <h3 className="font-semibold text-nature-800">Mesaj trimis cu succes!</h3>
                    <p className="text-nature-600">Vă vom răspunde în cel mai scurt timp.</p>
                  </div>
                </div>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Nume complet
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      required
                      readOnly={isAuthenticated}
                      className={`w-full px-4 py-3 pl-10 border border-gray-300 rounded-xl focus:ring-2 focus:ring-nature-500 focus:border-transparent transition-all ${
                        isAuthenticated ? 'bg-sage-50' : ''
                      }`}
                      placeholder="Numele tău"
                    />
                    <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Email
                  </label>
                  <div className="relative">
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      required
                      readOnly={isAuthenticated}
                      className={`w-full px-4 py-3 pl-10 border border-gray-300 rounded-xl focus:ring-2 focus:ring-nature-500 focus:border-transparent transition-all ${
                        isAuthenticated ? 'bg-sage-50' : ''
                      }`}
                      placeholder="email@exemplu.ro"
                    />
                    <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Subiect
                </label>
                <input
                  type="text"
                  name="subject"
                  value={formData.subject}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-nature-500 focus:border-transparent transition-all"
                  placeholder="Subiectul mesajului"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Mesaj
                </label>
                <textarea
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  required
                  rows={6}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-nature-500 focus:border-transparent transition-all"
                  placeholder="Scrie mesajul tău aici..."
                />
              </div>

              <SimpleCaptcha onValidate={setCaptchaValid} />

              <button
                type="submit"
                disabled={loading}
                className="w-full bg-earth-600 text-white py-3 px-6 rounded-xl font-semibold hover:bg-earth-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300 transform hover:scale-105 active:scale-95 flex items-center justify-center space-x-2 shadow-lg hover:shadow-xl"
              >
                <Send className="w-5 h-5" />
                <span>{loading ? 'Se trimite...' : 'Trimite mesajul'}</span>
              </button>
            </form>
          </div>

          {/* Contact Info */}
          <div className="space-y-8">
            <div className="bg-white rounded-3xl shadow-soft border p-8 backdrop-blur-sm">
              <h2 className="text-2xl font-semibold text-gray-900 mb-6">Informații de contact</h2>
              
              <div className="space-y-6">
                <div className="flex items-start space-x-4">
                  <div className="bg-nature-100 p-3 rounded-xl">
                    <MapPin className="w-6 h-6 text-nature-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">Adresa</h3>
                    <p className="text-gray-600">DJ248 31, Lunca Cetățuii 707085<br />Iași, România</p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="bg-earth-100 p-3 rounded-xl">
                    <Phone className="w-6 h-6 text-earth-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">Telefon</h3>
                    <p className="text-gray-600">+40 743 159 223</p>
                    <p className="text-gray-600">+40 744 137 032</p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="bg-sage-100 p-3 rounded-xl">
                    <Mail className="w-6 h-6 text-sage-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">Email</h3>
                    <p className="text-gray-600">apache_com@yahoo.com</p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="bg-earth-100 p-3 rounded-xl">
                    <Clock className="w-6 h-6 text-earth-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">Program</h3>
                    <p className="text-gray-600">
                      Luni - Vineri: 07:00 - 15:00<br />
                      Sâmbătă: 07:00 - 13:00<br />
                      Duminică: Închis
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="bg-green-100 p-3 rounded-xl">
                    <FaWhatsapp className="w-6 h-6 text-green-500" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">WhatsApp</h3>
                    <p className="text-gray-600 mb-2">Contactează-ne rapid pe WhatsApp!</p>
                    <a
                      href={`https://wa.me/40770877094?text=${encodeURIComponent('Salut! Am o întrebare despre produsele voastre.')}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center px-4 py-2 bg-green-500 text-white rounded-xl font-semibold shadow hover:bg-green-600 transition-all duration-200"
                    >
                      <FaWhatsapp className="w-5 h-5 mr-2" />
                      Deschide WhatsApp
                    </a>
                    {/* Înlocuiește PHONE_NUMBER cu numărul tău, ex: 40744137032 */}
                  </div>
                </div>
              </div>
            </div>

            {/* FAQ */}
            <div className="bg-white rounded-3xl shadow-soft border p-8 backdrop-blur-sm">
              <h2 className="text-2xl font-semibold text-gray-900 mb-6">Întrebări frecvente</h2>
              
              <div className="space-y-4">
                <div className="p-4 bg-nature-50 rounded-xl border border-nature-100">
                  <h3 className="font-semibold text-gray-900 mb-2">Cât durează livrarea?</h3>
                  <p className="text-gray-600 text-sm">Livrarea se face în 1-3 zile lucrătoare pentru comenzile din București și 2-5 zile pentru restul țării.</p>
                </div>
                
                <div className="p-4 bg-earth-50 rounded-xl border border-earth-100">
                  <h3 className="font-semibold text-gray-900 mb-2">Pot returna un produs?</h3>
                  <p className="text-gray-600 text-sm">Da, aveți 14 zile pentru a returna produsele în stare originală.</p>
                </div>
                
                <div className="p-4 bg-sage-50 rounded-xl border border-sage-100">
                  <h3 className="font-semibold text-gray-900 mb-2">Ce metode de plată acceptați?</h3>
                  <p className="text-gray-600 text-sm">Acceptăm plata cu cardul, transfer bancar și ramburs la livrare.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;
